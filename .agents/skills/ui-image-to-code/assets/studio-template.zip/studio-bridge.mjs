import http from 'node:http';
import path from 'node:path';
import { readFile } from 'node:fs/promises';
import {
  PROTOCOL_VERSION, MAX_DOCUMENT_BYTES, MAX_REFERENCE_BYTES, appendOperationLog, applyPreviewDocumentToProject, archiveDocument, atomicWriteBuffer, atomicWriteBundle, atomicWriteJSON,
  buildSemanticOperations, documentChangeSummary, ensureSyncProject, executableSourceHash, generatedSourceHash, listDocumentHistory, readDocumentRevision, readJSON, readSyncSnapshot, sourceHash, syncPaths, validateDocument,
} from './ui-sync-core.mjs';
import { computeFidelityGate, FIDELITY_WEIGHTS } from './ui-fidelity-core.mjs';
import { runLocalOcr } from './local-ocr.mjs';

const root = path.resolve(process.cwd());
const port = Number(process.env.UI_STUDIO_PORT || 4173);
const host = process.env.UI_STUDIO_HOST || '127.0.0.1';
const STUDIO_BUILD_VERSION = '2.13.0';
const types = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.mjs':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.json':'application/json; charset=utf-8', '.png':'image/png', '.svg':'image/svg+xml' };

// Every API request observes one coherent project snapshot. In particular, two
// Studio tabs cannot both read the same revision and then commit it in parallel.
let projectOperationTail = Promise.resolve();
async function withProjectOperationLock(operation) {
  const previous = projectOperationTail;
  let release;
  projectOperationTail = new Promise((resolve) => { release = resolve; });
  await previous;
  try { return await operation(); }
  finally { release(); }
}

function json(response, status, payload) {
  response.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' });
  response.end(JSON.stringify(payload));
}

async function bodyJSON(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > MAX_DOCUMENT_BYTES + 64 * 1024) throw Object.assign(new Error('请求体过大'), { status:413 });
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); }
  catch { throw Object.assign(new Error('JSON 无法解析'), { status:400 }); }
}

async function bodyBuffer(request, maximumBytes) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maximumBytes) throw Object.assign(new Error('上传文件过大'), { status:413 });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

function inspectPng(buffer) {
  if (buffer.length < 24 || buffer.subarray(0, 8).toString('hex') !== '89504e470d0a1a0a' || buffer.subarray(12, 16).toString('ascii') !== 'IHDR') throw Object.assign(new Error('只接受有效 PNG 参考图'), { status:400 });
  const width = buffer.readUInt32BE(16);
  const height = buffer.readUInt32BE(20);
  if (!width || !height || width > 20000 || height > 20000 || width * height > 100_000_000) throw Object.assign(new Error('参考图尺寸无效或过大'), { status:400 });
  return { width, height };
}

function currentQualityGate(snapshot) {
  const gate = snapshot.evidence?.qualityGate || null;
  if (!gate) return null;
  const stale = Number(gate.revision) !== Number(snapshot.document.revision)
    || gate.sourceHash !== snapshot.currentPreviewHash;
  return stale ? { ...gate, passed:false, stale:true, staleReason:'revision-or-executable-source-changed' } : { ...gate, stale:false };
}

function publicStatus(snapshot) {
  return {
    protocolVersion: PROTOCOL_VERSION,
    studioBuildVersion: STUDIO_BUILD_VERSION,
    projectId: path.basename(root),
    connected: true,
    state: snapshot.state.state,
    documentRevision: snapshot.document.revision,
    appliedRevision: snapshot.state.appliedRevision,
    previewRevision: snapshot.state.previewRevision || 0,
    previewStatus: snapshot.state.previewStatus || 'clean',
    previewCoverage: snapshot.state.previewCoverage || 'complete',
    previewIsCurrent: snapshot.state.previewIsCurrent,
    previewBlockedTargets: snapshot.state.previewBlockedTargets || [],
    previewIssue: snapshot.state.previewIssue || null,
    baseSourceHash: snapshot.state.baseSourceHash,
    currentSourceHash: snapshot.currentHash,
    previewSourceHash: snapshot.state.previewSourceHash || null,
    currentPreviewSourceHash: snapshot.currentPreviewHash || null,
    previewGeneratedHash: snapshot.state.previewGeneratedHash || null,
    currentGeneratedHash: snapshot.currentGeneratedHash || null,
    previewExecutableIsCurrent: snapshot.state.previewExecutableIsCurrent,
    lastWriter: snapshot.state.lastWriter,
    pendingChanges: snapshot.state.pendingChanges,
    summary: documentChangeSummary(snapshot.document),
    updatedAt: snapshot.state.updatedAt,
    qualityGate: currentQualityGate(snapshot),
    handoffStatus: snapshot.handoff?.status || 'idle',
    handoffRevision: Number(snapshot.handoff?.revision || 0),
  };
}

function normalizeFidelityEvidence(payload, snapshot) {
  const scoreKeys = Object.keys(FIDELITY_WEIGHTS);
  const scores = Object.fromEntries(scoreKeys.map((key) => {
    const raw = payload.scores?.[key];
    const value = raw === '' || raw === null || raw === undefined ? null : Number(raw);
    if (value !== null && (!Number.isFinite(value) || value < 0 || value > 100)) throw Object.assign(new Error(`Invalid fidelity score: ${key}`), { status:400 });
    return [key, value];
  }));
  const criticalFailures = Array.isArray(payload.criticalFailures)
    ? payload.criticalFailures.map(String).filter(Boolean).slice(0, 30)
    : [];
  const computed = computeFidelityGate(scores, criticalFailures);
  const proofKind = payload.proofKind === 'browser-capture' ? 'browser-capture' : 'diagnostic';
  const metrics = {};
  for (const [key, raw] of Object.entries(payload.metrics || {})) {
    const value = Number(raw);
    if (Number.isFinite(value)) metrics[String(key).slice(0, 80)] = value;
  }
  return {
    revision:Number(snapshot.document.revision || 0),
    sourceHash:snapshot.currentPreviewHash,
    canonicalSourceHash:snapshot.currentHash,
    proofKind,
    scores,
    criticalFailures,
    complete:computed.complete,
    coverage:computed.coverage,
    score:computed.score,
    provisionalScore:computed.provisionalScore,
    passed:Boolean(computed.passed && proofKind === 'browser-capture'),
    metrics,
    verifiedAt:new Date().toISOString(),
  };
}

async function handleAPI(request, response, url) {
  const paths = syncPaths(root);
  const referenceMatch = url.pathname.match(/^\/__ui_sync\/reference\/([A-Za-z0-9_.-]{1,120})$/);
  if (request.method === 'PUT' && referenceMatch) {
    const snapshot = await readSyncSnapshot(root);
    const expectedRevision = Number(request.headers['x-ui-expected-revision']);
    if (expectedRevision !== Number(snapshot.document.revision)) return json(response, 409, { error:'revision.conflict', message:'项目中已有更新，请先拉取最新版', status:publicStatus(snapshot) });
    if (String(request.headers['content-type'] || '').split(';')[0].trim() !== 'image/png') throw Object.assign(new Error('参考图必须转换为 PNG 后上传'), { status:415 });
    const buffer = await bodyBuffer(request, MAX_REFERENCE_BYTES);
    const dimensions = inspectPng(buffer);
    const id = referenceMatch[1];
    await atomicWriteBuffer(path.join(paths.references, `${id}.png`), buffer);
    return json(response, 200, { id, path:`/.ui-studio/references/${id}.png`, bytes:buffer.length, ...dimensions });
  }
  if (request.method === 'POST' && url.pathname === '/__ui_sync/ocr') {
    if (String(request.headers['content-type'] || '').split(';')[0].trim() !== 'image/png') throw Object.assign(new Error('本地 OCR 只接受 PNG'), { status:415 });
    const buffer = await bodyBuffer(request, MAX_REFERENCE_BYTES);
    const dimensions = inspectPng(buffer);
    const result = await runLocalOcr(buffer, { root });
    if (!result.available) return json(response, 503, { ...result, message:'没有可用的本地 OCR：请安装系统 OCR 语言或 Tesseract，或在高级选项导入结果。' });
    return json(response, 200, { ...result, width:dimensions.width, height:dimensions.height });
  }
  if (request.method === 'GET' && url.pathname === '/__ui_sync/status') {
    return json(response, 200, publicStatus(await readSyncSnapshot(root)));
  }
  if (request.method === 'GET' && url.pathname === '/__ui_sync/client-version') {
    return json(response, 200, { studioBuildVersion:STUDIO_BUILD_VERSION, projectId:path.basename(root) });
  }
  if (request.method === 'GET' && url.pathname === '/__ui_sync/document') {
    const snapshot = await readSyncSnapshot(root);
    return json(response, 200, { document:snapshot.document, status:publicStatus(snapshot) });
  }
  if (request.method === 'GET' && url.pathname === '/__ui_sync/handoff') {
    await ensureSyncProject(root);
    return json(response, 200, await readJSON(paths.handoff));
  }
  if (request.method === 'GET' && url.pathname === '/__ui_sync/fidelity') {
    const snapshot = await readSyncSnapshot(root);
    return json(response, 200, { qualityGate:currentQualityGate(snapshot), status:publicStatus(snapshot) });
  }
  if (request.method === 'PUT' && url.pathname === '/__ui_sync/fidelity') {
    const payload = await bodyJSON(request);
    const snapshot = await readSyncSnapshot(root);
    if (Number(payload.expectedRevision) !== Number(snapshot.document.revision)) return json(response, 409, { error:'revision.conflict', status:publicStatus(snapshot) });
    const qualityGate = normalizeFidelityEvidence(payload, snapshot);
    const evidence = { ...(snapshot.evidence || snapshot.document.evidence), qualityGate };
    const document = { ...snapshot.document, evidence };
    validateDocument(document);
    await atomicWriteBundle(paths.transaction, [
      { file:paths.evidence, value:evidence },
      { file:paths.document, value:document },
    ]);
    return json(response, 200, { qualityGate, status:{ ...publicStatus(snapshot), qualityGate } });
  }
  if (request.method === 'GET' && url.pathname === '/__ui_sync/history') {
    const snapshot = await readSyncSnapshot(root);
    return json(response, 200, {
      current:{ revision:snapshot.document.revision, updatedAt:snapshot.document.updatedAt || null, updatedBy:snapshot.document.updatedBy || null, summary:documentChangeSummary(snapshot.document) },
      archived:await listDocumentHistory(paths),
    });
  }
  if (request.method === 'PUT' && url.pathname === '/__ui_sync/document') {
    const payload = await bodyJSON(request);
    const snapshot = await readSyncSnapshot(root);
    if (Number(payload.expectedRevision) !== Number(snapshot.document.revision)) {
      return json(response, 409, { error:'revision.conflict', message:'项目中已有更新，请先拉取最新版', status:publicStatus(snapshot), latestDocument:snapshot.document });
    }
    try { validateDocument(payload.document); }
    catch (error) { throw Object.assign(error, { status:400 }); }
    if (snapshot.state.state === 'conflict' || payload.document.baseSourceHash !== snapshot.currentHash) {
      return json(response, 409, { error:'source.changed', message:'Codex 源码已变化，请先拉取最新版并检查差异', status:publicStatus(snapshot), latestDocument:snapshot.document });
    }
    await archiveDocument(paths, snapshot.document);
    const revision = Number(snapshot.document.revision) + 1;
    let semanticOperations;
    try { semanticOperations = buildSemanticOperations(payload.operations || [], revision, 'studio'); }
    catch (error) { throw Object.assign(error, { status:400 }); }
    const document = {
      ...payload.document,
      protocolVersion:PROTOCOL_VERSION,
      revision,
      baseSourceHash:snapshot.currentHash,
      operations:[...(snapshot.document.operations || []), ...semanticOperations].slice(-200),
      updatedAt:new Date().toISOString(),
      updatedBy:'studio',
    };
    try { validateDocument(document); }
    catch (error) { throw Object.assign(error, { status:400 }); }
    const now = new Date().toISOString();
    let previewResult;
    try { previewResult = await applyPreviewDocumentToProject(root, document); }
    catch (error) { previewResult = { applied:false, status:'failed', coverage:'none', unresolvedTargetIds:[], message:error.message }; }
    const [previewHash, generatedHash] = previewResult.applied
      ? await Promise.all([executableSourceHash(root), generatedSourceHash(root)])
      : [snapshot.storedState.previewSourceHash || snapshot.currentPreviewHash, snapshot.storedState.previewGeneratedHash || snapshot.currentGeneratedHash];
    const state = {
      ...snapshot.storedState,
      protocolVersion:PROTOCOL_VERSION,
      documentRevision:revision,
      baseSourceHash:snapshot.currentHash,
      currentSourceHash:snapshot.currentHash,
      state:'pending-codex',
      previewRevision:previewResult.applied ? revision : Number(snapshot.storedState.previewRevision || 0),
      previewStatus:previewResult.status,
      previewCoverage:previewResult.coverage,
      previewBlockedTargets:[...(previewResult.duplicateIds || []), ...(previewResult.unresolvedTargetIds || [])],
      previewIssue:previewResult.issue || previewResult.message || null,
      previewUpdatedAt:previewResult.applied ? now : (snapshot.storedState.previewUpdatedAt || null),
      previewSourceHash:previewHash,
      previewGeneratedHash:generatedHash,
      lastWriter:'studio',
      updatedAt:now,
    };
    const automaticHandoff = {
      protocolVersion:PROTOCOL_VERSION,
      revision,
      status:previewResult.applied ? 'preview-applied-waiting-codex' : 'waiting-codex',
      summary:documentChangeSummary(document),
      preview:{ revision:previewResult.applied ? revision : Number(snapshot.storedState.previewRevision || 0), status:previewResult.status, coverage:previewResult.coverage },
      requestedAt:now,
      prompt:`请使用 $ui-image-to-code 接管 Studio 最新修改。先运行 npm run sync:context，确认身份状态有效；实际页面参数补丁已预览应用，但正式源码仍需执行 npm run sync:apply。当前修订 r${revision}。`,
    };
    await atomicWriteBundle(paths.transaction, [
      { file:paths.document, value:document },
      { file:paths.evidence, value:document.evidence },
      { file:paths.state, value:state },
      { file:paths.handoff, value:automaticHandoff },
    ]);
    await appendOperationLog(paths.operations, {
      protocolVersion:PROTOCOL_VERSION,
      revision,
      writer:'studio',
      createdAt:document.updatedAt,
      summary:documentChangeSummary(document),
      operations:semanticOperations,
    });
    const next = await readSyncSnapshot(root);
    return json(response, 200, { document, status:publicStatus(next) });
  }
  if (request.method === 'POST' && url.pathname === '/__ui_sync/handoff') {
    const payload = await bodyJSON(request);
    const snapshot = await readSyncSnapshot(root);
    if (Number(payload.expectedRevision) !== Number(snapshot.document.revision)) return json(response, 409, { error:'revision.conflict', status:publicStatus(snapshot) });
    const summary = documentChangeSummary(snapshot.document);
    const handoff = {
      protocolVersion:PROTOCOL_VERSION,
      revision:snapshot.document.revision,
      status:'ready-for-codex',
      summary,
      note:String(payload.note || ''),
      requestedAt:new Date().toISOString(),
      prompt:`请使用 $ui-image-to-code 接管 Studio 最新修改。先运行 npm run sync:context，确认身份状态有效、源码基线未冲突，再审查并执行 npm run sync:apply。当前修订 r${snapshot.document.revision}。`,
    };
    await atomicWriteJSON(paths.handoff, handoff);
    return json(response, 200, handoff);
  }
  if (request.method === 'POST' && url.pathname === '/__ui_sync/rollback') {
    const payload = await bodyJSON(request);
    const snapshot = await readSyncSnapshot(root);
    const expectedRevision = Number(payload.expectedRevision);
    const targetRevision = Number(payload.targetRevision);
    if (expectedRevision !== Number(snapshot.document.revision)) return json(response, 409, { error:'revision.conflict', status:publicStatus(snapshot) });
    if (!Number.isInteger(targetRevision) || targetRevision < 0 || targetRevision >= expectedRevision) return json(response, 400, { error:'revision.invalid', message:'请选择较早的有效修订' });
    if (snapshot.state.state === 'source-ahead' || snapshot.state.state === 'conflict') return json(response, 409, { error:'source.changed', message:'源码基线已变化，请先拉取 Codex 最新版', status:publicStatus(snapshot) });
    const target = await readDocumentRevision(paths, targetRevision);
    if (!target) return json(response, 404, { error:'revision.not-found', message:`找不到修订 r${targetRevision}` });
    await archiveDocument(paths, snapshot.document);
    const revision = expectedRevision + 1;
    const restoredOperation = buildSemanticOperations([{
      type:'history.restore',
      targetIds:[],
      detail:{ fromRevision:expectedRevision, targetRevision },
    }], revision, 'studio');
    const now = new Date().toISOString();
    const document = {
      ...target,
      protocolVersion:PROTOCOL_VERSION,
      revision,
      baseSourceHash:snapshot.currentHash,
      operations:[...(snapshot.document.operations || []), ...restoredOperation].slice(-200),
      updatedAt:now,
      updatedBy:'studio',
    };
    validateDocument(document);
    let previewResult;
    try { previewResult = await applyPreviewDocumentToProject(root, document); }
    catch (error) { previewResult = { applied:false, status:'failed', coverage:'none', unresolvedTargetIds:[], message:error.message }; }
    const [previewHash, generatedHash] = previewResult.applied
      ? await Promise.all([executableSourceHash(root), generatedSourceHash(root)])
      : [snapshot.storedState.previewSourceHash || snapshot.currentPreviewHash, snapshot.storedState.previewGeneratedHash || snapshot.currentGeneratedHash];
    const state = {
      ...snapshot.storedState,
      documentRevision:revision,
      baseSourceHash:snapshot.currentHash,
      currentSourceHash:snapshot.currentHash,
      state:'pending-codex',
      previewRevision:previewResult.applied ? revision : Number(snapshot.storedState.previewRevision || 0),
      previewStatus:previewResult.status,
      previewCoverage:previewResult.coverage,
      previewBlockedTargets:[...(previewResult.duplicateIds || []), ...(previewResult.unresolvedTargetIds || [])],
      previewIssue:previewResult.issue || previewResult.message || null,
      previewUpdatedAt:previewResult.applied ? now : (snapshot.storedState.previewUpdatedAt || null),
      previewSourceHash:previewHash,
      previewGeneratedHash:generatedHash,
      lastWriter:'studio',
      updatedAt:now,
    };
    const rollbackHandoff = {
      protocolVersion:PROTOCOL_VERSION,
      revision,
      status:previewResult.applied ? 'preview-applied-waiting-codex' : 'waiting-codex',
      summary:documentChangeSummary(document),
      preview:{ revision:previewResult.applied ? revision : Number(snapshot.storedState.previewRevision || 0), status:previewResult.status, coverage:previewResult.coverage },
      requestedAt:now,
      prompt:`请使用 $ui-image-to-code 接管 Studio 回退后的修订 r${revision}，先运行 npm run sync:context 再应用到正式源码。`,
    };
    await atomicWriteBundle(paths.transaction, [
      { file:paths.document, value:document },
      { file:paths.evidence, value:document.evidence },
      { file:paths.state, value:state },
      { file:paths.handoff, value:rollbackHandoff },
    ]);
    await appendOperationLog(paths.operations, {
      protocolVersion:PROTOCOL_VERSION,
      revision,
      writer:'studio',
      createdAt:now,
      summary:documentChangeSummary(document),
      operations:restoredOperation,
    });
    const next = await readSyncSnapshot(root);
    return json(response, 200, { document, restoredFrom:targetRevision, status:publicStatus(next) });
  }
  if (request.method === 'POST' && url.pathname === '/__ui_sync/reload-source') {
    await bodyJSON(request);
    const snapshot = await readSyncSnapshot(root);
    if (snapshot.state.pendingChanges) return json(response, 409, { error:'pending.studio', message:'仍有未应用的 Studio 修改，不能直接覆盖', status:publicStatus(snapshot) });
    const [hash, previewHash, generatedHash] = await Promise.all([sourceHash(root), executableSourceHash(root), generatedSourceHash(root)]);
    const document = { ...snapshot.document, baseSourceHash:hash, updatedAt:new Date().toISOString(), updatedBy:'codex' };
    const now = new Date().toISOString();
    const state = {
      ...snapshot.storedState,
      baseSourceHash:hash,
      currentSourceHash:hash,
      previewRevision:Number(snapshot.document.revision || 0),
      previewStatus:'applied',
      previewCoverage:'complete',
      previewBlockedTargets:[],
      previewIssue:null,
      previewUpdatedAt:now,
      previewSourceHash:previewHash,
      previewGeneratedHash:generatedHash,
      state:'clean',
      lastWriter:'codex',
      updatedAt:now,
    };
    await atomicWriteBundle(paths.transaction, [
      { file:paths.document, value:document },
      { file:paths.state, value:state },
    ]);
    const next = await readSyncSnapshot(root);
    return json(response, 200, { document, status:publicStatus(next) });
  }
  return json(response, 404, { error:'not_found' });
}

async function serveStatic(response, url) {
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === '/') pathname = '/studio.html';
  const file = path.resolve(root, `.${pathname}`);
  if (file !== root && !file.startsWith(`${root}${path.sep}`)) return json(response, 403, { error:'forbidden' });
  try {
    const content = await readFile(file);
    response.writeHead(200, { 'Content-Type':types[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control':'no-cache', 'X-Content-Type-Options':'nosniff' });
    response.end(content);
  } catch (error) {
    if (error.code === 'ENOENT' || error.code === 'EISDIR') return json(response, 404, { error:'not_found' });
    throw error;
  }
}

await ensureSyncProject(root);
const server = http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url, `http://${request.headers.host || `${host}:${port}`}`);
    if (url.pathname === '/__ui_sync/ocr') await handleAPI(request, response, url);
    else if (url.pathname.startsWith('/__ui_sync/')) await withProjectOperationLock(() => handleAPI(request, response, url));
    else await serveStatic(response, url);
  } catch (error) {
    json(response, error.status || 500, { error:'server_error', message:error.message });
  }
});
server.listen(port, host, () => console.log(`UI Studio bridge: http://${host}:${port}/studio.html`));
