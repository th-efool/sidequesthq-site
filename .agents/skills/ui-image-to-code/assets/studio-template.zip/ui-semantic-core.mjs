const CONTAINER_TYPES = new Set(['page', 'section', 'frame', 'container']);
const TEXT_TAGS = new Set(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span', 'strong', 'small', 'label', 'b', 'i', 'em', 'code']);
const CONTROL_TAGS = new Set(['button', 'input', 'textarea', 'select', 'option']);

const clamp = (value, minimum, maximum) => Math.min(maximum, Math.max(minimum, value));
const finite = (value) => Number.isFinite(Number(value));
const area = (box) => Math.max(0, Number(box?.width || 0)) * Math.max(0, Number(box?.height || 0));
const centerX = (box) => Number(box.x) + Number(box.width) / 2;
const centerY = (box) => Number(box.y) + Number(box.height) / 2;

function safeId(value, fallback = 'candidate') {
  const normalized = String(value || fallback).replace(/[^A-Za-z0-9_.:-]/g, '-').replace(/-+/g, '-').slice(0, 140);
  return normalized || fallback;
}

function normalizedBounds(raw) {
  if (!raw) return null;
  if (Array.isArray(raw) && raw.length >= 4 && raw.slice(0, 4).every(finite)) {
    const [x, y, width, height] = raw.map(Number);
    return width > 0 && height > 0 ? { x, y, width, height } : null;
  }
  if (Array.isArray(raw) && raw.length >= 2 && raw.every((point) => Array.isArray(point) || (point && typeof point === 'object'))) {
    const points = raw.map((point) => Array.isArray(point) ? { x:Number(point[0]), y:Number(point[1]) } : { x:Number(point.x), y:Number(point.y) }).filter((point) => finite(point.x) && finite(point.y));
    if (points.length < 2) return null;
    const xs = points.map((point) => point.x);
    const ys = points.map((point) => point.y);
    return { x:Math.min(...xs), y:Math.min(...ys), width:Math.max(...xs) - Math.min(...xs), height:Math.max(...ys) - Math.min(...ys) };
  }
  if (typeof raw === 'object') {
    if (Array.isArray(raw.vertices)) return normalizedBounds(raw.vertices);
    if (finite(raw.x) && finite(raw.y) && finite(raw.width) && finite(raw.height)) {
      const box = { x:Number(raw.x), y:Number(raw.y), width:Number(raw.width), height:Number(raw.height) };
      return box.width > 0 && box.height > 0 ? box : null;
    }
    if ([raw.left, raw.top, raw.right, raw.bottom].every(finite)) {
      const box = { x:Number(raw.left), y:Number(raw.top), width:Number(raw.right) - Number(raw.left), height:Number(raw.bottom) - Number(raw.top) };
      return box.width > 0 && box.height > 0 ? box : null;
    }
  }
  return null;
}

function ocrRows(payload) {
  if (Array.isArray(payload)) return payload;
  if (!payload || typeof payload !== 'object') return [];
  if (Array.isArray(payload.blocks)) return payload.blocks;
  if (Array.isArray(payload.data)) return payload.data;
  if (Array.isArray(payload.result)) return payload.result;
  if (Array.isArray(payload.results)) return payload.results;
  const annotations = payload.textAnnotations || payload.responses?.[0]?.textAnnotations;
  if (Array.isArray(annotations)) return annotations.length > 1 ? annotations.slice(1) : annotations;
  return [];
}

function normalizeOcrText(value) {
  return String(value ?? '').trim().replace(/([\p{Script=Han}])\s+(?=[\p{Script=Han}])/gu, '$1');
}

function normalizeOcrRow(row, index) {
  if (Array.isArray(row) && Array.isArray(row[0])) {
    const detail = Array.isArray(row[1]) ? row[1] : [];
    const text = normalizeOcrText(detail[0] ?? row.text ?? '');
    const bounds = normalizedBounds(row[0]);
    if (!text || !bounds) return null;
    return { id:`ocr.${index + 1}`, text:text.slice(0, 500), confidence:clamp(Number(detail[1] ?? row.confidence ?? 0.8), 0, 1), bounds };
  }
  if (!row || typeof row !== 'object') return null;
  const text = normalizeOcrText(row.text ?? row.description ?? row.label ?? row.value ?? '');
  const rawBounds = row.bounds ?? row.bbox ?? row.boundingBox ?? row.box ?? row.boundingPoly ?? row.vertices;
  const bounds = normalizedBounds(rawBounds);
  if (!text || !bounds) return null;
  return { id:safeId(row.id || `ocr.${index + 1}`), text:text.slice(0, 500), confidence:clamp(Number(row.confidence ?? row.score ?? row.probability ?? 0.8), 0, 1), bounds };
}

function unionBounds(boxes) {
  const valid = boxes.filter(Boolean);
  if (!valid.length) return null;
  const left = Math.min(...valid.map((box) => Number(box.x)));
  const top = Math.min(...valid.map((box) => Number(box.y)));
  const right = Math.max(...valid.map((box) => Number(box.x) + Number(box.width)));
  const bottom = Math.max(...valid.map((box) => Number(box.y) + Number(box.height)));
  return { x:left, y:top, width:right - left, height:bottom - top };
}

function verticalOverlapRatio(left, right) {
  const overlap = Math.max(0, Math.min(left.y + left.height, right.y + right.height) - Math.max(left.y, right.y));
  return overlap / Math.max(1, Math.min(left.height, right.height));
}

function joinOcrText(left, right) {
  const a = normalizeOcrText(left);
  const b = normalizeOcrText(right);
  if (!a) return b;
  if (!b) return a;
  const noGap = /[\p{Script=Han}]$/u.test(a) && /^[\p{Script=Han}]/u.test(b);
  return `${a}${noGap ? '' : ' '}${b}`;
}

/**
 * Browser OCR adapters often return words while Windows Media OCR returns lines.
 * Coalesce only close, baseline-aligned horizontal fragments so titles and
 * subtitles remain separate editable layers.
 */
export function coalesceOcrBlocks(inputBlocks, options = {}) {
  const normalized = Array.isArray(inputBlocks) && inputBlocks.every((item) => item?.bounds && typeof item?.text === 'string')
    ? inputBlocks.map((item, index) => ({ ...item, id:safeId(item.id || `ocr.${index + 1}`), text:normalizeOcrText(item.text), bounds:{ ...item.bounds }, confidence:clamp(Number(item.confidence ?? 0.8), 0, 1) })).filter((item) => item.text)
    : normalizeOcrPayload(inputBlocks);
  const maximumGapFactor = Math.max(0.35, Number(options.maximumGapFactor ?? 0.9));
  const minimumVerticalOverlap = clamp(Number(options.minimumVerticalOverlap ?? 0.58), 0.35, 0.95);
  const ordered = [...normalized].sort((left, right) => left.bounds.y - right.bounds.y || left.bounds.x - right.bounds.x);
  const rows = [];
  for (const block of ordered) {
    const row = rows
      .map((candidate) => {
        const last = candidate.blocks[candidate.blocks.length - 1];
        const gap = Number(block.bounds.x) - (Number(last.bounds.x) + Number(last.bounds.width));
        const overlap = verticalOverlapRatio(candidate.bounds, block.bounds);
        const centerDistance = Math.abs(centerY(candidate.bounds) - centerY(block.bounds));
        const height = Math.max(1, median([...candidate.blocks, block].map((item) => Number(item.bounds.height))));
        const aligned = overlap >= minimumVerticalOverlap || centerDistance <= Math.max(2, height * 0.28);
        const close = gap >= -height * 0.45 && gap <= Math.max(6, height * maximumGapFactor);
        return { candidate, score:(aligned && close) ? Math.abs(gap) + centerDistance * 0.35 : Number.POSITIVE_INFINITY };
      })
      .sort((left, right) => left.score - right.score)[0];
    if (!row || !Number.isFinite(row.score)) {
      rows.push({ blocks:[block], bounds:{ ...block.bounds } });
      continue;
    }
    row.candidate.blocks.push(block);
    row.candidate.blocks.sort((left, right) => left.bounds.x - right.bounds.x);
    row.candidate.bounds = unionBounds(row.candidate.blocks.map((item) => item.bounds));
  }
  return rows.map((row, index) => {
    const blocks = [...row.blocks].sort((left, right) => left.bounds.x - right.bounds.x);
    const weight = blocks.reduce((sum, item) => sum + Math.max(1, String(item.text).length), 0);
    return {
      id:safeId(blocks.map((item) => item.id).join('+') || `ocr.line.${index + 1}`),
      text:blocks.reduce((value, item) => joinOcrText(value, item.text), ''),
      confidence:Number((blocks.reduce((sum, item) => sum + Number(item.confidence || 0) * Math.max(1, String(item.text).length), 0) / Math.max(1, weight)).toFixed(3)),
      bounds:unionBounds(blocks.map((item) => item.bounds)),
      sourceBlockIds:blocks.map((item) => item.id),
    };
  });
}

export function normalizeOcrPayload(input) {
  let payload = input;
  if (typeof input === 'string') payload = JSON.parse(input);
  return ocrRows(payload).slice(0, 1000).map(normalizeOcrRow).filter(Boolean);
}

const SYSTEM_OVERLAY_TEXT = /(?:激活\s*Windows|转到.*设置.*激活.*Windows|activate\s+windows|go to settings to activate windows)/i;
const ADDRESS_BAR_TEXT = /^(?:https?:\/\/|www\.)\S+$/i;

/**
 * Keep browser chrome and operating-system overlays out of the generated UI.
 * The detector stays deliberately conservative: URL-like text is rejected only
 * near the screenshot's top edge, while known system watermark phrases are
 * rejected wherever they appear.
 */
export function screenOcrContamination(inputBlocks, options = {}) {
  const blocks = Array.isArray(inputBlocks) && inputBlocks.every((item) => item?.bounds && typeof item?.text === 'string')
    ? inputBlocks
    : normalizeOcrPayload(inputBlocks);
  const width = Math.max(1, Number(options.width || 0));
  const height = Math.max(1, Number(options.height || 0));
  const topChromeLimit = Math.max(72, height * 0.09);
  const clean = [];
  const rejected = [];
  for (const block of blocks) {
    const text = String(block.text || '').trim();
    let reason = '';
    const bottomRightWindows = /windows/i.test(text)
      && Number(block.bounds?.x || 0) >= width * 0.62
      && Number(block.bounds?.y || 0) >= height * 0.78;
    if (SYSTEM_OVERLAY_TEXT.test(text) || bottomRightWindows) reason = 'system-overlay';
    else if (ADDRESS_BAR_TEXT.test(text) && Number(block.bounds?.y || 0) <= topChromeLimit) reason = 'browser-address-bar';
    if (reason) rejected.push({ ...block, contaminationReason:reason });
    else clean.push(block);
  }
  return { clean, rejected, metrics:{ input:blocks.length, clean:clean.length, rejected:rejected.length } };
}

function intersectionOverUnion(left, right) {
  const x1 = Math.max(left.x, right.x);
  const y1 = Math.max(left.y, right.y);
  const x2 = Math.min(left.x + left.width, right.x + right.width);
  const y2 = Math.min(left.y + left.height, right.y + right.height);
  const intersection = Math.max(0, x2 - x1) * Math.max(0, y2 - y1);
  return intersection / Math.max(1, area(left) + area(right) - intersection);
}

function contains(outer, inner, margin = 0) {
  return outer.x - margin <= inner.x && outer.y - margin <= inner.y && outer.x + outer.width + margin >= inner.x + inner.width && outer.y + outer.height + margin >= inner.y + inner.height;
}

function nearestContainer(nodes, bounds, ignoredId = null) {
  return nodes.filter((node) => node.id !== ignoredId && CONTAINER_TYPES.has(node.type) && area(node.bounds) > area(bounds) * 1.05 && contains(node.bounds, bounds, 2)).sort((left, right) => area(left.bounds) - area(right.bounds))[0] || null;
}

function evidenceSources(node) {
  const sources = new Set(Array.isArray(node?.evidenceSources) ? node.evidenceSources : []);
  String(node?.source || '').split(/[+,]/).map((item) => item.trim()).filter(Boolean).forEach((item) => sources.add(item));
  if (node?.ocr) sources.add('ocr');
  if (node?.sourceNodeId || node?.semantic?.sourceNodeId) sources.add('production-dom');
  if (node?.layoutHint || node?.componentHint) sources.add('layout');
  if (node?.humanConfirmed) sources.add('human');
  return [...sources];
}

const EDGE_TARGET_TYPES = new Set(['page', 'section', 'frame', 'container', 'control', 'image']);

function axisOverlap(startA, lengthA, startB, lengthB) {
  return Math.max(0, Math.min(startA + lengthA, startB + lengthB) - Math.max(startA, startB));
}

function closestEdgeDistance(value, bounds, axis) {
  const start = Number(bounds[axis] || 0);
  const length = Number(bounds[axis === 'x' ? 'width' : 'height'] || 0);
  return Math.min(Math.abs(value - start), Math.abs(value - (start + length)));
}

function coveredLength(intervals) {
  const ordered = intervals.filter((item) => item[1] > item[0]).sort((left, right) => left[0] - right[0]);
  if (!ordered.length) return 0;
  let total = 0;
  let [start, end] = ordered[0];
  for (const [nextStart, nextEnd] of ordered.slice(1)) {
    if (nextStart <= end) end = Math.max(end, nextEnd);
    else { total += end - start; start = nextStart; end = nextEnd; }
  }
  return total + end - start;
}

/**
 * Suppress pixel-only border fragments only when an exact production DOM edge
 * explains them. Thinness by itself is never enough: this keeps genuine visual
 * dividers in the review queue while removing duplicate screenshot evidence.
 */
export function markCoveredPixelEdges(inputNodes, options = {}) {
  const nodes = structuredClone(Array.isArray(inputNodes) ? inputNodes : []);
  const tolerance = Math.max(1, Number(options.tolerance ?? 6));
  const maximumThickness = Math.max(1, Number(options.maximumThickness ?? 12));
  const minimumLength = Math.max(16, Number(options.minimumLength ?? 56));
  const minimumOverlap = clamp(Number(options.minimumOverlap ?? 0.72), 0.5, 1);
  const targetPool = [...nodes, ...structuredClone(Array.isArray(options.evidenceNodes) ? options.evidenceNodes : [])];
  const exactTargets = targetPool.filter((node) =>
    (node.sourceNodeId || node.semantic?.sourceNodeId || evidenceSources(node).includes('production-dom'))
    && EDGE_TARGET_TYPES.has(node.type)
    && node.bounds
  );
  let absorbedEdgeArtifacts = 0;

  for (const node of nodes) {
    if (!node?.bounds || node.humanConfirmed || !['divider', 'unknown'].includes(node.type)) continue;
    const sources = evidenceSources(node);
    if (sources.includes('production-dom') || sources.includes('ocr') || sources.includes('human')) continue;
    const width = Math.max(0, Number(node.bounds.width || 0));
    const height = Math.max(0, Number(node.bounds.height || 0));
    const horizontal = width >= minimumLength && height <= maximumThickness && width >= height * 6;
    const vertical = height >= minimumLength && width <= maximumThickness && height >= width * 6;
    if (!horizontal && !vertical) continue;

    const candidateCenter = horizontal
      ? Number(node.bounds.y) + height / 2
      : Number(node.bounds.x) + width / 2;
    let match = exactTargets
      .filter((target) => target.id !== node.id)
      .map((target) => {
        const overlap = horizontal
          ? axisOverlap(Number(node.bounds.x), width, Number(target.bounds.x), Number(target.bounds.width)) / Math.max(1, width)
          : axisOverlap(Number(node.bounds.y), height, Number(target.bounds.y), Number(target.bounds.height)) / Math.max(1, height);
        const distance = closestEdgeDistance(candidateCenter, target.bounds, horizontal ? 'y' : 'x');
        return { target, overlap, distance };
      })
      .filter((item) => item.overlap >= minimumOverlap && item.distance <= tolerance + (horizontal ? height : width) / 2)
      .sort((left, right) => left.distance - right.distance || right.overlap - left.overlap)[0];
    if (!match) {
      const longStart = Number(node.bounds[horizontal ? 'x' : 'y']);
      const longLength = horizontal ? width : height;
      const aligned = exactTargets
        .filter((target) => target.id !== node.id)
        .map((target) => {
          const targetStart = Number(target.bounds[horizontal ? 'x' : 'y']);
          const targetLength = Number(target.bounds[horizontal ? 'width' : 'height']);
          return {
            target,
            distance:closestEdgeDistance(candidateCenter, target.bounds, horizontal ? 'y' : 'x'),
            interval:[Math.max(longStart, targetStart), Math.min(longStart + longLength, targetStart + targetLength)],
          };
        })
        .filter((item) => item.distance <= tolerance + (horizontal ? height : width) / 2 && item.interval[1] > item.interval[0]);
      const unionOverlap = coveredLength(aligned.map((item) => item.interval)) / Math.max(1, longLength);
      if (unionOverlap >= minimumOverlap) {
        const nearest = aligned.sort((left, right) => left.distance - right.distance)[0];
        match = { target:nearest.target, distance:nearest.distance, overlap:unionOverlap, targets:aligned.map((item) => item.target) };
      }
    }
    if (!match) continue;

    node.quality = {
      level:'absorbed-edge',
      reason:'covered-by-dom-edge',
      recommendation:'exclude',
      confidence:Number(Math.min(0.999, 0.94 + match.overlap * 0.05).toFixed(3)),
      targetId:match.target.id,
      targetIds:[...new Set((match.targets || [match.target]).map((target) => target.id))],
      sourceNodeId:match.target.sourceNodeId || match.target.semantic?.sourceNodeId || '',
      orientation:horizontal ? 'horizontal' : 'vertical',
      distance:Number(match.distance.toFixed(2)),
      overlap:Number(match.overlap.toFixed(3)),
    };
    absorbedEdgeArtifacts += 1;
  }
  return { nodes, metrics:{ absorbedEdgeArtifacts } };
}

function compatibleTypes(left, right) {
  if (left === right || left === 'unknown' || right === 'unknown') return true;
  return CONTAINER_TYPES.has(left) && CONTAINER_TYPES.has(right);
}

function candidateMatchScore(candidate, evidence) {
  if (!candidate?.bounds || !evidence?.bounds || !compatibleTypes(candidate.type, evidence.type)) return -1;
  const iou = intersectionOverUnion(candidate.bounds, evidence.bounds);
  const evidenceCenter = { x:centerX(evidence.bounds), y:centerY(evidence.bounds), width:1, height:1 };
  const candidateCenter = { x:centerX(candidate.bounds), y:centerY(candidate.bounds), width:1, height:1 };
  const mutualCenter = contains(candidate.bounds, evidenceCenter, 2) && contains(evidence.bounds, candidateCenter, 2);
  const typeBonus = candidate.type === evidence.type ? 0.18 : 0.06;
  const sourceBonus = evidence.source === 'production-dom' ? 0.12 : evidence.ocr ? 0.08 : 0;
  return iou + (mutualCenter ? 0.22 : 0) + typeBonus + sourceBonus;
}

function mergedConfidence(left, right) {
  const a = clamp(Number(left || 0), 0, 1);
  const b = clamp(Number(right || 0), 0, 1);
  return Number((1 - (1 - a) * (1 - b)).toFixed(3));
}

function mergeEvidenceIntoCandidate(candidate, evidence) {
  const exactDom = evidence.source === 'production-dom';
  const previousSources = evidenceSources(candidate);
  const incomingSources = evidenceSources(evidence);
  candidate.evidenceSources = [...new Set([...previousSources, ...incomingSources])];
  candidate.confidence = exactDom ? Math.max(0.995, Number(evidence.confidence || 0)) : mergedConfidence(candidate.confidence, evidence.confidence);
  candidate.source = candidate.evidenceSources.join('+');
  candidate.fusion = {
    matchedEvidenceIds:[...new Set([...(candidate.fusion?.matchedEvidenceIds || []), evidence.id])],
    sourceCount:candidate.evidenceSources.length,
  };
  if (exactDom) {
    candidate.type = evidence.type;
    candidate.name = evidence.name || candidate.name;
    candidate.bounds = { ...evidence.bounds };
    candidate.sourceNodeId = evidence.sourceNodeId || evidence.semantic?.sourceNodeId;
    candidate.semantic = evidence.semantic ? { ...evidence.semantic } : candidate.semantic;
    candidate.layout = evidence.layout ? structuredClone(evidence.layout) : candidate.layout;
    if (evidence.content?.text) candidate.content = { ...candidate.content, ...evidence.content };
    candidate.quality = { level:'verified', reason:'production-dom', recommendation:'accept', confidence:0.995 };
  } else {
    if (candidate.type === 'unknown' && evidence.type !== 'unknown') candidate.type = evidence.type;
    if (evidence.content?.text) candidate.content = { ...candidate.content, ...evidence.content };
    if (evidence.ocr) candidate.ocr = structuredClone(evidence.ocr);
    if (evidence.ocr && Number(evidence.ocr.confidence || evidence.confidence || 0) >= 0.8) candidate.quality = { level:'verified', reason:'ocr-text', recommendation:'accept', confidence:Number(evidence.ocr.confidence || evidence.confidence || 0) };
  }
}

function uniqueEvidenceId(nodes, requestedId) {
  const used = new Set(nodes.map((node) => node.id));
  const base = safeId(requestedId || 'analysis.evidence');
  if (!used.has(base)) return base;
  let suffix = 2;
  while (used.has(`${base}.${suffix}`)) suffix += 1;
  return `${base}.${suffix}`;
}

function repairParentGraph(nodes) {
  const byId = new Map(nodes.map((node) => [node.id, node]));
  const page = nodes.find((node) => node.type === 'page') || null;
  let repairs = 0;
  for (const node of nodes) {
    if (node.type === 'page') {
      if (node.parentId) { node.parentId = null; repairs += 1; }
      continue;
    }
    const current = byId.get(node.parentId);
    const suggested = nearestContainer(nodes, node.bounds, node.id);
    const currentIsValid = current
      && current.id !== node.id
      && CONTAINER_TYPES.has(current.type)
      && contains(current.bounds, node.bounds, Math.max(2, Math.min(node.bounds.width, node.bounds.height) * 0.04));
    const protectedParent = node.humanConfirmed || evidenceSources(node).includes('production-dom');
    const hasMoreSpecificParent = suggested
      && current
      && suggested.id !== current.id
      && area(suggested.bounds) < area(current.bounds) * 0.92;
    if (!currentIsValid || (!protectedParent && hasMoreSpecificParent)) {
      node.parentId = suggested?.id || page?.id || null;
      repairs += 1;
    }
  }
  for (const node of nodes) {
    const visited = new Set([node.id]);
    let cursor = node.parentId;
    while (cursor && byId.has(cursor)) {
      if (visited.has(cursor)) {
        node.parentId = page && page.id !== node.id ? page.id : null;
        repairs += 1;
        break;
      }
      visited.add(cursor);
      cursor = byId.get(cursor)?.parentId;
    }
  }
  return repairs;
}

export function fuseEvidenceCandidates(inputNodes, inputEvidenceNodes, options = {}) {
  const nodes = structuredClone(Array.isArray(inputNodes) ? inputNodes : []);
  const evidenceNodes = structuredClone(Array.isArray(inputEvidenceNodes) ? inputEvidenceNodes : []);
  const minimumScore = Number(options.minimumScore || 0.34);
  const matchedCandidateIds = new Set();
  const evidenceIdMap = new Map();
  const evidenceParentLinks = [];
  let matched = 0;
  let added = 0;
  let deduplicated = 0;

  for (const evidence of evidenceNodes) {
    const match = nodes
      .filter((candidate) => !matchedCandidateIds.has(candidate.id))
      .map((candidate) => ({ candidate, score:candidateMatchScore(candidate, evidence) }))
      .sort((left, right) => right.score - left.score)[0];
    if (match && match.score >= minimumScore) {
      mergeEvidenceIntoCandidate(match.candidate, evidence);
      matchedCandidateIds.add(match.candidate.id);
      evidenceIdMap.set(evidence.id, match.candidate.id);
      evidenceParentLinks.push({ targetId:match.candidate.id, evidenceParentId:evidence.parentId });
      matched += 1;
    } else {
      const originalEvidenceId = evidence.id;
      evidence.id = uniqueEvidenceId(nodes, evidence.id);
      evidence.evidenceSources = evidenceSources(evidence);
      evidence.fusion = { matchedEvidenceIds:[evidence.id], sourceCount:evidence.evidenceSources.length };
      nodes.push(evidence);
      evidenceIdMap.set(originalEvidenceId, evidence.id);
      evidenceParentLinks.push({ targetId:evidence.id, evidenceParentId:evidence.parentId });
      added += 1;
    }
  }

  evidenceParentLinks.forEach(({ targetId, evidenceParentId }) => {
    if (!evidenceParentId || !evidenceIdMap.has(evidenceParentId)) return;
    const target = nodes.find((node) => node.id === targetId);
    if (target) target.parentId = evidenceIdMap.get(evidenceParentId);
  });

  const removedIds = new Set();
  for (let leftIndex = 0; leftIndex < nodes.length; leftIndex += 1) {
    const left = nodes[leftIndex];
    if (removedIds.has(left.id)) continue;
    for (let rightIndex = leftIndex + 1; rightIndex < nodes.length; rightIndex += 1) {
      const right = nodes[rightIndex];
      if (removedIds.has(right.id) || !compatibleTypes(left.type, right.type)) continue;
      if (intersectionOverUnion(left.bounds, right.bounds) < 0.88) continue;
      const leftStrength = evidenceSources(left).length + (left.sourceNodeId ? 3 : 0) + Number(left.confidence || 0);
      const rightStrength = evidenceSources(right).length + (right.sourceNodeId ? 3 : 0) + Number(right.confidence || 0);
      const keeper = leftStrength >= rightStrength ? left : right;
      const duplicate = keeper === left ? right : left;
      mergeEvidenceIntoCandidate(keeper, duplicate);
      removedIds.add(duplicate.id);
      nodes.forEach((node) => { if (node.parentId === duplicate.id) node.parentId = keeper.id; });
      deduplicated += 1;
    }
  }

  const kept = nodes.filter((node) => !removedIds.has(node.id));
  const parentRepairs = repairParentGraph(kept);
  const inferred = inferSemanticStructure(kept);
  return {
    nodes:inferred.nodes,
    metrics:{ evidenceMatched:matched, evidenceAdded:added, evidenceDeduplicated:deduplicated, parentRepairs, ...inferred.metrics },
  };
}

export function mergeCandidatePair(inputNodes, primaryId, secondaryId) {
  const nodes = structuredClone(Array.isArray(inputNodes) ? inputNodes : []);
  const primary = nodes.find((node) => node.id === primaryId);
  const secondary = nodes.find((node) => node.id === secondaryId);
  if (!primary || !secondary || primary.id === secondary.id || primary.type === 'page' || secondary.type === 'page') {
    return { nodes, merged:false, primaryId:null, removedId:null, parentRepairs:0 };
  }
  const ordered = [primary, secondary].sort((left, right) => {
    const sameLine = verticalOverlapRatio(left.bounds, right.bounds) >= 0.55;
    return sameLine ? left.bounds.x - right.bounds.x : left.bounds.y - right.bounds.y;
  });
  primary.bounds = unionBounds([primary.bounds, secondary.bounds]);
  primary.confidence = mergedConfidence(primary.confidence, secondary.confidence);
  primary.evidenceSources = [...new Set([...evidenceSources(primary), ...evidenceSources(secondary), 'human'])];
  primary.source = primary.evidenceSources.join('+');
  primary.humanConfirmed = true;
  primary.reviewState = 'review';
  primary.accepted = false;
  primary.fusion = {
    ...(primary.fusion || {}),
    mergedCandidateIds:[...new Set([...(primary.fusion?.mergedCandidateIds || []), secondary.id, ...(secondary.fusion?.mergedCandidateIds || [])])],
    sourceCount:primary.evidenceSources.length,
  };
  if (primary.type === 'unknown' && secondary.type !== 'unknown') primary.type = secondary.type;
  if (primary.type === 'text' || secondary.type === 'text') {
    const text = ordered.reduce((value, node) => joinOcrText(value, node.content?.text || node.name || ''), '');
    primary.type = 'text';
    primary.name = text.slice(0, 120) || primary.name;
    primary.content = { ...(primary.content || {}), text, status:'human-merged' };
  }
  if (primary.parentId === secondary.id) primary.parentId = secondary.parentId || null;
  nodes.forEach((node) => { if (node.parentId === secondary.id) node.parentId = primary.id; });
  const kept = nodes.filter((node) => node.id !== secondary.id);
  const parentRepairs = repairParentGraph(kept);
  return { nodes:kept, merged:true, primaryId:primary.id, removedId:secondary.id, parentRepairs };
}

function splitTextValue(value) {
  const text = String(value || '').trim();
  if (text.length < 2) return [text, ''];
  const center = Math.floor(text.length / 2);
  const boundaries = [...text.matchAll(/\s+/g)].map((match) => match.index).filter((index) => index > 0 && index < text.length);
  const boundary = boundaries.sort((left, right) => Math.abs(left - center) - Math.abs(right - center))[0] ?? center;
  return [text.slice(0, boundary).trim(), text.slice(boundary).trim()];
}

export function splitCandidate(inputNodes, candidateId, options = {}) {
  const nodes = structuredClone(Array.isArray(inputNodes) ? inputNodes : []);
  const selected = nodes.find((node) => node.id === candidateId);
  if (!selected || selected.type === 'page' || Math.max(selected.bounds?.width || 0, selected.bounds?.height || 0) < 24) {
    return { nodes, split:false, createdIds:[] };
  }
  const axis = options.axis === 'x' || options.axis === 'y' ? options.axis : selected.bounds.width >= selected.bounds.height ? 'x' : 'y';
  const children = nodes.filter((node) => node.parentId === selected.id);
  const centers = children.map((node) => axis === 'x' ? centerX(node.bounds) : centerY(node.bounds)).sort((left, right) => left - right);
  let splitAt = Number(selected.bounds[axis]) + Number(selected.bounds[axis === 'x' ? 'width' : 'height']) / 2;
  if (centers.length >= 2) {
    let bestGap = -1;
    for (let index = 1; index < centers.length; index += 1) {
      const gap = centers[index] - centers[index - 1];
      if (gap > bestGap) { bestGap = gap; splitAt = (centers[index] + centers[index - 1]) / 2; }
    }
  }
  const minimum = Number(selected.bounds[axis]) + 1;
  const maximum = Number(selected.bounds[axis]) + Number(selected.bounds[axis === 'x' ? 'width' : 'height']) - 1;
  splitAt = clamp(splitAt, minimum, maximum);
  const first = structuredClone(selected);
  const second = structuredClone(selected);
  first.id = uniqueEvidenceId(nodes, `${selected.id}.split.a`);
  second.id = uniqueEvidenceId([...nodes, first], `${selected.id}.split.b`);
  first.name = `${selected.name} A`;
  second.name = `${selected.name} B`;
  const sizeKey = axis === 'x' ? 'width' : 'height';
  first.bounds[sizeKey] = splitAt - Number(selected.bounds[axis]);
  second.bounds[axis] = splitAt;
  second.bounds[sizeKey] = Number(selected.bounds[axis]) + Number(selected.bounds[sizeKey]) - splitAt;
  const splitText = splitTextValue(selected.content?.text);
  [first, second].forEach((node, index) => {
    node.accepted = false;
    node.reviewState = 'review';
    node.humanConfirmed = true;
    node.evidenceSources = [...new Set([...evidenceSources(node), 'human'])];
    node.source = node.evidenceSources.join('+');
    node.splitFrom = selected.id;
    if (selected.type === 'text') {
      node.content = { ...(node.content || {}), text:splitText[index], status:'human-split' };
      node.name = splitText[index] || node.name;
    }
  });
  for (const child of children) {
    const coordinate = axis === 'x' ? centerX(child.bounds) : centerY(child.bounds);
    child.parentId = coordinate < splitAt ? first.id : second.id;
  }
  const selectedIndex = nodes.findIndex((node) => node.id === selected.id);
  nodes.splice(selectedIndex, 1, first, second);
  repairParentGraph(nodes);
  return { nodes, split:true, createdIds:[first.id, second.id], axis, splitAt:Number(splitAt.toFixed(2)) };
}

function conflictIdentity(leftId, rightId) {
  return `conflict:${[String(leftId), String(rightId)].sort().join('|')}`;
}

function hasConflictResolution(node, conflictId) {
  return Boolean(node?.conflictResolutions?.[conflictId]?.action);
}

function compatibleConflictTypes(left, right) {
  if (left.type === right.type) return true;
  return CONTAINER_TYPES.has(left.type) && CONTAINER_TYPES.has(right.type);
}

function strongEvidenceCount(node) {
  return evidenceSources(node).filter((source) => ['production-dom', 'ocr', 'human', 'layout'].includes(source)).length;
}

/**
 * Explain same-parent overlap instead of exposing a bare IoU number. Resolved
 * pairs are omitted so a deliberate “keep both” decision survives re-analysis.
 */
export function diagnoseCandidateConflicts(inputNodes) {
  const nodes = Array.isArray(inputNodes) ? inputNodes : [];
  const conflicts = [];
  for (let leftIndex = 0; leftIndex < nodes.length; leftIndex += 1) {
    const left = nodes[leftIndex];
    if (left.type === 'page' || left.reviewState === 'excluded') continue;
    for (let rightIndex = leftIndex + 1; rightIndex < nodes.length; rightIndex += 1) {
      const right = nodes[rightIndex];
      if (right.type === 'page' || right.reviewState === 'excluded' || left.parentId !== right.parentId) continue;
      const iou = intersectionOverUnion(left.bounds, right.bounds);
      if (iou < 0.72 || contains(left.bounds, right.bounds, 1) || contains(right.bounds, left.bounds, 1)) continue;
      const id = conflictIdentity(left.id, right.id);
      if (hasConflictResolution(left, id) || hasConflictResolution(right, id)) continue;
      const compatible = compatibleConflictTypes(left, right);
      const protectedByHuman = Boolean(left.humanConfirmed || right.humanConfirmed);
      const leftSources = evidenceSources(left);
      const rightSources = evidenceSources(right);
      const leftStrength = strongEvidenceCount(left);
      const rightStrength = strongEvidenceCount(right);
      const leftWeak = leftStrength === 0 && Number(left.confidence || 0) < 0.72;
      const rightWeak = rightStrength === 0 && Number(right.confidence || 0) < 0.72;
      let kind = compatible && iou >= 0.84 ? 'probable-duplicate' : left.type === 'text' && right.type === 'text' ? 'text-overlap' : 'layout-overlap';
      let recommendedAction = 'review';
      let weakerId = null;
      let reasonCode = kind;
      if (protectedByHuman) {
        recommendedAction = 'keep-both';
        reasonCode = 'human-protected';
      } else if (leftWeak !== rightWeak) {
        weakerId = leftWeak ? left.id : right.id;
        recommendedAction = leftWeak ? 'exclude-left' : 'exclude-right';
        reasonCode = 'weak-single-source-overlap';
      } else if (compatible && iou >= 0.84) {
        recommendedAction = 'merge';
        reasonCode = 'probable-duplicate';
      } else if (!compatible) {
        recommendedAction = 'keep-both';
        reasonCode = 'different-semantic-types';
      }
      conflicts.push({
        id,
        leftId:left.id,
        rightId:right.id,
        parentId:left.parentId || null,
        kind,
        severity:recommendedAction === 'merge' || weakerId ? 'blocker' : 'warning',
        iou:Number(iou.toFixed(3)),
        recommendedAction,
        weakerId,
        reasonCode,
        protectedByHuman,
        evidence:{ left:leftSources, right:rightSources },
      });
    }
  }
  return conflicts.sort((left, right) => (left.severity === right.severity ? right.iou - left.iou : left.severity === 'blocker' ? -1 : 1));
}

export function auditCandidateGraph(inputNodes) {
  const nodes = Array.isArray(inputNodes) ? inputNodes : [];
  const byId = new Map(nodes.map((node) => [node.id, node]));
  const missingParents = [];
  const cycles = [];
  const missingText = [];
  const overlapConflicts = diagnoseCandidateConflicts(nodes);
  for (const node of nodes) {
    if (node.type !== 'page' && (!node.parentId || !byId.has(node.parentId))) missingParents.push(node.id);
    if (node.type === 'text' && !String(node.content?.text || '').trim()) missingText.push(node.id);
    const visited = new Set([node.id]);
    let cursor = node.parentId;
    while (cursor && byId.has(cursor)) {
      if (visited.has(cursor)) { cycles.push(node.id); break; }
      visited.add(cursor);
      cursor = byId.get(cursor)?.parentId;
    }
  }
  return {
    nodeCount:nodes.length,
    missingParents,
    cycles:[...new Set(cycles)],
    missingText,
    overlapConflicts,
    valid:missingParents.length === 0 && cycles.length === 0,
  };
}

export function mergeOcrBlocks(inputNodes, inputBlocks, options = {}) {
  const nodes = structuredClone(Array.isArray(inputNodes) ? inputNodes : []);
  const rawBlocks = Array.isArray(inputBlocks) && inputBlocks.every((item) => item?.bounds && typeof item?.text === 'string') ? inputBlocks : normalizeOcrPayload(inputBlocks);
  const blocks = coalesceOcrBlocks(rawBlocks, options.coalesce || {});
  const usedIds = new Set(nodes.map((node) => node.id));
  const matchedNodeIds = new Set();
  const prefix = safeId(options.idPrefix || 'analysis.ocr');
  let matched = 0;
  let created = 0;
  for (const block of blocks) {
    const candidates = nodes.filter((node) => node.type === 'text' && !matchedNodeIds.has(node.id)).map((node) => {
      const iou = intersectionOverUnion(node.bounds, block.bounds);
      const centerInside = contains(node.bounds, { x:centerX(block.bounds), y:centerY(block.bounds), width:1, height:1 }, Math.max(2, block.bounds.height * 0.35));
      return { node, score:iou + (centerInside ? 0.24 : 0) };
    }).sort((left, right) => right.score - left.score);
    const match = candidates[0]?.score >= 0.18 ? candidates[0].node : null;
    if (match) {
      matchedNodeIds.add(match.id);
      match.name = block.text.slice(0, 120);
      match.content = { ...(match.content || {}), text:block.text, status:'ocr-observed' };
      match.confidence = Number(Math.max(Number(match.confidence || 0), 0.62 + block.confidence * 0.36).toFixed(3));
      match.ocr = { confidence:block.confidence, bounds:{ ...block.bounds }, sourceBlockIds:[...(block.sourceBlockIds || [block.id])] };
      match.quality = { level:'verified', reason:'ocr-text', recommendation:block.confidence >= 0.92 ? 'accept' : 'review', confidence:block.confidence };
      match.source = match.source?.includes('ocr') ? match.source : `${match.source || 'pixel-structure'}+ocr`;
      match.accepted = match.accepted || block.confidence >= 0.92;
      matched += 1;
      continue;
    }
    let suffix = created + 1;
    let id = `${prefix}.text.${suffix}`;
    while (usedIds.has(id)) { suffix += 1; id = `${prefix}.text.${suffix}`; }
    usedIds.add(id);
    const parent = nearestContainer(nodes, block.bounds);
    nodes.push({
      id,
      name:block.text.slice(0, 120),
      type:'text',
      parentId:parent?.id || nodes.find((node) => node.type === 'page')?.id || null,
      bounds:{ ...block.bounds },
      confidence:Number((0.58 + block.confidence * 0.4).toFixed(3)),
      source:'ocr-import',
      accepted:block.confidence >= 0.92,
      content:{ text:block.text, status:'ocr-observed' },
      ocr:{ confidence:block.confidence, bounds:{ ...block.bounds }, sourceBlockIds:[...(block.sourceBlockIds || [block.id])] },
      quality:{ level:'verified', reason:'ocr-text', recommendation:block.confidence >= 0.92 ? 'accept' : 'review', confidence:block.confidence },
    });
    created += 1;
  }
  return { nodes, metrics:{ ocrRawBlocks:rawBlocks.length, ocrBlocks:blocks.length, ocrCoalesced:Math.max(0, rawBlocks.length - blocks.length), ocrMatched:matched, ocrCreated:created } };
}

function median(values) {
  if (!values.length) return 0;
  const sorted = [...values].sort((left, right) => left - right);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function clusterBy(items, coordinate, tolerance) {
  const groups = [];
  for (const item of [...items].sort((left, right) => coordinate(left) - coordinate(right))) {
    let group = groups.find((candidate) => Math.abs(candidate.mean - coordinate(item)) <= tolerance);
    if (!group) { group = { mean:coordinate(item), items:[] }; groups.push(group); }
    group.items.push(item);
    group.mean = group.items.reduce((sum, entry) => sum + coordinate(entry), 0) / group.items.length;
  }
  return groups;
}

function adjacentGap(items, axis) {
  if (items.length < 2) return 0;
  const sorted = [...items].sort((left, right) => left.bounds[axis] - right.bounds[axis]);
  const size = axis === 'x' ? 'width' : 'height';
  const gaps = [];
  for (let index = 1; index < sorted.length; index += 1) gaps.push(Math.max(0, sorted[index].bounds[axis] - (sorted[index - 1].bounds[axis] + sorted[index - 1].bounds[size])));
  return Math.round(median(gaps));
}

function inferContainerLayout(children) {
  if (children.length < 2) return null;
  const medianWidth = Math.max(1, median(children.map((node) => node.bounds.width)));
  const medianHeight = Math.max(1, median(children.map((node) => node.bounds.height)));
  const rows = clusterBy(children, (node) => centerY(node.bounds), Math.max(4, medianHeight * 0.55));
  const columns = clusterBy(children, (node) => centerX(node.bounds), Math.max(4, medianWidth * 0.55));
  if (rows.length === 1) return { mode:'flex', direction:'row', gap:adjacentGap(children, 'x'), confidence:0.86, reason:'single-aligned-row' };
  if (columns.length === 1) return { mode:'flex', direction:'column', gap:adjacentGap(children, 'y'), confidence:0.86, reason:'single-aligned-column' };
  if (rows.length >= 2 && columns.length >= 2 && rows.length * columns.length >= children.length * 0.7) {
    return { mode:'grid', columns:columns.length, rows:rows.length, columnGap:Math.round(median(rows.map((row) => adjacentGap(row.items, 'x')))), rowGap:Math.round(median(columns.map((column) => adjacentGap(column.items, 'y')))), confidence:0.78, reason:'repeated-row-column-alignment' };
  }
  return { mode:'free', confidence:0.48, reason:'mixed-alignment' };
}

function dimensionSimilarity(left, right) {
  const width = Math.min(left.bounds.width, right.bounds.width) / Math.max(1, Math.max(left.bounds.width, right.bounds.width));
  const height = Math.min(left.bounds.height, right.bounds.height) / Math.max(1, Math.max(left.bounds.height, right.bounds.height));
  return Math.min(width, height);
}

function repeatAlignment(left, right) {
  const sameColumn = Math.abs(centerX(left.bounds) - centerX(right.bounds)) <= Math.max(6, Math.min(left.bounds.width, right.bounds.width) * 0.14);
  const sameRow = Math.abs(centerY(left.bounds) - centerY(right.bounds)) <= Math.max(6, Math.min(left.bounds.height, right.bounds.height) * 0.2);
  return sameColumn ? 'column' : sameRow ? 'row' : '';
}

function inferRepeatedGroups(nodes) {
  const pools = new Map();
  for (const node of nodes.filter((candidate) => candidate.type !== 'page' && candidate.type !== 'divider')) {
    const key = `${node.parentId || 'root'}|${node.type}`;
    if (!pools.has(key)) pools.set(key, []);
    pools.get(key).push(node);
  }
  const groups = [];
  for (const pool of pools.values()) {
    const remaining = new Set(pool.map((node) => node.id));
    while (remaining.size) {
      const seedId = remaining.values().next().value;
      const component = [];
      const queue = [pool.find((node) => node.id === seedId)];
      remaining.delete(seedId);
      while (queue.length) {
        const current = queue.shift();
        component.push(current);
        for (const candidate of pool) {
          if (!remaining.has(candidate.id)) continue;
          const similarity = dimensionSimilarity(current, candidate);
          const alignment = repeatAlignment(current, candidate);
          if (similarity >= 0.78 && alignment) {
            remaining.delete(candidate.id);
            queue.push(candidate);
          }
        }
      }
      if (component.length >= 3 || (component.length === 2 && dimensionSimilarity(component[0], component[1]) >= 0.92)) groups.push(component);
    }
  }
  return groups;
}

export function inferSemanticStructure(inputNodes) {
  const nodes = structuredClone(Array.isArray(inputNodes) ? inputNodes : []);
  const parentRepairs = repairParentGraph(nodes);
  let inferredLayouts = 0;
  for (const container of nodes.filter((node) => CONTAINER_TYPES.has(node.type))) {
    const children = nodes.filter((node) => node.parentId === container.id && node.type !== 'divider');
    const hint = inferContainerLayout(children);
    if (hint) { container.layoutHint = hint; inferredLayouts += 1; }
  }
  const groups = inferRepeatedGroups(nodes);
  let repeatedGroups = 0;
  let repeatedInstances = 0;
  for (const group of groups) {
    repeatedGroups += 1;
    const componentKey = `repeat.${safeId(group[0].parentId || 'root')}.${group[0].type}.${repeatedGroups}`;
    const ordered = [...group].sort((left, right) => left.bounds.y - right.bounds.y || left.bounds.x - right.bounds.x);
    ordered.forEach((node, index) => {
      if (!node.componentHint?.humanConfirmed) node.componentHint = { key:componentKey, instance:index + 1, count:ordered.length, confidence:0.82, direction:repeatAlignment(ordered[0], ordered[1]) || 'mixed', reason:'sibling-shape-and-alignment' };
    });
    repeatedInstances += ordered.length;
  }
  return { nodes, metrics:{ inferredLayouts, repeatedGroups, repeatedInstances, parentRepairs } };
}

function domType(element) {
  const explicit = String(element.type || '').toLowerCase();
  if (explicit) return explicit;
  const tag = String(element.tag || '').toLowerCase();
  const role = String(element.role || '').toLowerCase();
  if (tag === 'main') return 'page';
  if (tag === 'svg') return 'icon';
  if (tag === 'img' || tag === 'picture' || tag === 'canvas') return 'image';
  if (CONTROL_TAGS.has(tag) || ['button', 'textbox', 'combobox', 'checkbox', 'radio', 'slider'].includes(role)) return 'control';
  if (TEXT_TAGS.has(tag) || element.directText) return 'text';
  if (['nav', 'aside', 'section', 'header', 'footer', 'form'].includes(tag)) return 'section';
  return 'frame';
}

export function normalizeDomSnapshot(inputElements, options = {}) {
  const viewportWidth = Math.max(1, Number(options.viewportWidth || options.sourceWidth || 1));
  const viewportHeight = Math.max(1, Number(options.viewportHeight || options.sourceHeight || 1));
  const sourceWidth = Math.max(1, Number(options.sourceWidth || viewportWidth));
  const sourceHeight = Math.max(1, Number(options.sourceHeight || viewportHeight));
  const scaleX = sourceWidth / viewportWidth;
  const scaleY = sourceHeight / viewportHeight;
  const elements = (Array.isArray(inputElements) ? inputElements : []).slice(0, 2000).filter((element) => element?.id && normalizedBounds(element.bounds));
  const idMap = new Map(elements.map((element) => [String(element.id), `dom.${safeId(element.id)}`]));
  const nodes = elements.map((element) => {
    const type = domType(element);
    const sourceBounds = normalizedBounds(element.bounds);
    const bounds = { x:Math.round(sourceBounds.x * scaleX), y:Math.round(sourceBounds.y * scaleY), width:Math.max(1, Math.round(sourceBounds.width * scaleX)), height:Math.max(1, Math.round(sourceBounds.height * scaleY)) };
    const text = String(element.directText || element.text || '').trim().replace(/\s+/g, ' ').slice(0, 500);
    const display = String(element.display || '').toLowerCase();
    const layoutMode = display.includes('grid') ? 'grid' : display.includes('flex') ? 'flex' : 'flow';
    return {
      id:idMap.get(String(element.id)),
      sourceNodeId:String(element.id),
      name:String(element.name || text || element.id).slice(0, 120),
      type,
      parentId:idMap.get(String(element.parentId || '')) || null,
      bounds,
      confidence:0.995,
      source:'production-dom',
      accepted:true,
      quality:{ level:'verified', reason:'production-dom', recommendation:'accept', confidence:0.995 },
      content:text ? { text, status:'dom-observed' } : {},
      layout:{ mode:layoutMode, direction:String(element.flexDirection || ''), gap:Number.parseFloat(element.gap) || 0 },
      semantic:{ tag:String(element.tag || '').toLowerCase(), role:String(element.role || ''), sourceNodeId:String(element.id) },
    };
  });
  const enriched = inferSemanticStructure(nodes);
  return { nodes:enriched.nodes, metrics:{ domNodes:nodes.length, domTextNodes:nodes.filter((node) => node.type === 'text' && node.content?.text).length, ...enriched.metrics }, sourceSize:{ width:sourceWidth, height:sourceHeight } };
}
