const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));

export const FIDELITY_WEIGHTS = Object.freeze({
  geometry: 25,
  typography: 15,
  assets: 10,
  effects: 10,
  responsive: 15,
  interactions: 10,
  codeQuality: 10,
  editable: 5,
});

export const FIDELITY_LABELS = Object.freeze({
  geometry: '几何与布局',
  typography: '字体与排版',
  assets: '图标与图片',
  effects: '颜色与效果',
  responsive: '响应式',
  interactions: '交互状态',
  codeQuality: '代码质量',
  editable: '结构可编辑性',
});

function validateImageData(image, label) {
  if (!image || !Number.isInteger(image.width) || !Number.isInteger(image.height) || image.width < 1 || image.height < 1) {
    throw new TypeError(`${label} 必须包含有效的 width、height 和 RGBA data`);
  }
  if (!image.data || image.data.length !== image.width * image.height * 4) {
    throw new TypeError(`${label} 的 RGBA data 长度无效`);
  }
}

function summarizeTiles(width, height, deltas, edgeDeltas, columns, rows, threshold) {
  const tiles = [];
  const tileWidth = Math.ceil(width / columns);
  const tileHeight = Math.ceil(height / rows);
  for (let row = 0; row < rows; row += 1) {
    for (let column = 0; column < columns; column += 1) {
      const x = column * tileWidth;
      const y = row * tileHeight;
      const regionWidth = Math.min(tileWidth, width - x);
      const regionHeight = Math.min(tileHeight, height - y);
      if (regionWidth <= 0 || regionHeight <= 0) continue;
      let total = 0;
      let changed = 0;
      let edgeDelta = 0;
      for (let py = y; py < y + regionHeight; py += 1) {
        for (let px = x; px < x + regionWidth; px += 1) {
          const index = py * width + px;
          const delta = deltas[index];
          total += delta;
          if (delta >= threshold) changed += 1;
          edgeDelta += edgeDeltas[index];
        }
      }
      const pixels = regionWidth * regionHeight;
      const meanDelta = total / pixels;
      const changedRatio = changed / pixels;
      const meanEdgeDelta = edgeDelta / pixels;
      tiles.push({
        id: `tile-${row + 1}-${column + 1}`,
        bounds: { x, y, width:regionWidth, height:regionHeight },
        meanDelta: Number(meanDelta.toFixed(3)),
        changedRatio: Number(changedRatio.toFixed(4)),
        severity: Number(clamp((meanDelta / 80) * 0.55 + changedRatio * 0.45).toFixed(4)),
        category: meanEdgeDelta > meanDelta * 1.35 ? 'geometry' : 'color-effects',
      });
    }
  }
  return tiles.sort((a, b) => b.severity - a.severity);
}

export function compareImageData(reference, candidate, options = {}) {
  validateImageData(reference, '参考图');
  validateImageData(candidate, '结果图');
  if (reference.width !== candidate.width || reference.height !== candidate.height) {
    throw new RangeError(`图片尺寸必须一致：参考图 ${reference.width}×${reference.height}，结果图 ${candidate.width}×${candidate.height}`);
  }

  const threshold = Math.max(0, Number(options.threshold ?? 12));
  const heatmap = new Uint8ClampedArray(reference.data.length);
  const deltas = new Float32Array(reference.width * reference.height);
  const edgeDeltas = new Float32Array(reference.width * reference.height);
  const referenceLuma = new Float32Array(reference.width * reference.height);
  const candidateLuma = new Float32Array(reference.width * reference.height);
  let absolute = 0;
  let squared = 0;
  let changed = 0;
  let edgeAbsolute = 0;
  const pixels = reference.width * reference.height;

  for (let index = 0; index < pixels; index += 1) {
      const offset = index * 4;
      const red = Math.abs(reference.data[offset] - candidate.data[offset]);
      const green = Math.abs(reference.data[offset + 1] - candidate.data[offset + 1]);
      const blue = Math.abs(reference.data[offset + 2] - candidate.data[offset + 2]);
      const delta = (red + green + blue) / 3;
      deltas[index] = delta;
      referenceLuma[index] = reference.data[offset] * 0.2126 + reference.data[offset + 1] * 0.7152 + reference.data[offset + 2] * 0.0722;
      candidateLuma[index] = candidate.data[offset] * 0.2126 + candidate.data[offset + 1] * 0.7152 + candidate.data[offset + 2] * 0.0722;
      absolute += delta;
      squared += delta * delta;
      if (delta >= threshold) changed += 1;
      const intensity = Math.round(clamp(delta / 96) * 255);
      heatmap[offset] = intensity;
      heatmap[offset + 1] = Math.round(intensity * 0.18);
      heatmap[offset + 2] = Math.round(255 - intensity * 0.8);
      heatmap[offset + 3] = intensity ? Math.max(72, intensity) : 26;
  }

  for (let y = 0; y < reference.height; y += 1) {
    const topY = Math.max(0, y - 1);
    const bottomY = Math.min(reference.height - 1, y + 1);
    for (let x = 0; x < reference.width; x += 1) {
      const leftX = Math.max(0, x - 1);
      const rightX = Math.min(reference.width - 1, x + 1);
      const index = y * reference.width + x;
      const refEdge = Math.abs(referenceLuma[y * reference.width + rightX] - referenceLuma[y * reference.width + leftX])
        + Math.abs(referenceLuma[bottomY * reference.width + x] - referenceLuma[topY * reference.width + x]);
      const candidateEdge = Math.abs(candidateLuma[y * reference.width + rightX] - candidateLuma[y * reference.width + leftX])
        + Math.abs(candidateLuma[bottomY * reference.width + x] - candidateLuma[topY * reference.width + x]);
      const delta = Math.abs(refEdge - candidateEdge);
      edgeDeltas[index] = delta;
      edgeAbsolute += delta;
    }
  }

  const meanAbsoluteError = absolute / pixels;
  const rmse = Math.sqrt(squared / pixels);
  const edgeError = edgeAbsolute / pixels;
  const pixelSimilarity = clamp(1 - meanAbsoluteError / 255) * 100;
  const edgeSimilarity = clamp(1 - edgeError / 510) * 100;
  const tiles = summarizeTiles(reference.width, reference.height, deltas, edgeDeltas, options.columns || 8, options.rows || 6, threshold);

  return {
    width: reference.width,
    height: reference.height,
    threshold,
    metrics: {
      pixelSimilarity: Number(pixelSimilarity.toFixed(2)),
      edgeSimilarity: Number(edgeSimilarity.toFixed(2)),
      meanAbsoluteError: Number(meanAbsoluteError.toFixed(3)),
      rmse: Number(rmse.toFixed(3)),
      changedPixelRatio: Number((changed / pixels).toFixed(5)),
    },
    heatmap: { width: reference.width, height: reference.height, data: heatmap },
    mismatchQueue: tiles.filter((tile) => tile.severity > 0.005).slice(0, options.maxMismatches || 8),
  };
}

export function computeFidelityGate(scores = {}, criticalFailures = []) {
  let weighted = 0;
  let ratedWeight = 0;
  const normalized = {};
  for (const [key, weight] of Object.entries(FIDELITY_WEIGHTS)) {
    const raw = scores[key];
    const value = raw === '' || raw === null || raw === undefined || !Number.isFinite(Number(raw))
      ? null
      : clamp(Number(raw), 0, 100);
    normalized[key] = value;
    if (value !== null) {
      weighted += value * weight;
      ratedWeight += weight;
    }
  }
  const complete = ratedWeight === 100;
  const provisionalScore = ratedWeight ? weighted / ratedWeight : null;
  const failures = [...new Set((criticalFailures || []).filter(Boolean).map(String))];
  const uncappedScore = complete ? weighted / 100 : null;
  const score = uncappedScore === null ? null : Number(Math.min(uncappedScore, failures.length ? 94 : 100).toFixed(2));
  return {
    score,
    provisionalScore: provisionalScore === null ? null : Number(provisionalScore.toFixed(2)),
    coverage: ratedWeight,
    complete,
    passed: complete && failures.length === 0 && score >= 95,
    criticalCapApplied: complete && failures.length > 0 && uncappedScore >= 95,
    criticalFailures: failures,
    scores: normalized,
    weights: FIDELITY_WEIGHTS,
  };
}
