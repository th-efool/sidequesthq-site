import { readFileSync, writeFileSync } from 'node:fs';

const html = readFileSync('index.html', 'utf8');
const css = readFileSync('styles.css', 'utf8');
let studioOverrides = '';
try { studioOverrides = readFileSync('ui-studio-overrides.css', 'utf8'); } catch {}
const app = readFileSync('app.js', 'utf8').replace(/<\/script/gi, '<\\/script');
let structure = '';
try { structure = readFileSync('ui-studio-structure.js', 'utf8').replace(/<\/script/gi, '<\\/script'); } catch {}

const standalone = html
  .replace(
    /<link\s+rel="stylesheet"\s+href="styles\.css"\s*\/>/i,
    () => `<style>\n${css}\n\n${studioOverrides}\n</style>`
  )
  .replace(/\s*<link\s+rel="stylesheet"\s+href="ui-studio-overrides\.css"\s*\/?>/i, '')
  .replace(
    /<script\s+src="ui-studio-structure\.js"><\/script>/i,
    () => `<script>\n${structure}\n<\/script>`
  )
  .replace(
    /<script\s+src="app\.js"><\/script>/i,
    () => `<script>\n${app}\n<\/script>`
  );

writeFileSync('ui-replica.html', standalone, 'utf8');
console.log(`Generated ui-replica.html (${Buffer.byteLength(standalone)} bytes)`);
