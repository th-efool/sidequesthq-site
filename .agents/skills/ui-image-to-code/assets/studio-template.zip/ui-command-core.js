(function attachUICommandCore(global) {
  'use strict';

  const clone = (value) => JSON.parse(JSON.stringify(value));
  const fingerprint = (value) => JSON.stringify(value);

  class UICommandHistory {
    constructor(initialSnapshot, options = {}) {
      this.limit = Math.max(20, Number(options.limit || 200));
      this.mergeWindow = Math.max(0, Number(options.mergeWindow || 520));
      this.reset(initialSnapshot, options.baselineLabel || '打开文档');
    }

    reset(snapshot, label = '打开文档') {
      const entry = this.createEntry(snapshot, {
        label,
        type: 'document.open',
        targetIds: [],
        detail: {},
      });
      this.entries = [entry];
      this.index = 0;
      this.savedIndex = 0;
      this.pending = [];
      return this.state();
    }

    createEntry(snapshot, metadata = {}) {
      return {
        snapshot: clone(snapshot),
        fingerprint: fingerprint(snapshot),
        label: String(metadata.label || '编辑 UI'),
        type: String(metadata.type || 'property.change'),
        targetIds: [...new Set((metadata.targetIds || []).map(String))],
        detail: metadata.detail && typeof metadata.detail === 'object' ? clone(metadata.detail) : {},
        mergeKey: metadata.mergeKey ? String(metadata.mergeKey) : '',
        timestamp: Number(metadata.timestamp || Date.now()),
      };
    }

    commit(snapshot, metadata = {}) {
      const current = this.entries[this.index];
      const next = this.createEntry(snapshot, metadata);
      if (current?.fingerprint === next.fingerprint) return false;

      if (this.index < this.entries.length - 1) this.entries = this.entries.slice(0, this.index + 1);
      const previous = this.entries[this.index];
      const canMerge = Boolean(
        next.mergeKey &&
        previous?.mergeKey === next.mergeKey &&
        next.timestamp - previous.timestamp <= this.mergeWindow &&
        this.index > this.savedIndex
      );

      if (canMerge) {
        this.entries[this.index] = next;
      } else {
        this.entries.push(next);
        this.index += 1;
      }

      if (this.entries.length > this.limit) {
        const removeCount = this.entries.length - this.limit;
        this.entries.splice(0, removeCount);
        this.index = Math.max(0, this.index - removeCount);
        this.savedIndex = Math.max(0, this.savedIndex - removeCount);
      }

      this.queueOperation(next);
      return true;
    }

    queueOperation(entry, type = entry.type, detail = entry.detail) {
      const operation = {
        type,
        targetIds: clone(entry.targetIds || []),
        detail: {
          label: entry.label,
          ...clone(detail || {}),
        },
      };
      const previous = this.pending.at(-1);
      if (entry.mergeKey && previous?.mergeKey === entry.mergeKey) {
        this.pending[this.pending.length - 1] = { ...operation, mergeKey: entry.mergeKey };
      } else {
        this.pending.push({ ...operation, mergeKey: entry.mergeKey });
      }
      this.pending = this.pending.slice(-50);
    }

    undo() {
      if (!this.canUndo()) return null;
      const command = this.entries[this.index];
      this.index -= 1;
      this.queueOperation(command, 'history.undo', { label: command.label, commandType: command.type });
      return { snapshot: clone(this.entries[this.index].snapshot), label: command.label, command: clone(command) };
    }

    redo() {
      if (!this.canRedo()) return null;
      const command = this.entries[this.index + 1];
      this.index += 1;
      this.queueOperation(command, 'history.redo', { label: command.label, commandType: command.type });
      return { snapshot: clone(command.snapshot), label: command.label, command: clone(command) };
    }

    canUndo() { return this.index > 0; }
    canRedo() { return this.index < this.entries.length - 1; }

    undoLabel() { return this.canUndo() ? this.entries[this.index].label : '' ; }
    redoLabel() { return this.canRedo() ? this.entries[this.index + 1].label : '' ; }
    currentLabel() { return this.entries[this.index]?.label || '打开文档'; }

    operations() {
      return this.pending.map(({ mergeKey, ...operation }) => clone(operation));
    }

    markSaved() {
      this.savedIndex = this.index;
      this.pending = [];
      return this.state();
    }

    state() {
      return {
        index: this.index,
        length: this.entries.length,
        canUndo: this.canUndo(),
        canRedo: this.canRedo(),
        undoLabel: this.undoLabel(),
        redoLabel: this.redoLabel(),
        currentLabel: this.currentLabel(),
        dirty: this.index !== this.savedIndex,
      };
    }
  }

  global.UICommandCore = Object.freeze({ UICommandHistory });
})(globalThis);
