import { readFileSync } from 'node:fs';

const html = readFileSync(new URL('../studio.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../studio.css', import.meta.url), 'utf8');
const js = readFileSync(new URL('../studio.js', import.meta.url), 'utf8');

const requirements = [
  ['task-first lists', html.includes('feature-task-bar') && html.includes('data-feature-search')],
  ['developer toggle', html.includes('data-feature-dev-toggle') && js.includes('showDeveloper')],
  ['human selection summary', html.includes('selection-path') && js.includes('selectionBreadcrumb')],
  ['contextual inspector', html.includes('data-inspector-section="typography"') && js.includes('configureInspectorForSelection')],
  ['progressive disclosure', html.includes('<details id="geometry-section"') && css.includes('.inspector-section > summary')],
  ['hover reveal', js.includes('data-ui-studio-list-hover') && js.includes('pointerenter')],
  ['state restoration', js.includes('FEATURE_STATE_KEY') && js.includes('featureScrollContainer')],
  ['feature switching preserves camera', js.includes('captureCanvasCamera') && js.includes('preserveCameraAfterFeatureSwitch') && !/if \(target\) \{ select\(target\); focusSelectedInCanvas\(\); \}/.test(js)],
  ['automatic fit pauses during feature transitions', js.includes('canvasAutoFitSuspended') && js.includes('if (canvasAutoFitSuspended || !autoFitCanvas')],
  ['reversible feedback', js.includes('showPropertyFeedback') && js.includes('Ctrl+Z 撤销')],
];

const failed = requirements.filter(([, passed]) => !passed).map(([name]) => name);
if (failed.length) {
  console.error(`Human sidebar contract: FAIL\nMissing: ${failed.join(', ')}`);
  process.exit(1);
}
console.log(`Human sidebar contract: PASS (${requirements.length} behaviors locked)`);
