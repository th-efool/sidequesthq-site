import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { analyzeImageData } from '../ui-analysis-core.mjs';
import { auditCandidateGraph, coalesceOcrBlocks, diagnoseCandidateConflicts, fuseEvidenceCandidates, inferSemanticStructure, markCoveredPixelEdges, mergeCandidatePair, mergeOcrBlocks, normalizeDomSnapshot, normalizeOcrPayload, screenOcrContamination, splitCandidate } from '../ui-semantic-core.mjs';

const width = 240;
const height = 160;
const data = new Uint8ClampedArray(width * height * 4);
for (let index = 0; index < width * height; index += 1) {
  data[index * 4] = 248;
  data[index * 4 + 1] = 250;
  data[index * 4 + 2] = 252;
  data[index * 4 + 3] = 255;
}

function pixel(x, y, color = 25) {
  const offset = (y * width + x) * 4;
  data[offset] = color;
  data[offset + 1] = color;
  data[offset + 2] = color;
}

for (let x = 20; x <= 90; x += 1) { pixel(x, 25); pixel(x, 65); }
for (let y = 25; y <= 65; y += 1) { pixel(20, y); pixel(90, y); }
for (let x = 120; x <= 220; x += 1) { pixel(x, 22); pixel(x, 120); }
for (let y = 22; y <= 120; y += 1) { pixel(120, y); pixel(220, y); }
for (let x = 32; x <= 76; x += 4) for (let y = 40; y <= 48; y += 1) pixel(x, y, 45);

const result = analyzeImageData({ data, width, height }, { idPrefix:'analysis.test', sourceScaleX:2, sourceScaleY:2 });
assert.equal(result.nodes[0].type, 'page');
assert.equal(result.sourceSize.width, 480);
assert.ok(result.nodes.some((node) => ['frame', 'section', 'image'].includes(node.type)), '应识别至少一个框架区域');
assert.ok(result.palette.length >= 2, '应提取颜色候选');
assert.ok(result.nodes.every((node) => node.id.startsWith('analysis.test.')));
assert.ok(result.nodes.filter((node) => node.type !== 'page').every((node) => node.parentId), '非页面节点必须有父级');
assert.equal(Number.isInteger(result.metrics.noiseCandidates), true, '像素分析必须报告微小噪声候选数量');

const ocr = normalizeOcrPayload({ blocks:[{ text:'复制商品图', confidence:0.97, bounds:{ x:30, y:40, width:90, height:20 } }] });
assert.equal(ocr.length, 1);
assert.equal(ocr[0].text, '复制商品图');
const screenedOcr = screenOcrContamination(normalizeOcrPayload({ blocks:[
  { text:'复制商品图', confidence:0.97, bounds:{ x:30, y:40, width:90, height:20 } },
  { text:'激活 Windows', confidence:0.99, bounds:{ x:1500, y:850, width:180, height:20 } },
  { text:'https://example.com/studio', confidence:0.99, bounds:{ x:160, y:16, width:300, height:20 } },
] }), { width:1920, height:919 });
assert.equal(screenedOcr.clean.length, 1);
assert.equal(screenedOcr.rejected.length, 2);
assert.deepEqual(new Set(screenedOcr.rejected.map((item) => item.contaminationReason)), new Set(['system-overlay', 'browser-address-bar']));
const merged = mergeOcrBlocks(result.nodes, ocr, { idPrefix:'analysis.test.ocr' });
assert.equal(merged.metrics.ocrBlocks, 1);
assert.ok(merged.nodes.some((node) => node.type === 'text' && node.content?.text === '复制商品图'));

const coalesced = coalesceOcrBlocks([
  { id:'ocr.a', text:'复制', confidence:0.94, bounds:{ x:20, y:20, width:34, height:18 } },
  { id:'ocr.b', text:'商品图', confidence:0.96, bounds:{ x:58, y:20, width:52, height:18 } },
  { id:'ocr.c', text:'构图 / 光线 / 背景', confidence:0.91, bounds:{ x:20, y:48, width:150, height:18 } },
]);
assert.equal(coalesced.length, 2, '同一基线的 OCR 词块应合成一行，标题和副标题必须保持分层');
assert.equal(coalesced[0].text, '复制商品图');
const distinctTextMerge = mergeOcrBlocks([
  { id:'page.text', type:'page', name:'页面', bounds:{ x:0, y:0, width:300, height:160 }, parentId:null, confidence:1 },
  { id:'pixel.text', type:'text', name:'文字候选', bounds:{ x:18, y:18, width:100, height:22 }, parentId:'page.text', confidence:0.72 },
], coalesced, { idPrefix:'analysis.lines' });
assert.equal(distinctTextMerge.metrics.ocrMatched, 1, '一个像素文字候选在同一轮只能消费一条 OCR 行');
assert.equal(distinctTextMerge.metrics.ocrCreated, 1, '第二条 OCR 行必须成为独立文字层而不是覆盖标题');

const semantic = inferSemanticStructure([
  { id:'page', type:'page', bounds:{ x:0, y:0, width:400, height:200 }, parentId:null },
  { id:'item.1', type:'control', bounds:{ x:20, y:20, width:80, height:32 }, parentId:'page' },
  { id:'item.2', type:'control', bounds:{ x:20, y:64, width:80, height:32 }, parentId:'page' },
  { id:'item.3', type:'control', bounds:{ x:20, y:108, width:80, height:32 }, parentId:'page' },
]);
assert.equal(semantic.nodes.find((node) => node.id === 'page').layoutHint.direction, 'column');
assert.ok(semantic.metrics.repeatedGroups >= 1);
assert.equal(semantic.metrics.repeatedInstances, 3);

const repairedHierarchy = inferSemanticStructure([
  { id:'hierarchy.page', type:'page', bounds:{ x:0, y:0, width:500, height:300 }, parentId:null },
  { id:'hierarchy.panel', type:'section', bounds:{ x:40, y:30, width:220, height:220 }, parentId:'hierarchy.page' },
  { id:'hierarchy.label', type:'text', bounds:{ x:60, y:50, width:80, height:20 }, parentId:'hierarchy.page', content:{ text:'标题' } },
]);
assert.equal(repairedHierarchy.nodes.find((node) => node.id === 'hierarchy.label').parentId, 'hierarchy.panel', '广义页面父级应收紧到最接近的真实容器');
assert.ok(repairedHierarchy.metrics.parentRepairs >= 1);

const mergedPair = mergeCandidatePair([
  { id:'merge.page', type:'page', bounds:{ x:0, y:0, width:400, height:200 }, parentId:null, confidence:1 },
  { id:'merge.a', type:'frame', name:'候选 A', bounds:{ x:20, y:20, width:100, height:80 }, parentId:'merge.page', confidence:0.72 },
  { id:'merge.b', type:'frame', name:'候选 B', bounds:{ x:22, y:22, width:96, height:76 }, parentId:'merge.page', confidence:0.8 },
  { id:'merge.child', type:'text', name:'子层', bounds:{ x:30, y:30, width:40, height:20 }, parentId:'merge.b', confidence:0.9, content:{ text:'子层' } },
], 'merge.a', 'merge.b');
assert.equal(mergedPair.merged, true);
assert.equal(mergedPair.nodes.find((node) => node.id === 'merge.child').parentId, 'merge.a', '合并候选必须重定向被合并节点的子层');
assert.deepEqual(auditCandidateGraph(mergedPair.nodes).missingParents, []);

const splitResult = splitCandidate([
  { id:'split.page', type:'page', bounds:{ x:0, y:0, width:400, height:240 }, parentId:null, confidence:1 },
  { id:'split.container', type:'frame', name:'双栏', bounds:{ x:20, y:20, width:240, height:120 }, parentId:'split.page', confidence:0.8 },
  { id:'split.left', type:'text', name:'左', bounds:{ x:40, y:50, width:50, height:20 }, parentId:'split.container', confidence:0.9, content:{ text:'左' } },
  { id:'split.right', type:'text', name:'右', bounds:{ x:190, y:50, width:50, height:20 }, parentId:'split.container', confidence:0.9, content:{ text:'右' } },
], 'split.container');
assert.equal(splitResult.split, true);
assert.deepEqual(splitResult.createdIds, ['split.container.split.a', 'split.container.split.b'], '拆分身份必须稳定，不使用时间戳');
assert.equal(new Set(splitResult.nodes.filter((node) => ['split.left','split.right'].includes(node.id)).map((node) => node.parentId)).size, 2, '拆分后子层应按实际空间重新分配');
assert.deepEqual(auditCandidateGraph(splitResult.nodes).missingParents, []);

const dom = normalizeDomSnapshot([
  { id:'app.shell', tag:'main', name:'应用', bounds:{ x:0, y:0, width:400, height:200 }, display:'grid' },
  { id:'app.icon', parentId:'app.shell', tag:'svg', name:'首页图标', bounds:{ x:20, y:20, width:20, height:20 } },
  { id:'app.label', parentId:'app.shell', tag:'span', name:'首页文字', directText:'首页', bounds:{ x:48, y:20, width:40, height:20 } },
], { viewportWidth:400, viewportHeight:200, sourceWidth:800, sourceHeight:400 });
assert.equal(dom.nodes.length, 3);
assert.equal(dom.nodes.find((node) => node.sourceNodeId === 'app.icon').type, 'icon');
assert.equal(dom.nodes.find((node) => node.sourceNodeId === 'app.label').content.text, '首页');
assert.equal(dom.nodes[0].bounds.width, 800);
assert.equal(dom.metrics.domTextNodes, 1, 'DOM 校准必须报告自动文字证据数量');

const fused = fuseEvidenceCandidates([
  { id:'pixel.page', type:'page', name:'页面', bounds:{ x:0, y:0, width:800, height:400 }, parentId:null, confidence:0.99, source:'image-boundary' },
  { id:'pixel.frame', type:'frame', name:'像素框', bounds:{ x:38, y:38, width:204, height:84 }, parentId:'pixel.page', confidence:0.76, source:'pixel-structure' },
], [
  { id:'dom.page', type:'page', name:'应用', bounds:{ x:0, y:0, width:800, height:400 }, parentId:null, confidence:0.995, source:'production-dom', sourceNodeId:'app.shell' },
  { id:'dom.frame', type:'frame', name:'菜单', bounds:{ x:40, y:40, width:200, height:80 }, parentId:'dom.page', confidence:0.995, source:'production-dom', sourceNodeId:'sidebar.navigation' },
  { id:'dom.icon', type:'icon', name:'菜单图标', bounds:{ x:52, y:52, width:20, height:20 }, parentId:'dom.frame', confidence:0.995, source:'production-dom', sourceNodeId:'sidebar.navigation.icon' },
]);
assert.equal(fused.metrics.evidenceMatched, 2);
assert.equal(fused.metrics.evidenceAdded, 1);
assert.equal(fused.nodes.length, 3, '融合证据不应复制同一个可见对象，但必须保留独立原子节点');
assert.equal(fused.nodes.find((node) => node.sourceNodeId === 'sidebar.navigation')?.bounds.width, 200, 'DOM 精确边界应成为融合后的事实');
assert.equal(fused.nodes.find((node) => node.sourceNodeId === 'sidebar.navigation')?.quality?.reason, 'production-dom', 'DOM 精确证据必须清除像素噪声标记');
assert.equal(fused.nodes.find((node) => node.sourceNodeId === 'sidebar.navigation.icon')?.parentId, 'pixel.frame', '新增 DOM 子节点必须指向融合后的稳定父级');
assert.deepEqual(auditCandidateGraph(fused.nodes).missingParents, []);
assert.deepEqual(auditCandidateGraph(fused.nodes).cycles, [], '融合后的候选图不得包含父级循环');

const coveredEdges = markCoveredPixelEdges([
  { id:'dom.panel', type:'section', name:'面板', bounds:{ x:100, y:50, width:300, height:200 }, parentId:null, confidence:0.995, source:'production-dom', sourceNodeId:'panel' },
  { id:'pixel.bottom', type:'divider', name:'底部边缘', bounds:{ x:100, y:248, width:300, height:4 }, parentId:null, confidence:0.74, source:'edge-projection' },
  { id:'pixel.left', type:'unknown', name:'左侧残影', bounds:{ x:97, y:50, width:8, height:200 }, parentId:null, confidence:0.7, source:'pixel-structure' },
  { id:'pixel.real-divider', type:'divider', name:'真实分割线', bounds:{ x:120, y:150, width:260, height:2 }, parentId:null, confidence:0.8, source:'edge-projection' },
  { id:'human.divider', type:'divider', name:'人工分割线', bounds:{ x:100, y:51, width:300, height:2 }, parentId:null, confidence:0.8, source:'edge-projection', humanConfirmed:true },
]);
assert.equal(coveredEdges.metrics.absorbedEdgeArtifacts, 2, '只有被精确 DOM 边缘解释的纯像素细线才应被吸收');
assert.equal(coveredEdges.nodes.find((node) => node.id === 'pixel.bottom')?.quality?.reason, 'covered-by-dom-edge');
assert.equal(coveredEdges.nodes.find((node) => node.id === 'pixel.left')?.quality?.orientation, 'vertical');
assert.notEqual(coveredEdges.nodes.find((node) => node.id === 'pixel.real-divider')?.quality?.reason, 'covered-by-dom-edge', '容器内部真实分割线必须保留审核');
assert.notEqual(coveredEdges.nodes.find((node) => node.id === 'human.divider')?.quality?.reason, 'covered-by-dom-edge', '人工确认结果不得被自动规则覆盖');

const unionCoveredEdge = markCoveredPixelEdges([
  { id:'pixel.full-line', type:'divider', name:'跨栏投影线', bounds:{ x:0, y:49, width:400, height:2 }, confidence:0.9, source:'edge-projection' },
], { evidenceNodes:[
  { id:'dom.left', type:'section', bounds:{ x:0, y:0, width:180, height:50 }, source:'production-dom', sourceNodeId:'left' },
  { id:'dom.right', type:'section', bounds:{ x:180, y:0, width:220, height:50 }, source:'production-dom', sourceNodeId:'right' },
] });
assert.equal(unionCoveredEdge.metrics.absorbedEdgeArtifacts, 1, '多个精确 DOM 边缘共同覆盖的投影线也应被吸收');
assert.deepEqual(unionCoveredEdge.nodes[0].quality.targetIds.sort(), ['dom.left', 'dom.right']);
assert.equal(auditCandidateGraph([{ id:'orphan', type:'text', bounds:{ x:0, y:0, width:20, height:10 }, parentId:'missing', content:{} }]).valid, false);
assert.equal(auditCandidateGraph([
  { id:'cycle.a', type:'container', bounds:{ x:0, y:0, width:40, height:40 }, parentId:'cycle.b', content:{} },
  { id:'cycle.b', type:'container', bounds:{ x:2, y:2, width:20, height:20 }, parentId:'cycle.a', content:{} }
]).cycles.length > 0, true, '图审计必须识别父级循环');

const conflictDiagnosis = diagnoseCandidateConflicts([
  { id:'conflict.page', type:'page', bounds:{ x:0, y:0, width:300, height:200 }, parentId:null, confidence:1 },
  { id:'conflict.strong', type:'frame', name:'DOM 容器', bounds:{ x:20, y:20, width:100, height:80 }, parentId:'conflict.page', confidence:.99, source:'production-dom', sourceNodeId:'panel' },
  { id:'conflict.weak', type:'frame', name:'像素重复框', bounds:{ x:28, y:20, width:100, height:80 }, parentId:'conflict.page', confidence:.55, source:'pixel-structure' },
]);
assert.equal(conflictDiagnosis.length, 1);
assert.equal(conflictDiagnosis[0].recommendedAction, 'exclude-right', '强 DOM 与弱像素候选冲突时应建议排除弱项');
assert.equal(conflictDiagnosis[0].weakerId, 'conflict.weak');

const humanConflict = diagnoseCandidateConflicts([
  { id:'human.page', type:'page', bounds:{ x:0, y:0, width:300, height:200 }, parentId:null, confidence:1 },
  { id:'human.a', type:'text', bounds:{ x:20, y:20, width:100, height:24 }, parentId:'human.page', confidence:.9, humanConfirmed:true, content:{ text:'标题' } },
  { id:'human.b', type:'text', bounds:{ x:25, y:20, width:100, height:24 }, parentId:'human.page', confidence:.9, content:{ text:'副标题' } },
]);
assert.equal(humanConflict[0].recommendedAction, 'keep-both', '人工确认候选不得被自动合并或排除');
assert.equal(humanConflict[0].protectedByHuman, true);

const resolvedId = 'conflict:resolved.a|resolved.b';
assert.equal(diagnoseCandidateConflicts([
  { id:'resolved.page', type:'page', bounds:{ x:0, y:0, width:300, height:200 }, parentId:null },
  { id:'resolved.a', type:'frame', bounds:{ x:20, y:20, width:100, height:80 }, parentId:'resolved.page', conflictResolutions:{ [resolvedId]:{ action:'keep-both' } } },
  { id:'resolved.b', type:'frame', bounds:{ x:28, y:20, width:100, height:80 }, parentId:'resolved.page' },
]).length, 0, '保留两个的人工决策必须持久化并抑制重复冲突');

const analysisSource = readFileSync(new URL('../ui-analysis.js', import.meta.url), 'utf8');
const studioMarkup = readFileSync(new URL('../studio.html', import.meta.url), 'utf8');
assert.match(analysisSource, /AUTO_ACCEPT_THRESHOLD = 0\.92/);
assert.match(analysisSource, /evidenceSources\(node\)\.length >= 2/);
assert.match(analysisSource, /fuseEvidenceCandidates/);
assert.match(analysisSource, /auditCandidateGraph/);
assert.match(analysisSource, /analysis-generation-preflight/);
assert.match(analysisSource, /unresolvedBeforeSave/);
assert.match(analysisSource, /reviewConfirmed/);
assert.match(analysisSource, /runAutomaticTextRecognition/);
assert.match(analysisSource, /globalThis\.TextDetector/);
assert.match(analysisSource, /browser-text-detector-unavailable/);
assert.match(analysisSource, /mergeTextEvidence/);
assert.match(analysisSource, /screenOcrContamination/);
assert.match(analysisSource, /stableIdentityToken/);
assert.match(analysisSource, /screenshotIdentityKey/);
assert.match(analysisSource, /analysisIdentity:\{ sourceKey, candidateId:node\.id, referenceId \}/);
assert.match(analysisSource, /mergeRecognizedNodes\(documentValue\.nodes, recognizedNodes\)/);
assert.match(analysisSource, /conflictBlockers = graphAudit\.overlapConflicts\.filter/);
assert.match(analysisSource, /diagnoseCandidateConflicts/);
assert.match(analysisSource, /resolveSelectedConflict/);
assert.match(analysisSource, /我已检查 \$\{warningCount\} 项生成警告/);
assert.match(studioMarkup, /id="analysis-intake-check"/);
assert.match(analysisSource, /function inspectScreenshotIntake\(/);
assert.match(analysisSource, /function screenshotSharpness\(/);
assert.match(analysisSource, /包含浏览器栏或系统区域/);
assert.match(analysisSource, /projectReference/);
assert.match(analysisSource, /matchesCanonicalProjectReference/);
assert.match(analysisSource, /origin:state\.projectReference \? 'project-reference' : 'upload'/);
assert.match(analysisSource, /waitForProductionDomSnapshot/);
assert.match(analysisSource, /classList\.add\('dom-calibrating'\)/);
assert.match(analysisSource, /calibration\.dom\.metrics\.domTextNodes/);
assert.match(analysisSource, /analysis-smart-triage/);
assert.match(analysisSource, /isLikelyNoiseCandidate/);
assert.match(analysisSource, /markCoveredPixelEdges/);
assert.match(analysisSource, /type:'analysis\.generate-editable-layers'/);
assert.doesNotMatch(analysisSource, /analysis\.generateEditableLayers/);
assert.match(studioMarkup, /id="analysis-review-confirm"/);
assert.match(studioMarkup, /id="analysis-smart-triage"/);
assert.match(studioMarkup, /id="analysis-prop-quality"/);
assert.match(studioMarkup, /id="analysis-conflict-card"/);
assert.doesNotMatch(studioMarkup, /analysis-toggle-all/);
assert.doesNotMatch(studioMarkup, /data-feature="menus"/);

console.log(`Recognition pipeline: PASS (${result.nodes.length} pixel candidates, OCR/layout/DOM adapters and human review gate ready)`);
