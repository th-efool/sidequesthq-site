import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createUIDocumentV4, validateUIDocumentV4 } from '../ui-document-v4.mjs';
import { buildOverrideCSS, buildStructuralScript, applyDocumentToHTML } from '../ui-sync-core.mjs';

const [studio, html, schema, sync] = await Promise.all([
  readFile(new URL('../studio.js', import.meta.url), 'utf8'),
  readFile(new URL('../studio.html', import.meta.url), 'utf8'),
  readFile(new URL('../ui-document-v4.mjs', import.meta.url), 'utf8'),
  readFile(new URL('../ui-sync-core.mjs', import.meta.url), 'utf8'),
]);

const insertion = {
  id:'card.copy1',
  sourceId:'card',
  parentId:'page',
  afterId:'card',
  idMap:{ card:'card.copy1', 'card.title':'card.title.copy1' },
  name:'Card copy',
};
const document = createUIDocumentV4('hash', 1);
document.structuralEdits.insertions.push(insertion);
document.layerMetadata['card.copy1'] = { name:'Renamed card copy' };
document.overrides['card.copy1'] = { zIndex:3, position:'relative' };
validateUIDocumentV4(document, { protocolVersion:1 });

const generated = buildStructuralScript(document);
assert.match(generated, /card\.copy1/, 'generated structural source must contain the stable duplicate ID');
assert.match(generated, /cloneNode\(true\)/, 'generated structural source must duplicate the real subtree');
assert.match(buildOverrideCSS(document), /z-index: 3 !important;[\s\S]*position: relative !important;/, 'stacking overrides must reach generated source CSS with authoritative cascade priority');
const linked = applyDocumentToHTML('<!doctype html><html><body><main data-ui-id="page"><section data-ui-id="card"><h2 data-ui-id="card.title">A</h2></section></main><script src="app.js"></script></body></html>', document);
assert.match(linked, /ui-studio-structure\.js/, 'production HTML must load the structural source before app.js');

const checks = [
  [studio, /SHORTCUT_LAYER_VERSION = '1\.2\.0'/, 'shortcut layer version'],
  [studio, /function applyStructuralEdits\(/, 'runtime structural replay'],
  [studio, /function duplicateSelection\(/, 'true duplicate command'],
  [studio, /type:'layer\.duplicate'/, 'semantic duplicate history'],
  [studio, /type:duplicateDrag \? 'layer\.duplicate-drag'/, 'persistent duplicate-drag history'],
  [studio, /command && key === 'j'/, 'Ctrl\/Cmd+J accelerator'],
  [studio, /structuralEdits:clone\(structuralEdits\)/, 'project persistence'],
  [studio, /layerMetadata:clone\(layerMetadata\)/, 'layer-name persistence'],
  [schema, /validateStructuralEdits/, 'schema validation'],
  [sync, /buildStructuralScript/, 'project preview generation'],
  [html, /创建真实图层副本/, 'discoverable shortcut help'],
];
for (const [source, pattern, label] of checks) assert.match(source, pattern, label);

console.log(`Structural duplicate contract PASS (${checks.length + 3} invariants)`);
