import assert from 'node:assert/strict';
import { compareImageData, computeFidelityGate } from '../ui-fidelity-core.mjs';

function makeImage(width, height, color = [248, 250, 252]) {
  const data = new Uint8ClampedArray(width * height * 4);
  for (let index = 0; index < width * height; index += 1) {
    data[index * 4] = color[0];
    data[index * 4 + 1] = color[1];
    data[index * 4 + 2] = color[2];
    data[index * 4 + 3] = 255;
  }
  return { width, height, data };
}

const reference = makeImage(80, 60);
const identical = { width:reference.width, height:reference.height, data:new Uint8ClampedArray(reference.data) };
const same = compareImageData(reference, identical);
assert.equal(same.metrics.pixelSimilarity, 100);
assert.equal(same.metrics.changedPixelRatio, 0);
assert.equal(same.mismatchQueue.length, 0);

const changed = makeImage(80, 60);
for (let y = 15; y < 45; y += 1) for (let x = 20; x < 60; x += 1) {
  const offset = (y * changed.width + x) * 4;
  changed.data[offset] = 20;
  changed.data[offset + 1] = 80;
  changed.data[offset + 2] = 220;
}
const diff = compareImageData(reference, changed, { columns:4, rows:3 });
assert.ok(diff.metrics.pixelSimilarity < 100);
assert.ok(diff.metrics.changedPixelRatio > 0.2);
assert.ok(diff.mismatchQueue.length > 0);
assert.equal(diff.heatmap.data.length, reference.data.length);

const perfectScores = Object.fromEntries(['geometry','typography','assets','effects','responsive','interactions','codeQuality','editable'].map((key) => [key, 100]));
const passed = computeFidelityGate(perfectScores);
assert.equal(passed.score, 100);
assert.equal(passed.passed, true);
const capped = computeFidelityGate(perfectScores, ['文字溢出']);
assert.equal(capped.score, 94);
assert.equal(capped.passed, false);
assert.equal(capped.criticalCapApplied, true);
const partial = computeFidelityGate({ geometry:96 });
assert.equal(partial.complete, false);
assert.equal(partial.coverage, 25);

console.log(`Fidelity gate: PASS (${diff.mismatchQueue.length} mismatch regions, weighted 95% gate ready)`);
