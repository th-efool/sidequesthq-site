import { readFileSync } from 'node:fs';

const html = readFileSync(new URL('../studio.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../studio.css', import.meta.url), 'utf8');
const js = readFileSync(new URL('../studio.js', import.meta.url), 'utf8');

const requirements = [
  ['selection set', js.includes('let selectedIds = new Set()') && js.includes('activeSelectionIds')],
  ['shift toggle from tree', js.includes("select(node.id, { toggle:event.shiftKey })")],
  ['parent child conflict protection', js.includes('relatedIds') && js.includes('ancestorIds(id)') && js.includes('descendantIds(id)')],
  ['union selection box', js.includes('selectionUnionRect') && js.includes('data-multi="true"')],
  ['group move', js.includes('multiStart') && js.includes('movableIds')],
  ['six align actions', ['align-left','align-center-x','align-right','align-top','align-center-y','align-bottom'].every((action) => html.includes(`data-multi-action="${action}"`))],
  ['equal spacing', html.includes('data-multi-action="distribute-x"') && html.includes('data-multi-action="distribute-y"') && js.includes("action === 'distribute-x' || action === 'distribute-y'")],
  ['batch undo', js.includes('offsets.forEach') && js.includes("type:'layout.arrange'")],
  ['batch keyboard nudge', js.includes('activeSelectionIds().forEach((id) => offsetNode(id, dx, dy))')],
  ['multi visual states', css.includes('.layer-row.multi-selected') && css.includes('.multi-inspector')],
];

const failed = requirements.filter(([, passed]) => !passed).map(([name]) => name);
if (failed.length) {
  console.error(`Multi-selection contract: FAIL\nMissing: ${failed.join(', ')}`);
  process.exit(1);
}
console.log(`Multi-selection contract: PASS (${requirements.length} behaviors locked)`);
