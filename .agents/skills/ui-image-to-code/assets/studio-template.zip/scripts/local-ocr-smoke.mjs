import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { parseTesseractTsv } from '../local-ocr.mjs';
import { normalizeOcrPayload, screenOcrContamination } from '../ui-semantic-core.mjs';

const tsv = [
  'level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext',
  '5\t1\t1\t1\t1\t1\t12\t20\t30\t14\t96\t复制',
  '5\t1\t1\t1\t1\t2\t46\t20\t45\t14\t92\t商品图',
].join('\n');
const blocks = parseTesseractTsv(tsv);
assert.equal(blocks.length, 1);
assert.equal(blocks[0].text, '复制 商品图');
assert.deepEqual(blocks[0].bounds, { x:12, y:20, width:79, height:14 });
assert.equal(blocks[0].confidence, 0.94);

const normalized = normalizeOcrPayload({ blocks:[
  { text:'复 刻 参 考 图', confidence:.9, bounds:{ x:20, y:20, width:100, height:18 } },
  { text:'激 活 Windows', confidence:.9, bounds:{ x:1600, y:840, width:180, height:18 } },
] });
assert.equal(normalized[0].text, '复刻参考图');
const screened = screenOcrContamination(normalized, { width:1920, height:919 });
assert.equal(screened.clean.length, 1);
assert.equal(screened.rejected.length, 1);
assert.equal(screened.rejected[0].contaminationReason, 'system-overlay');

const bridgeSource = await readFile(new URL('../studio-bridge.mjs', import.meta.url), 'utf8');
const analysisSource = await readFile(new URL('../ui-analysis.js', import.meta.url), 'utf8');
const nativeSource = await readFile(new URL('./windows-native-ocr.ps1', import.meta.url), 'utf8');
assert.match(bridgeSource, /runLocalOcr/);
assert.match(bridgeSource, /\/__ui_sync\/ocr/);
assert.match(analysisSource, /runBridgeTextRecognition/);
assert.match(analysisSource, /Windows 离线 OCR/);
assert.doesNotMatch(analysisSource, /setAdapterStatus\('analysis-ocr-status', `DOM 自动文字/);
assert.match(nativeSource, /TryCreateFromUserProfileLanguages/);
assert.match(nativeSource, /RecognizeAsync/);

console.log('Local OCR fallback contract: PASS');
