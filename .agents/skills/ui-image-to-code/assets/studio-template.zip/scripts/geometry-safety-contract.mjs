import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { createUIDocumentV4, validateUIDocumentV4 } from '../ui-document-v4.mjs';

const root = path.resolve(import.meta.dirname, '..');
const studioSource = await readFile(path.join(root, 'studio.js'), 'utf8');
const hash = 'a'.repeat(64);

function invalidOverride(key, value) {
  const document = createUIDocumentV4(hash, 1);
  document.overrides = { target:{ [key]:value } };
  return document;
}

for (const [key, value] of [
  ['width', -10],
  ['height', 0],
  ['x', Infinity],
  ['y', 1_000_001],
  ['scale', 0],
  ['scale', 11],
  ['rotation', 361],
]) {
  assert.throws(() => validateUIDocumentV4(invalidOverride(key, value), { protocolVersion:1 }), undefined, `${key}=${value} 必须被拒绝`);
}

assert.match(studioSource, /GEOMETRY_LIMITS/);
assert.match(studioSource, /sanitizeOverrideGeometry\(overrides\)/);
assert.match(studioSource, /已阻止.*无效几何值/);
assert.match(studioSource, /Number\(rectSnapshot\.width\) <= 1_000_000/);

console.log('geometry safety contract: ok');
