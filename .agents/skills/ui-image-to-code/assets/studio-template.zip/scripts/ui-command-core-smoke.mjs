import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../ui-command-core.js', import.meta.url), 'utf8');
const context = vm.createContext({ console, structuredClone, setTimeout, clearTimeout });
context.globalThis = context;
vm.runInContext(source, context, { filename:'ui-command-core.js' });

const { UICommandHistory } = context.UICommandCore;
const history = new UICommandHistory({ value:0 }, { mergeWindow:1000 });

assert.equal(history.canUndo(), false);
assert.equal(history.commit({ value:1 }, { label:'移动对象', type:'geometry.move', targetIds:['hero'], mergeKey:'move:hero' }), true);
assert.equal(history.commit({ value:2 }, { label:'移动对象', type:'geometry.move', targetIds:['hero'], mergeKey:'move:hero' }), true);
assert.equal(history.state().length, 2, '连续轻移应合并成一条命令');
assert.equal(history.undoLabel(), '移动对象');
assert.equal(JSON.stringify(history.undo().snapshot), JSON.stringify({ value:0 }));
assert.ok(history.operations().some((operation) => operation.type === 'history.undo'));
assert.equal(JSON.stringify(history.redo().snapshot), JSON.stringify({ value:2 }));
assert.ok(history.operations().some((operation) => operation.type === 'history.redo'));
history.markSaved();
assert.equal(history.operations().length, 0);

console.log('UI command core: PASS');
