import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { copyFile, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

const sourceRoot = path.resolve(import.meta.dirname, '..');
const fixture = await mkdtemp(path.join(os.tmpdir(), 'ui-studio-sync-'));
const port = 43000 + Math.floor(Math.random() * 1500);
let bridge;

async function waitForServer() {
  let lastError;
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/__ui_sync/status`);
      if (response.ok) return response.json();
    } catch (error) { lastError = error; }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw lastError || new Error('同步桥启动超时');
}

async function request(pathname, options = {}) {
  const response = await fetch(`http://127.0.0.1:${port}${pathname}`, { headers:{ 'Content-Type':'application/json' }, ...options });
  const data = await response.json();
  return { response, data };
}

try {
  await mkdir(path.join(fixture, 'scripts'), { recursive:true });
  for (const file of ['ui-document-v4.mjs','ui-sync-core.mjs','ui-fidelity-core.mjs','local-ocr.mjs','studio-bridge.mjs','ui-sync.mjs']) await copyFile(path.join(sourceRoot, file), path.join(fixture, file));
  await copyFile(path.join(sourceRoot, 'scripts', 'windows-native-ocr.ps1'), path.join(fixture, 'scripts', 'windows-native-ocr.ps1'));
  await writeFile(path.join(fixture, 'index.html'), '<!doctype html><link rel="stylesheet" href="styles.css"><link rel="stylesheet" href="ui-studio-overrides.css"><main data-ui-id="page"><span data-ui-id="title">Old</span><section data-ui-id="card"><h2 data-ui-id="card.title">Card</h2></section></main><script src="ui-studio-structure.js"></script><script src="app.js"></script>\n', 'utf8');
  await writeFile(path.join(fixture, 'styles.css'), '[data-ui-id="title"] { color: black; }\n', 'utf8');
  await writeFile(path.join(fixture, 'app.js'), 'console.log("fixture");\n', 'utf8');

  bridge = spawn(process.execPath, ['studio-bridge.mjs'], {
    cwd:fixture,
    env:{ ...process.env, UI_STUDIO_PORT:String(port) },
    stdio:['ignore','pipe','pipe'],
  });
  const initial = await waitForServer();
  assert.equal(initial.state, 'clean');
  assert.equal(initial.documentRevision, 0);

  const current = await request('/__ui_sync/document');
  const document = current.data.document;
  assert.equal(document.version, 4);
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Wl5sAAAAASUVORK5CYII=', 'base64');
  const uploaded = await request('/__ui_sync/reference/ref-fixture', { method:'PUT', headers:{ 'Content-Type':'image/png', 'X-UI-Expected-Revision':'0' }, body:png });
  assert.equal(uploaded.response.status, 200);
  assert.equal(uploaded.data.width, 1);
  assert.equal(uploaded.data.path, '/.ui-studio/references/ref-fixture.png');
  const invalidVersion = structuredClone(document);
  invalidVersion.version = 99;
  const rejectedVersion = await request('/__ui_sync/document', { method:'PUT', body:JSON.stringify({ expectedRevision:0, document:invalidVersion }) });
  assert.equal(rejectedVersion.response.status, 400);
  const invalidSvg = structuredClone(document);
  invalidSvg.iconReplacements = { icon:{ body:'<script>alert(1)</script>', viewBox:'0 0 24 24' } };
  const rejectedSvg = await request('/__ui_sync/document', { method:'PUT', body:JSON.stringify({ expectedRevision:0, document:invalidSvg }) });
  assert.equal(rejectedSvg.response.status, 400);
  document.overrides = { title:{ textContent:'New', color:'#ff0000' } };
  document.structuralEdits = { insertions:[{ id:'card.copy1', sourceId:'card', parentId:'page', afterId:'card', idMap:{ card:'card.copy1', 'card.title':'card.title.copy1' }, name:'Card copy' }] };
  const saved = await request('/__ui_sync/document', { method:'PUT', body:JSON.stringify({ expectedRevision:0, document, operations:[{ type:'property.change', targetIds:['title'], detail:{ key:'color' } }] }) });
  assert.equal(saved.response.status, 200);
  assert.equal(saved.data.document.revision, 1);
  assert.equal(saved.data.status.state, 'pending-codex');
  assert.equal(saved.data.status.previewRevision, 1);
  assert.equal(saved.data.status.previewIsCurrent, true);
  assert.equal(saved.data.status.previewStatus, 'applied');
  assert.equal(saved.data.document.operations.at(-1).type, 'property.change');
  assert.match(await readFile(path.join(fixture, 'ui-studio-overrides.css'), 'utf8'), /color: #ff0000/);
  assert.match(await readFile(path.join(fixture, 'ui-studio-structure.js'), 'utf8'), /card\.copy1/);
  const automaticHandoff = JSON.parse(await readFile(path.join(fixture, '.ui-studio', 'handoff.json'), 'utf8'));
  assert.equal(automaticHandoff.revision, 1);
  assert.equal(automaticHandoff.status, 'preview-applied-waiting-codex');

  const stale = await request('/__ui_sync/document', { method:'PUT', body:JSON.stringify({ expectedRevision:0, document }) });
  assert.equal(stale.response.status, 409);
  assert.equal(stale.data.error, 'revision.conflict');

  const handoff = await request('/__ui_sync/handoff', { method:'POST', body:JSON.stringify({ expectedRevision:1 }) });
  assert.equal(handoff.response.status, 200);
  assert.match(handoff.data.prompt, /sync:apply/);

  const fidelityScores = { geometry:96, typography:95, assets:95, effects:95, responsive:95, interactions:96, codeQuality:95, editable:95 };
  const fidelity = await request('/__ui_sync/fidelity', { method:'PUT', body:JSON.stringify({ expectedRevision:1, scores:fidelityScores, criticalFailures:[], proofKind:'browser-capture', metrics:{ pixelSimilarity:97.4 } }) });
  assert.equal(fidelity.response.status, 200);
  assert.equal(fidelity.data.qualityGate.revision, 1);
  assert.equal(fidelity.data.qualityGate.passed, true);
  const fidelityStatus = await request('/__ui_sync/status');
  assert.equal(fidelityStatus.data.qualityGate.passed, true);
  assert.equal(fidelityStatus.data.handoffRevision, 1);

  const history = await request('/__ui_sync/history');
  assert.equal(history.response.status, 200);
  assert.equal(history.data.current.revision, 1);
  assert.ok(history.data.archived.some((item) => item.revision === 0));
  const rolledBack = await request('/__ui_sync/rollback', { method:'POST', body:JSON.stringify({ expectedRevision:1, targetRevision:0 }) });
  assert.equal(rolledBack.response.status, 200);
  assert.equal(rolledBack.data.document.revision, 2);
  assert.equal(rolledBack.data.document.overrides.title, undefined);
  assert.equal(rolledBack.data.document.operations.at(-1).type, 'history.restore');
  const restoredForward = await request('/__ui_sync/rollback', { method:'POST', body:JSON.stringify({ expectedRevision:2, targetRevision:1 }) });
  assert.equal(restoredForward.response.status, 200);
  assert.equal(restoredForward.data.document.revision, 3);
  assert.equal(restoredForward.data.document.overrides.title.textContent, 'New');

  bridge.kill();
  await new Promise((resolve) => bridge.once('exit', resolve));
  bridge = null;

  const contextResult = spawnSync(process.execPath, ['ui-sync.mjs','context'], { cwd:fixture, encoding:'utf8' });
  assert.equal(contextResult.status, 0, contextResult.stderr || contextResult.stdout);
  const context = JSON.parse(contextResult.stdout);
  assert.equal(context.persistedOnly, true);
  assert.equal(context.latestUI.revision, 3);
  assert.equal(context.latestUI.appliedRevision, 0);
  assert.equal(context.latestUI.previewRevision, 3);
  assert.equal(context.latestUI.previewIsCurrent, true);
  assert.equal(context.identity.status, 'valid');
  assert.deepEqual(context.identity.duplicateIds, []);
  assert.deepEqual(context.identity.unresolvedTargetIds, []);
  assert.equal(context.pending.operations.length, 3);
  assert.deepEqual(context.pending.operations[0].targetIds, ['title']);
  assert.equal(context.nextAction, 'apply-studio-revision');

  const stylesBeforeUnsafeConflict = await readFile(path.join(fixture, 'styles.css'), 'utf8');
  await writeFile(path.join(fixture, 'styles.css'), `${stylesBeforeUnsafeConflict}\n/* concurrent Codex change */\n`, 'utf8');
  const conflicted = spawnSync(process.execPath, ['ui-sync.mjs','context'], { cwd:fixture, encoding:'utf8' });
  assert.equal(conflicted.status, 0, conflicted.stderr || conflicted.stdout);
  assert.equal(JSON.parse(conflicted.stdout).latestUI.state, 'conflict');
  const blockedApply = spawnSync(process.execPath, ['ui-sync.mjs','apply'], { cwd:fixture, encoding:'utf8' });
  assert.notEqual(blockedApply.status, 0, 'A conflict must never be applied implicitly');
  const refusedUnsafeResolution = spawnSync(process.execPath, ['ui-sync.mjs','resolve-safe'], { cwd:fixture, encoding:'utf8' });
  assert.notEqual(refusedUnsafeResolution.status, 0, 'Text and structural conflicts require a manual merge');
  await writeFile(path.join(fixture, 'styles.css'), stylesBeforeUnsafeConflict, 'utf8');

  const applied = spawnSync(process.execPath, ['ui-sync.mjs','apply'], { cwd:fixture, encoding:'utf8' });
  assert.equal(applied.status, 0, applied.stderr || applied.stdout);
  const html = await readFile(path.join(fixture, 'index.html'), 'utf8');
  const css = await readFile(path.join(fixture, 'ui-studio-overrides.css'), 'utf8');
  assert.match(html, />New<\/span>/);
  assert.match(html, /ui-studio-overrides\.css/);
  assert.match(html, /ui-studio-structure\.js/);
  assert.match(css, /color: #ff0000 !important/);
  assert.match(await readFile(path.join(fixture, 'ui-studio-structure.js'), 'utf8'), /cloneNode\(true\)/);

  bridge = spawn(process.execPath, ['studio-bridge.mjs'], {
    cwd:fixture,
    env:{ ...process.env, UI_STUDIO_PORT:String(port) },
    stdio:['ignore','pipe','pipe'],
  });
  await waitForServer();
  const styleOnlyCurrent = await request('/__ui_sync/document');
  const styleOnlyDocument = styleOnlyCurrent.data.document;
  styleOnlyDocument.overrides.title.color = '#00ff00';
  const styleOnlySaved = await request('/__ui_sync/document', { method:'PUT', body:JSON.stringify({ expectedRevision:3, document:styleOnlyDocument, operations:[{ type:'property.change', targetIds:['title'], detail:{ key:'color' } }] }) });
  assert.equal(styleOnlySaved.response.status, 200);
  assert.equal(styleOnlySaved.data.document.revision, 4);
  bridge.kill();
  await new Promise((resolve) => bridge.once('exit', resolve));
  bridge = null;

  const stylesBeforeSafeConflict = await readFile(path.join(fixture, 'styles.css'), 'utf8');
  await writeFile(path.join(fixture, 'styles.css'), `${stylesBeforeSafeConflict}\n/* safe concurrent Codex change */\n`, 'utf8');
  const styleConflict = spawnSync(process.execPath, ['ui-sync.mjs','context'], { cwd:fixture, encoding:'utf8' });
  assert.equal(JSON.parse(styleConflict.stdout).latestUI.state, 'conflict');
  const resolved = spawnSync(process.execPath, ['ui-sync.mjs','resolve-safe'], { cwd:fixture, encoding:'utf8' });
  assert.equal(resolved.status, 0, resolved.stderr || resolved.stdout);
  const rebased = spawnSync(process.execPath, ['ui-sync.mjs','context'], { cwd:fixture, encoding:'utf8' });
  assert.equal(JSON.parse(rebased.stdout).latestUI.state, 'pending-codex');
  const appliedRebase = spawnSync(process.execPath, ['ui-sync.mjs','apply'], { cwd:fixture, encoding:'utf8' });
  assert.equal(appliedRebase.status, 0, appliedRebase.stderr || appliedRebase.stdout);
  assert.match(await readFile(path.join(fixture, 'styles.css'), 'utf8'), /safe concurrent Codex change/);
  assert.match(await readFile(path.join(fixture, 'ui-studio-overrides.css'), 'utf8'), /color: #00ff00 !important/);
  const refreshed = spawnSync(process.execPath, ['ui-sync.mjs','refresh-generated'], { cwd:fixture, encoding:'utf8' });
  assert.equal(refreshed.status, 0, refreshed.stderr || refreshed.stdout);

  await writeFile(path.join(fixture, 'styles.css'), `${await readFile(path.join(fixture, 'styles.css'), 'utf8')}\n/* Codex change */\n`, 'utf8');
  const sourceUpdated = spawnSync(process.execPath, ['ui-sync.mjs','source-updated'], { cwd:fixture, encoding:'utf8' });
  assert.equal(sourceUpdated.status, 0, sourceUpdated.stderr || sourceUpdated.stdout);
  assert.match(sourceUpdated.stdout, /源码领先/);

  console.log('UI Studio round-trip smoke: PASS');
  console.log('invalid schema/SVG 400 → live preview patch + pending-codex → rollback/forward → identity gate → stale 409 → canonical apply → clean → source-ahead');
} finally {
  if (bridge) bridge.kill();
  const resolvedFixture = path.resolve(fixture);
  const resolvedTemp = path.resolve(os.tmpdir());
  if (!resolvedFixture.startsWith(`${resolvedTemp}${path.sep}`) || !path.basename(resolvedFixture).startsWith('ui-studio-sync-')) throw new Error(`拒绝清理非测试目录：${resolvedFixture}`);
  await rm(resolvedFixture, { recursive:true, force:true, maxRetries:10, retryDelay:120 });
}
