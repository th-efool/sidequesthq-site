import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { copyFile, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const sourceRoot = path.resolve(import.meta.dirname, '..');
const fixture = await mkdtemp(path.join(os.tmpdir(), 'ui-studio-reliability-'));
const port = 44500 + Math.floor(Math.random() * 900);
let bridge;

async function request(pathname, options = {}) {
  const response = await fetch(`http://127.0.0.1:${port}${pathname}`, {
    headers: { 'Content-Type':'application/json' },
    ...options,
  });
  const data = await response.json();
  return { response, data };
}

async function waitForServer() {
  let lastError;
  for (let attempt = 0; attempt < 50; attempt += 1) {
    try {
      const result = await request('/__ui_sync/status');
      if (result.response.ok) return result.data;
    } catch (error) { lastError = error; }
    await new Promise((resolve) => setTimeout(resolve, 80));
  }
  throw lastError || new Error('同步桥启动超时');
}

try {
  for (const file of ['ui-document-v4.mjs', 'ui-sync-core.mjs', 'ui-fidelity-core.mjs', 'local-ocr.mjs', 'studio-bridge.mjs']) {
    await copyFile(path.join(sourceRoot, file), path.join(fixture, file));
  }
  await mkdir(path.join(fixture, 'scripts'), { recursive:true });
  await copyFile(path.join(sourceRoot, 'scripts', 'windows-native-ocr.ps1'), path.join(fixture, 'scripts', 'windows-native-ocr.ps1'));
  await writeFile(path.join(fixture, 'index.html'), '<!doctype html><main data-ui-id="page"><span data-ui-id="title">Title</span></main>\n', 'utf8');
  await writeFile(path.join(fixture, 'styles.css'), '[data-ui-id="title"] { color: black; }\n', 'utf8');
  await writeFile(path.join(fixture, 'app.js'), 'console.log("fixture");\n', 'utf8');

  const { atomicWriteBundle, recoverAtomicBundle } = await import(pathToFileURL(path.join(sourceRoot, 'ui-sync-core.mjs')));
  const transactionDirectory = path.join(fixture, 'transaction-test');
  const transactionFile = path.join(transactionDirectory, 'transaction.json');
  const firstTarget = path.join(transactionDirectory, 'first.json');
  const secondTarget = path.join(transactionDirectory, 'second.json');
  await atomicWriteBundle(transactionFile, [
    { file:firstTarget, value:{ revision:1 } },
    { file:secondTarget, value:{ revision:1 } },
  ]);
  assert.equal(JSON.parse(await readFile(firstTarget, 'utf8')).revision, 1);
  assert.equal(JSON.parse(await readFile(secondTarget, 'utf8')).revision, 1);

  await mkdir(transactionDirectory, { recursive:true });
  const interruptedTemp = path.join(transactionDirectory, 'first.interrupted.txn');
  await writeFile(interruptedTemp, '{"revision":2}\n', 'utf8');
  await writeFile(transactionFile, JSON.stringify({
    version:1,
    entries:[{ target:firstTarget, temp:interruptedTemp }],
  }), 'utf8');
  assert.equal(await recoverAtomicBundle(transactionFile), true);
  assert.equal(JSON.parse(await readFile(firstTarget, 'utf8')).revision, 2, '启动时应完成中断事务');

  bridge = spawn(process.execPath, ['studio-bridge.mjs'], {
    cwd:fixture,
    env:{ ...process.env, UI_STUDIO_PORT:String(port) },
    stdio:['ignore', 'pipe', 'pipe'],
  });

  const initial = await waitForServer();
  assert.equal(initial.studioBuildVersion, '2.13.0');
  assert.equal(initial.projectId, path.basename(fixture));
  assert.equal(initial.documentRevision, 0);

  const clientVersion = await request('/__ui_sync/client-version');
  assert.equal(clientVersion.response.status, 200);
  assert.equal(clientVersion.data.studioBuildVersion, '2.13.0');

  const current = await request('/__ui_sync/document');
  const firstDocument = structuredClone(current.data.document);
  const secondDocument = structuredClone(current.data.document);
  firstDocument.overrides = { title:{ color:'#ff0000' } };
  secondDocument.overrides = { title:{ color:'#0000ff' } };

  const contenders = await Promise.all([
    request('/__ui_sync/document', {
      method:'PUT',
      body:JSON.stringify({ expectedRevision:0, document:firstDocument }),
    }),
    request('/__ui_sync/document', {
      method:'PUT',
      body:JSON.stringify({ expectedRevision:0, document:secondDocument }),
    }),
  ]);
  const statuses = contenders.map(({ response }) => response.status).sort((a, b) => a - b);
  assert.deepEqual(statuses, [200, 409], '相同基线修订只能有一个写入成功');
  const conflict = contenders.find(({ response }) => response.status === 409);
  assert.equal(conflict.data.error, 'revision.conflict');

  const afterRace = await request('/__ui_sync/status');
  assert.equal(afterRace.data.documentRevision, 1, '并发竞争只能生成一个新修订');

  const studioSource = await readFile(path.join(sourceRoot, 'studio.js'), 'utf8');
  for (const contract of [
    /DRAFT_SCHEMA_VERSION\s*=\s*2/,
    /RECOVERY_DRAFT_KEY/,
    /baseSourceHash/,
    /clientId/,
    /visibilitychange/,
    /checkStudioBuild/,
  ]) assert.match(studioSource, contract);

  console.log('sync reliability smoke: ok');
} finally {
  if (bridge) {
    await new Promise((resolve) => {
      if (bridge.exitCode !== null) { resolve(); return; }
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        resolve();
      };
      const timeout = setTimeout(finish, 2000);
      bridge.once('exit', finish);
      bridge.kill();
    });
  }
  await rm(fixture, { recursive:true, force:true });
}
