import assert from 'node:assert/strict';
import { createUIDocumentV4, migrateUIDocument, normalizeSemanticOperations, validateUIDocumentV4 } from '../ui-document-v4.mjs';

const hash = 'a'.repeat(64);
const legacy = {
  protocolVersion:1,
  version:3,
  documentId:'fixture',
  revision:7,
  baseSourceHash:hash,
  canvas:{ width:1440, height:900 },
  overrides:{ title:{ textContent:'新标题' } },
  iconReplacements:{},
  updatedAt:'2026-08-12T00:00:00.000Z',
  updatedBy:'studio',
};
const migrated = migrateUIDocument(legacy, hash, 1);
assert.equal(migrated.version, 4);
assert.equal(migrated.revision, 7);
assert.equal(migrated.overrides.title.textContent, '新标题');
assert.deepEqual(migrated.nodes, []);
validateUIDocumentV4(migrated);

const document = createUIDocumentV4(hash, 1);
document.source.references.push({ id:'ref-home', name:'home.png', path:'/.ui-studio/references/ref-home.png', width:1440, height:900, createdAt:new Date().toISOString() });
document.nodes.push({ id:'analysis.ref-home.frame.1', name:'主框架', type:'frame', parentId:null, bounds:{ x:0, y:0, width:1440, height:900 }, layout:{ mode:'free' } });
document.evidence = {
  activeRunId:'run-home',
  runs:[{ id:'run-home', referenceId:'ref-home', candidateCount:1, acceptedCount:1, createdAt:new Date().toISOString() }],
  items:{ 'analysis.ref-home.frame.1':{ referenceId:'ref-home', runId:'run-home', confidence:0.91, source:'pixel-structure' } },
};
validateUIDocumentV4(document);

const operations = normalizeSemanticOperations([{ type:'analysis.confirm', targetIds:['analysis.ref-home.frame.1'], detail:{ accepted:1 } }], 8);
assert.equal(operations[0].revision, 8);
assert.equal(operations[0].type, 'analysis.confirm');

const invalid = structuredClone(document);
invalid.source.references[0].path = 'C:/Windows/system32/bad.png';
assert.throws(() => validateUIDocumentV4(invalid), /路径不在允许目录/);

console.log('UI Document V3 → V4 migration and schema: PASS');
