import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../studio.js', import.meta.url), 'utf8');

const checks = [
  ['new projects detect whether the demo route adapter applies', /const hasKnownPageContract\s*=/],
  ['unknown identity namespaces use a generic DOM hierarchy', /if \(!hasKnownPageContract\)[\s\S]*appendGenericSubtree/],
  ['unresolved parent links remain visible', /nodes\.filter\(\(node\) => !used\.has\(node\.id\)\)\.forEach/],
  ['partially matching route adapters cannot hide imported identities', /PAGE_ROUTES\.forEach[\s\S]*nodes\.filter\(\(node\) => !used\.has\(node\.id\)\)\.forEach\(\(node\) => appendGenericSubtree\(node\)\)/],
  ['page context comes from the imported document', /function currentPageContext\(\)[\s\S]*frameDocument\.title/],
  ['stale selections are removed after a page swap', /selectedIds = new Set\(\[\.\.\.selectedIds\]\.filter/],
  ['layer labels detect the imported page language', /function frameLanguage\(\)[\s\S]*documentElement\?\.lang[\s\S]*body\?\.innerText/],
  ['generic technical names have localized semantic replacements', /const LOCAL_LAYER_NAMES\s*=\s*\{[\s\S]*zh:\{[\s\S]*page:'\u9875\u9762'[\s\S]*icon:'\u56fe\u6807'/],
  ['visible and accessible UI text outrank generator metadata', /function describeLayer\([\s\S]*directText[\s\S]*attributeText[\s\S]*contextualIcon[\s\S]*rawName/],
  ['icons inherit their labeled control context', /function iconContextLabel\([\s\S]*closest\?\.\('button,a,\[role="button"\]/],
  ['the generic tree renders the route or localized display name', /viewLabel:route\?\.label \|\| node\.displayName \|\| node\.text \|\| labelFor/],
  ['hash aliases reuse an existing view route instead of creating duplicate pages', /rawHref\.startsWith\('#'\)[\s\S]*matchingView[\s\S]*matchingTrigger[\s\S]*target = hashTarget/],
];

let failed = false;
for (const [label, pattern] of checks) {
  const passed = pattern.test(source);
  console.log(`${passed ? 'PASS' : 'FAIL'} ${label}`);
  failed ||= !passed;
}

if (failed) process.exitCode = 1;
else console.log('Generic layer tree contract: PASS');
