import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const [source, html, css] = await Promise.all([
  readFile(path.join(root, 'studio.js'), 'utf8'),
  readFile(path.join(root, 'studio.html'), 'utf8'),
  readFile(path.join(root, 'studio.css'), 'utf8'),
]);

const checks = [
  ['shortcut layer has an independent version', /SHORTCUT_LAYER_VERSION\s*=\s*['"]1\.2\.0['"]/.test(source)],
  ['Delete and Backspace use undoable layer deletion', /event\.key === 'Delete'[\s\S]*event\.key === 'Backspace'[\s\S]*deleteSelection\(\)/.test(source) && /type:cut \? 'clipboard\.cut' : 'layer\.delete'/.test(source)],
  ['clipboard is stable-ID based', /function captureLayerClipboard\(/.test(source) && /sourceId:id/.test(source) && /CLIPBOARD_KEY/.test(source)],
  ['paste and paste appearance are separate commands', /function pasteLayerClipboard\(/.test(source) && /clipboard\.paste-appearance/.test(source)],
  ['true duplicate is a separate persistent command', /function duplicateSelection\(/.test(source) && /type:'layer\.duplicate'/.test(source) && /command && key === 'j'/.test(source)],
  ['Alt drag creates one undoable persistent duplicate gesture', /duplicateDrag = direction === 'move' && event\.altKey/.test(source) && /type:duplicateDrag \? 'layer\.duplicate-drag'/.test(source) && /duplicateSelection\(\{ commit:false, notify:false \}\)/.test(source)],
  ['stacking accelerators support step and extreme moves', /arrangeSelectionStack\(event\.shiftKey \? 'front' : 'forward'\)/.test(source) && /arrangeSelectionStack\(event\.shiftKey \? 'back' : 'backward'\)/.test(source)],
  ['alignment accelerators reuse multi-selection commands', /applyMultiAction\(\{ arrowleft:'align-left'/.test(source) && /applyMultiAction\('distribute-x'\)/.test(source)],
  ['marquee selection is a dedicated pointer gesture', /function beginMarqueeSelection\(/.test(source) && /ui-studio-marquee/.test(source) && /suppressCanvasClick/.test(source)],
  ['visibility and lock commands are additive', /toggleSelectionVisibility/.test(source) && /toggleSelectionLock/.test(source)],
  ['layer rename is keyboard discoverable and persistent', /event\.key === 'F2'/.test(source) && /layerMetadata\[id\]/.test(source) && /重命名图层/.test(html)],
  ['undo supports both Photoshop and Windows redo', /event\.key\.toLowerCase\(\) === 'z'/.test(source) && /key === 'y'/.test(source)],
  ['iframe receives the same shortcuts as Studio chrome', /frameDocument\.addEventListener\('keydown', handleStudioKeydown\)/.test(source)],
  ['text editing is protected', /function editingTarget\([\s\S]*contenteditable/.test(source) && /if \(typing\) return;/.test(source)],
  ['selection and canvas accelerators exist', /selectAllInContext\(\)/.test(source) && /cycleSelection\(event\.shiftKey\)/.test(source) && /applyCanvasFitMode\('actual'\)/.test(source)],
  ['discoverable shortcut dialog exists', /id="shortcut-dialog"/.test(html) && /id="open-shortcuts"/.test(html) && /拖动时创建真实副本/.test(html) && /背景框选图层/.test(html)],
  ['shortcut dialog has responsive professional styling', /\.shortcut-grid/.test(css) && /@media \(max-width: 820px\)/.test(css)],
];

for (const [name, pass] of checks) {
  assert.ok(pass, name);
  console.log(`PASS ${name}`);
}

console.log(`Keyboard shortcut contract PASS (${checks.length} invariants)`);
