import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const [css, html, js] = await Promise.all([
  readFile(path.join(root, 'studio.css'), 'utf8'),
  readFile(path.join(root, 'studio.html'), 'utf8'),
  readFile(path.join(root, 'studio.js'), 'utf8'),
]);

assert.match(css, /--control-hit-compact:\s*32px/);
assert.match(css, /--control-hit-standard:\s*36px/);
assert.match(css, /--control-glyph:\s*17px/);
assert.match(css, /\.selection-card button[^}]*width:\s*var\(--control-hit-compact\)[^}]*height:\s*var\(--control-hit-compact\)/s);
assert.match(css, /\.panel-edge-toggle[^}]*width:\s*24px[^}]*height:\s*44px/s);
assert.match(css, /\.panel-edge-toggle[^}]*top:\s*30px[^}]*border-radius:\s*8px[^}]*opacity:\s*\.58/s);
assert.match(css, /\.panel-edge-toggle\.left[^}]*left:\s*27px/s);
assert.match(css, /\.panel-edge-toggle\.right[^}]*right:\s*7px/s);
assert.match(css, /\.panel-edge-toggle:hover[^}]*opacity:\s*1/s);
assert.match(css, /\.panel-toggle-chevron[^}]*stroke-width:\s*1\.75/s);
assert.match(html, /<summary>辅助\s*<span>/);
assert.match(html, /id="toggle-hand"[^>]*>平移<\/button>/);
assert.match(html, /id="toggle-layers"[^>]*>图层栏<\/button>/);
assert.match(html, /id="toggle-inspector"[^>]*>属性栏<\/button>/);
assert.match(html, /id="export-html" class="toolbar-button export-main"/);
assert.match(js, /handToggle\.setAttribute\('aria-pressed', String\(handToolEnabled\)\)/);
assert.match(css, /\.inspector-section\s*>\s*summary[^}]*min-height:\s*42px/s);
assert.match(css, /\.sync-history-row button[^}]*min-height:\s*34px/s);
assert.match(css, /\.toolbar-group button[^}]*height:\s*var\(--control-hit-compact\)/s);
assert.match(css, /\.layer-search[^}]*height:\s*var\(--control-hit-standard\)/s);
assert.match(css, /\.layer-options label[^}]*height:\s*34px/s);
assert.match(css, /\.layer-row[^}]*min-height:\s*36px/s);
assert.match(css, /\.layer-row \.tree-disclosure[^}]*width:\s*30px[^}]*height:\s*30px/s);
assert.match(css, /\.layer-row \.mini[^}]*width:\s*30px[^}]*height:\s*30px/s);
assert.match(css, /\.layer-row-actions[^}]*min-width:\s*63px[^}]*height:\s*32px/s);
assert.match(js, /function\s+layerActionIcon\s*\(/);
assert.match(js, /aria-label="\$\{isHidden \? '显示' : '隐藏'\}/);
assert.match(js, /aria-label="\$\{inheritedLock \? '由父级锁定'/);
assert.match(js, /图层操作">\$\{visibilityAction\}\$\{lockAction\}/);
assert.doesNotMatch(js, /class="mini route-enter"/);
assert.doesNotMatch(js, /class="mini visibility[^`]*>◉<\/button>/);
assert.doesNotMatch(js, /class="mini lock[^`]*>[●◌○]<\/button>/);

for (const id of ['sync-history-select', 'sync-restore', 'open-preview']) {
  assert.match(html, new RegExp(`id=["']${id}["']`));
}
assert.match(html, />(?:项目预览|精准预览)</);
assert.match(js, /function\s+openProjectPreview\s*\(/);
assert.match(js, /function\s+restoreSyncHistory\s*\(/);

console.log('Studio control hit-target contract: PASS');
