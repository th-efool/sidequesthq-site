import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const [source, css] = await Promise.all([
  readFile(path.join(root, 'studio.js'), 'utf8'),
  readFile(path.join(root, 'studio.css'), 'utf8'),
]);

assert.match(css, /\.canvas-area\s*\{[^}]*overflow:\s*hidden/s, '画布必须裁切编辑覆盖层');
assert.match(css, /\.ui-studio-selection\s*\{[^}]*position:\s*absolute/s, '选框必须使用画布局部坐标');
assert.match(source, /\$\('\.canvas-area'\)\.append\(selectionBox\)/, '选框必须挂载到画布容器');
assert.match(source, /frameRect\.left\s*-\s*canvasAreaRect\.left/, '选框横坐标必须转换为画布局部坐标');
assert.match(source, /frameRect\.top\s*-\s*canvasAreaRect\.top/, '选框纵坐标必须转换为画布局部坐标');
assert.match(source, /getCoalescedEvents\?\.\(\)/, '高频指针事件必须读取合并采样');
assert.match(source, /requestAnimationFrame\(flushMove\)/, '对象拖动必须按动画帧合并');
assert.match(source, /requestAnimationFrame\(flushPan\)/, '画布平移必须按动画帧合并');
assert.match(source, /SNAP_GUIDE_RELEASE_SCREEN_PX\s*=\s*5/, 'Guide snapping must retain only a small release hysteresis');
assert.match(source, /SNAP_STRUCTURE_RELEASE_SCREEN_PX\s*=\s*6/, 'Structure snapping must retain only a small release hysteresis');
assert.match(source, /distance <= releaseDistance && !betterFreshTarget/, 'Sticky snapping must release or switch without high-force magnetism');
assert.match(source, /applyLivePosition\(/, '移动期间必须走轻量 translate 路径');
assert.doesNotMatch(source, /move\.commitTimer/, '拖动中不得产生半途历史提交');
assert.match(source, /keyEvent\.key\s*!==\s*'Escape'/, 'Escape 必须可以取消当前拖动');
assert.match(source, /if\s*\(studioDirty\)\s*return/, '脏状态刷新必须幂等');

assert.match(source, /requestAnimationFrame\(manipulationAutoPanStep\)/, 'Edge auto-pan must stay frame-coalesced');
assert.match(source, /MANIPULATION_AUTO_PAN_EDGE\s*=\s*56/, 'Edge auto-pan must use a fixed screen-space activation zone');
assert.match(source, /function\s+updateLiveGeometryInputs\s*\(/, 'Live resize must update only geometry inputs');
assert.match(source, /function\s+applyMove\s*\([\s\S]*applyLiveResizeGeometry\(selectedId\)[\s\S]*predictedResizeRect\([\s\S]*function\s+flushMove/, 'Live resize frames must use geometry writes plus a predicted selection rectangle');
assert.doesNotMatch(source, /function\s+applyMove\s*\([\s\S]*stabilizeResizeAnchor\([\s\S]*function\s+flushMove/, 'Live resize frames must not force a DOM measurement');
assert.match(source, /function\s+end\s*\([\s\S]*stabilizeResizeAnchor\(selectedId, direction, startRect/, 'Pointer release must perform one exact DOM reconciliation');
assert.match(source, /function\s+liveGeometryValue\s*\([\s\S]*\* 100\) \/ 100/, 'Low-zoom resize must preserve fractional document geometry');
assert.match(css, /object-manipulating\[data-manipulation="n"\][\s\S]{0,260}cursor:\s*ns-resize\s*!important/s, 'The resize cursor must stay locked after pointer capture');
assert.match(css, /ui-studio-selection\[data-active-direction="n"\][\s\S]{0,600}display:\s*block/s, 'The active midpoint handle must survive compact-mode redraws');
assert.match(css, /ui-studio-selection\[data-compact="true"\][^}]*ui-studio-edge\[data-dir="e"\][\s\S]{0,180}top:\s*6px;\s*bottom:\s*6px/s, 'Compact selections must retain a usable full-height west/east resize target');
assert.doesNotMatch(source, /inspectorFrame/, 'Live manipulation must not periodically rebuild the full inspector');
assert.doesNotMatch(source, /cameraAutoPanned\s*=\s*true;[\s\S]{0,260}requestAnimationFrame\(flushMove\)/, 'Auto-pan must not defer DOM geometry into a second frame');
assert.match(source, /drawSelection\(offsetRectSnapshot\(startRect, dx, dy\), gestureRenderContext\)/, 'Move overlay must use deterministic geometry without a live layout read');
assert.match(source, /const resizeRect = predictedResizeRect[\s\S]{0,220}drawSelection\(resizeRect, gestureRenderContext\)/, 'Resize overlay must reuse deterministic current-frame geometry');
assert.match(css, /\.ui-studio-edge\[data-dir="n"\], \.ui-studio-edge\[data-dir="s"\][^}]*height:\s*28px/s, 'Height resize must use a forgiving fixed-screen hit zone');
assert.match(css, /\.ui-studio-move-grip[^}]*top:\s*-46px[^}]*height:\s*28px/s, 'Move chrome must stay separated from the resize edge');
assert.match(css, /\.ui-studio-move-surface\s*\{[^}]*inset:\s*0/s, 'The move surface must never collapse at low zoom');
assert.match(css, /ui-studio-selection\[data-compact="true"\][^}]*ui-studio-edge\[data-dir="s"\][^}]*height:\s*18px/s, 'Compact selections must preserve a center move target');
assert.match(source, /let gestureFinished = false/, 'Manipulation completion must be idempotent');
assert.match(source, /lostpointercapture[\s\S]*finishOnLostPointerCapture/, 'Pointer capture loss must finalize the active edit');
assert.match(source, /window\.addEventListener\('blur', finishOnBlur, true\)/, 'Window deactivation must not leave a stuck manipulation');
assert.match(source, /window\.addEventListener\('mouseup', finishOnMouseUp, true\)/, 'Mouse release must finalize even when pointerup is lost');
assert.match(source, /moveEvent\.pointerType === 'mouse' && moveEvent\.buttons === 0/, 'A released mouse must not leave a suspended gesture');
assert.match(source, /let width = start\.width;\s*let height = start\.height;\s*if \(direction === 'move'\)/, 'Resize geometry must remain in scope through live overlay rendering');
assert.doesNotMatch(source, /let width = start\.width \+/, 'Resize dimensions must not be block-scoped before overlay rendering');
assert.match(source, /drawSelection\(selectionUnionRect\(\)\)/, 'Pointer release must finish with one authoritative DOM measurement');
assert.match(source, /function\s+selectionRenderContext\s*\(/, 'A manipulation must cache its frame-to-canvas coordinate system');
assert.match(source, /function\s+positionSelectionOverlay\s*\(/, 'Selection chrome must use a dedicated compositor write path');
assert.match(source, /!Number\.isFinite\(selectionRenderState\.x\)/, 'The first selection frame must always initialize compositor geometry');
assert.match(source, /setProperty\('height', `\$\{number\(value\.height\)\}px`, 'important'\)/, 'The live draft must override the previous generated revision while resizing');
assert.match(source, /setProperty\('translate', `\$\{nextX\}px \$\{nextY\}px`, 'important'\)/, 'The live draft must override the previous generated revision while moving');
assert.match(source, /translate3d\(\$\{x\}px, \$\{y\}px, 0\)/, 'Selection position must move on the compositor');
assert.match(source, /gestureRenderContext\.frameRect\.left\s*-=/, 'Auto-pan must incrementally update cached overlay coordinates');
assert.match(css, /object-manipulating \.ui-studio-selection[^}]*will-change:\s*transform, width, height/s, 'Live selection chrome must not animate layout-position properties');

console.log('Studio interaction motion contract: PASS');
console.log('canvas clipping → rAF coalescing → sticky snap → atomic history');
