import { existsSync, readFileSync } from 'node:fs';

const studio = readFileSync(new URL('../studio.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../studio.html', import.meta.url), 'utf8');
const manifestUrl = new URL('../.ui-job/project-menu.json', import.meta.url);
const requireProjectManifest = process.argv.includes('--require-project');

const engineRequirements = [
  ['action buttons are menu evidence', studio.includes('nav button[data-action][data-ui-id]') && studio.includes('aside button[data-action][data-ui-id]')],
  ['project menu is the first structure view', studio.includes("root.innerHTML = '<svg") && studio.includes('<span>项目菜单</span>')],
  ['project menu and layers share one persistent tree', studio.includes('const shouldShow = uniqueEntries.length > 0') && studio.includes("className = 'page-directory-layers'")],
  ['single click only switches the real UI', studio.includes("activatePageRoute(entry, { fromDirectory:true, expand:false })")],
  ['double click expands layers inline', studio.includes("main.addEventListener('dblclick'") && studio.includes("activatePageRoute(entry, { fromDirectory:true, expand:true })")],
  ['layer count and chevron are a dedicated disclosure target', studio.includes("className = 'page-directory-disclosure'") && studio.includes("disclosure.addEventListener('click'")],
  ['nested project menus remain recursive', studio.includes('parentTriggerId') && studio.includes('childrenByParent') && studio.includes('appendEntry(child, depth + 1')],
  ['no second page or back-navigation mode is rendered', !html.includes('id="page-tree-back"')],
  ['page and action entries stay distinct', studio.includes("const kind = target || href ? 'page' : 'action'")],
  ['only page entries can own the current-page identity', studio.includes("entry.kind === 'page' && entry.active") && studio.includes("if (currentPage) branch.setAttribute('aria-current', 'page')")],
  ['actions wait for a stable UI before rebuilding layers', studio.includes('activeTransientMenuKey = latest.key') && studio.includes('buildLayers();')],
  ['active page layer count is sourced from the live production DOM', studio.includes('syncActivePageLayerCount') && studio.includes("root.querySelectorAll('[data-ui-id]').length")],
  ['inactive page counts use an isolated renderer', studio.includes('scanProjectPageLayerCounts') && studio.includes("className = 'page-layer-scan-frame'")],
  ['count scanning cannot move the editable canvas', studio.includes('left:-10000px;top:-10000px') && studio.includes('pointer-events:none')],
  ['dynamic entries never pretend to have a fixed count', studio.includes("entry.kind === 'action'") && studio.includes("? '动态'")],
  ['pending recognition is not a terminal menu state', !studio.includes("'待识别'")],
  ['expanded state survives redraw without changing canvas camera', studio.includes('PAGE_EXPANDED_KEY') && studio.includes('setExpandedPageKey')],
];

const failed = engineRequirements.filter(([, passed]) => !passed).map(([name]) => name);
if (failed.length) {
  console.error(`Project menu engine contract: FAIL\nMissing: ${failed.join(', ')}`);
  process.exit(1);
}

if (!existsSync(manifestUrl)) {
  if (requireProjectManifest) {
    console.error('Project menu integration contract: FAIL\nMissing: .ui-job/project-menu.json');
    process.exit(1);
  }
  console.log(`Project menu engine contract: PASS (${engineRequirements.length} generic behaviors locked; project manifest pending)`);
  process.exit(0);
}

const manifest = JSON.parse(readFileSync(manifestUrl, 'utf8'));
const expectedTree = {
  mode: 'persistent-inline',
  activation: 'single-click-switch-ui-only',
  drilldown: 'double-click-or-disclosure',
  selection: 'independent',
  camera: 'preserve',
  counts: 'live-truth',
  labels: 'visible-ui-language',
  currentPage: 'exactly-one',
};
const menus = Array.isArray(manifest.menus) ? manifest.menus : [];
const treeMatches = JSON.stringify(manifest.studioTree) === JSON.stringify(expectedTree);
const identitiesAreStable = menus.length > 0 && menus.every((entry) => entry && entry.id && entry.label && entry.trigger?.value && entry.destination?.id);
const pageCountsAreMeasured = menus.every((entry) => {
  if (entry?.destination?.kind !== 'page' || !entry.bound) return true;
  return Number.isInteger(entry.layerCount?.count)
    && entry.layerCount.count > 0
    && ['live-dom', 'isolated-browser'].includes(entry.layerCount.source)
    && Boolean(entry.layerCount.measuredAt);
});

const integrationFailures = [];
if (manifest.schemaVersion !== 1 || manifest.status !== 'ready') integrationFailures.push('ready schemaVersion 1 manifest');
if (!treeMatches) integrationFailures.push('persistent inline Studio tree contract');
if (!identitiesAreStable) integrationFailures.push('stable localized menu identities');
if (!pageCountsAreMeasured) integrationFailures.push('truthful measured page layer counts');

if (integrationFailures.length) {
  console.error(`Project menu integration contract: FAIL\nMissing: ${integrationFailures.join(', ')}`);
  process.exit(1);
}

console.log(`Project menu contract: PASS (${engineRequirements.length} generic behaviors, ${menus.length} project identities)`);
