import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');
const [html, css, studio, commandCore] = await Promise.all([
  readFile(resolve(root, 'studio.html'), 'utf8'),
  readFile(resolve(root, 'studio.css'), 'utf8'),
  readFile(resolve(root, 'studio.js'), 'utf8'),
  readFile(resolve(root, 'ui-command-core.js'), 'utf8'),
]);

const commandCoreIndex = html.indexOf('<script src="ui-command-core.js"></script>');
const studioIndex = html.indexOf('<script src="studio.js"></script>');

assert.ok(commandCoreIndex >= 0, 'Studio must load the command history core');
assert.ok(studioIndex > commandCoreIndex, 'Command history core must load before studio.js');
assert.match(html, /id="studio-statusbar"/, 'Studio must expose a persistent editing status bar');
assert.match(html, /id="empty-node-count"/, 'Empty inspector must summarize the current document');
assert.match(html, /id="open-page-directory"[^>]*>定位当前菜单</, 'Empty inspector must locate the current branch in the persistent project menu');
assert.match(html, /id="empty-page-name"/, 'Empty inspector must identify the active page dynamically');
assert.match(html, /id="collapse-empty-inspector"/, 'Empty inspector must support panel collapse');
assert.match(html, /id="reference-visible"[^>]*type="checkbox"/, 'Reference visibility must use an explicit checked control');
assert.match(html, /data-reference-layer="above"[\s\S]*data-reference-layer="below"/, 'Reference controls must explain both layer orders');
assert.match(html, /只影响编辑画布，不会进入保存或导出/, 'Reference controls must disclose that calibration is editor-only');
assert.doesNotMatch(html, /id="toggle-reference"/, 'Reference visibility must not be disguised as an ambiguous action button');
assert.doesNotMatch(html, /旧版临时叠图|编辑画布临时叠图/, 'Reference calibration must not expose duplicate legacy controls');
assert.match(html, /id="open-reference-control"/, 'Compare workspace must route back to the single reference control');
assert.match(html, /data-reference-layer="above"[^>]*data-keep-menu-open[\s\S]*data-reference-layer="below"[^>]*data-keep-menu-open/, 'Layer-order adjustments must keep the calibration popover open');
assert.doesNotMatch(html, /id="page-tree-back"/, 'The unified project menu must not regress into a separate layer page with a back action');
assert.match(html, /id="layer-page-directory"[^>]*role="tree"/, 'Multi-page projects must expose one persistent project-menu tree');

assert.match(css, /--statusbar-h:\s*28px/, 'The status bar height must remain part of shell geometry');
assert.match(css, /\.studio-statusbar\s*\{/, 'The status bar must keep dedicated styling');
assert.match(css, /\.studio-layout\s*\{[^}]*var\(--statusbar-h\)/s, 'Canvas shell height must reserve status-bar space');

assert.match(studio, /CANVAS_CORE_VERSION\s*=\s*'2\.13\.0'/, 'Canvas Core 2.13.0 must remain pinned');
assert.match(studio, /new UICommandHistory\(/, 'Studio must use the semantic command history');
assert.match(studio, /operations:\s*commandHistory\.operations\(\)/, 'Project saves must include semantic operations');
assert.match(studio, /function renderStatusBar\(/, 'Studio must continuously render workspace status');
assert.match(studio, /function undoCommand\(/, 'Undo must use the named command path');
assert.match(studio, /function redoCommand\(/, 'Redo must use the named command path');
assert.match(studio, /STYLE_KEYS\s*=\s*\[[^\]]*'display'/, 'Undo replay must manage display overrides so soft-delete can be restored');
assert.match(studio, /const baseStyles = new Map\(\)/, 'Studio must preserve immutable production inline styles for history replay');
assert.match(studio, /if \(!baseSizes\.has\(id\)\) baseSizes\.set/, 'Layer rebuilds must not replace the original geometry baseline');
assert.match(studio, /isTextElement\(element\) && !baseTexts\.has\(id\)/, 'Layer rebuilds must not replace the original text baseline');
assert.match(studio, /restoreBaseStyles\(element, id\)/, 'Applying a history snapshot must restore the production style baseline before overrides');
assert.match(studio, /frame\.addEventListener\('load',[\s\S]*baseSizes\.clear\(\);[\s\S]*baseTexts\.clear\(\);[\s\S]*baseStyles\.clear\(\);/, 'A real project reload must establish a fresh immutable baseline');
assert.match(studio, /DEDICATED_FEATURES/, 'Dedicated review workspaces must be isolated from production selection chrome');
assert.match(studio, /if \(isDedicatedFeature\(\)\) \{[\s\S]*selectionBox\.hidden = true/, 'Selection chrome must not leak into dedicated workspaces');
assert.match(studio, /canvasViewport\.clientWidth < 2 \|\| canvasViewport\.clientHeight < 2/, 'Hidden canvas resize events must not collapse the saved zoom');
assert.doesNotMatch(studio, /\[data-ui-id\]:hover/, 'Nested DOM hover must not draw parent and child outlines at the same time');
assert.match(studio, /function syncCanvasHover\(/, 'Canvas hover must explicitly track only the deepest semantic node');
assert.match(studio, /data-ui-studio-canvas-hover/, 'Canvas hover must use a single controlled marker');
assert.match(studio, /function applyReferenceViewState\(/, 'Reference overlay must have one state renderer');
assert.match(studio, /overlayImage\.style\.opacity = visible \? \(below \? '1'/, 'Reference-above mode must control reference opacity');
assert.match(studio, /frame\.style\.opacity = visible && below/, 'UI-above mode must use real reverse compositing instead of hiding the reference under an opaque frame');
assert.match(studio, /REFERENCE_VIEW_KEY/, 'Reference visibility, order and strength must persist across reloads');
assert.match(studio, /function openReferenceControl\(/, 'Secondary compare context must open the canonical reference control');
assert.match(studio, /\.toolbar-popover button:not\(\[data-keep-menu-open\]\)/, 'Continuous calibration controls must not close the popover after each click');
assert.match(studio, /function discoveredPageEntries\(/, 'Studio must discover page entries from the imported production UI');
assert.match(studio, /\[data-view-target\]\[data-ui-id\]/, 'SPA menu targets must become page-driven tree entries');
assert.match(studio, /function activatePageRoute\(/, 'Page rows must expose an explicit deep-entry action');
assert.match(studio, /if \(allowBoundPageAction\) return;/, 'Only explicit page activation may pass through the design-mode click shield');
assert.doesNotMatch(studio, /if \(node\.route\) \{\s*focusSelectedInCanvas\(\)/, 'Selecting a page row must not unexpectedly move the canvas camera');
assert.match(studio, /installPageContextObserver\(\)/, 'Page state changes must trigger a live tree refresh');
assert.match(studio, /savePageWorkspace\(activePageIdentity/, 'Page activation must preserve the previous page selection state');
assert.match(studio, /function renderPageDirectory\(/, 'Discovered routes must remain directly reachable from the page directory');
assert.doesNotMatch(studio, /function openPageDirectory\(/, 'The unified project menu must not keep a hidden second-page navigation mode');
assert.match(studio, /function focusProjectMenu\(\)/, 'The empty inspector action must focus the persistent menu without opening a second page mode');
assert.match(studio, /#open-page-directory'\)\.addEventListener\('click', focusProjectMenu\)/, 'The empty inspector must route to the persistent project menu');
assert.match(studio, /restorePageWorkspace\(latest\.key, pageEntryRootIds\(latest\)\)/, 'Inline expansion must restore remembered child layers without selecting the page root');
assert.match(studio, /function clearPageNavigationSelection\(/, 'Page navigation and layer selection must remain separate states');
assert.match(studio, /collapsedIds:\[\.\.\.collapsedNodes\]\.filter\(\(id\) => liveIds\.has\(id\)\)/, 'Each page workspace must remember its own expanded and collapsed tree state');
assert.match(studio, /ancestorIds\(selectedId\)\.forEach\(\(id\) => collapsedNodes\.delete\(id\)\)/, 'A restored child selection must be revealed instead of remaining hidden under a collapsed ancestor');
assert.match(studio, /excluded\.forEach\(\(id\) => collapsedNodes\.delete\(id\)\)/, 'Page roots must stay expanded while entering page detail');
assert.doesNotMatch(studio, /restorePageWorkspace\(nextKey, active\?\.containerId \|\| active\?\.triggerId/, 'Page activation must never fall back to the whole-page container');
assert.doesNotMatch(studio, /#select-current-page/, 'The legacy empty-state whole-page selection action must be removed');
assert.match(studio, /activatePageRoute\(entry, \{ fromDirectory:true, expand:false \}\)/, 'A single menu click must switch the real UI without entering layers');
assert.match(studio, /activatePageRoute\(entry, \{ fromDirectory:true, expand:true \}\)/, 'Double-click or disclosure must expand real layers inline');
assert.match(studio, /className = 'page-directory-layers'/, 'Expanded layers must stay inside the matching menu branch');
assert.match(studio, /viewDescendantIds\(allViewNodes, activeEntry\.id\)/, 'Inline layer expansion must isolate the active page and its real descendants');
assert.match(studio, /保持当前画布缩放与位置/, 'Page switching must communicate that the canvas camera is preserved');

assert.match(commandCore, /class UICommandHistory/, 'Command history must remain an isolated reusable module');
assert.match(commandCore, /mergeWindow/, 'Command history must coalesce rapid parameter edits');
assert.match(commandCore, /markSaved\(/, 'Command history must distinguish saved and unsaved state');

console.log('Studio foundation contract: PASS');
