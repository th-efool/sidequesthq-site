import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');
const readOptional = (name) => {
  const file = path.join(root, name);
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
};
const index = readOptional('index.html');
const styles = readOptional('styles.css');
const app = readOptional('app.js');
const studio = read('studio.html');
const studioJs = read('studio.js');
const preview = read('project-preview.html');

const assertions = [
  ['editor iframe uses parity profile', studio.includes('index.html?editor=1&amp;render=parity')],
  ['reloaded iframe keeps parity profile', studioJs.includes('index.html?editor=1&render=parity&sync=')],
  ['exact project preview uses real source', preview.includes('index.html?preview=project&render=parity')],
  ['exact project preview propagates revision identity', preview.includes('&revision=${revision}')],
  ['live preview is explicitly separate', studioJs.includes('index.html?preview=live&render=live')],
  ['exact preview receives the editor viewport', studioJs.includes('project-preview.html?width=${width}&height=${height}')],
  ['exact preview has a reliable in-studio dialog', studio.includes('id="project-preview-dialog"') && studio.includes('id="project-preview-frame"')],
  ['exact preview can reload the applied project', studioJs.includes('function reloadProjectPreview()')],
];

if (index.includes('dataset.renderProfile') && index.includes('styles.css')) {
  assertions.push(['render profile is decided before CSS loads', index.indexOf('dataset.renderProfile') < index.indexOf('styles.css')]);
}
if (styles) {
  assertions.push(
    ['legacy frame exception is gone', !styles.includes('html:not(.studio-frame)')],
    ['919px no longer triggers compact mode', !styles.includes('@media (max-height: 920px)')],
  );
  if (styles.includes('data-render-profile')) assertions.push(['compact rules are live-only', styles.includes('html[data-render-profile="live"]')]);
}
if (app) assertions.push(['browser localStorage is not a source override', !app.includes('tudoodoo-ui-studio-overrides-v1')]);

const failed = assertions.filter(([, passed]) => !passed);
assertions.forEach(([label, passed]) => console.log(`${passed ? 'PASS' : 'FAIL'} ${label}`));
if (failed.length) process.exit(1);
console.log(`Preview parity PASS (${assertions.length} invariants)`);
