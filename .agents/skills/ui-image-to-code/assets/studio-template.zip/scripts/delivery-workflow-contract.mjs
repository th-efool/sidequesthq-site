import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const [html, studio, css, bridge, syncCore, fidelity] = await Promise.all([
  readFile(path.join(root, 'studio.html'), 'utf8'),
  readFile(path.join(root, 'studio.js'), 'utf8'),
  readFile(path.join(root, 'studio.css'), 'utf8'),
  readFile(path.join(root, 'studio-bridge.mjs'), 'utf8'),
  readFile(path.join(root, 'ui-sync-core.mjs'), 'utf8'),
  readFile(path.join(root, 'ui-fidelity.js'), 'utf8'),
]);

for (const step of ['document', 'codex', 'source', 'verify']) {
  assert.match(html, new RegExp(`data-delivery-step="${step}"`), `missing delivery step: ${step}`);
}
for (const id of ['delivery-save-project', 'delivery-handoff-codex', 'delivery-exact-preview', 'delivery-open-compare']) {
  assert.match(html, new RegExp(`id="${id}"`), `missing delivery action: ${id}`);
  assert.match(studio, new RegExp(`#${id}`), `delivery action is not wired: ${id}`);
}
assert.match(studio, /function renderDeliveryStatus\(\)/);
assert.match(studio, /gate\.sourceHash === syncStatus\?\.currentPreviewSourceHash/);
assert.match(studio, /Number\(gate\.revision\) === appliedRevision/);
assert.match(studio, /activateFeature\('compare'\)/);
assert.match(css, /\.delivery-workflow li\[data-state="complete"\]/);
assert.match(bridge, /\/__ui_sync\/fidelity/);
assert.match(bridge, /proofKind === 'browser-capture'/);
assert.match(bridge, /computeFidelityGate/);
assert.match(fidelity, /scheduleGatePersistence/);
assert.match(fidelity, /ui-fidelity-updated/);
assert.match(syncCore, /randomUUID\(\)/, 'atomic temp files need collision-safe names');
assert.match(syncCore, /if \(!present\.document/);
assert.doesNotMatch(syncCore, /atomicWriteJSON\(paths\.evidence, document\.evidence\),\s*\n\s*operationsText/);

console.log('Delivery workflow contract: PASS');
console.log('revision → Codex handoff → canonical source → real preview → revision-bound 95% gate');
