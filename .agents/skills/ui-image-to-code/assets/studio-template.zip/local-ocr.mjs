import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';

const MAX_OUTPUT_BYTES = 4 * 1024 * 1024;

function runProcess(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd:options.cwd, windowsHide:true, stdio:['ignore', 'pipe', 'pipe'] });
    const stdout = [];
    const stderr = [];
    let outputBytes = 0;
    let settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (error) reject(error); else resolve(value);
    };
    const collect = (target) => (chunk) => {
      outputBytes += chunk.length;
      if (outputBytes > MAX_OUTPUT_BYTES) {
        child.kill();
        finish(Object.assign(new Error('OCR 输出过大'), { code:'OCR_OUTPUT_LIMIT' }));
        return;
      }
      target.push(chunk);
    };
    child.stdout.on('data', collect(stdout));
    child.stderr.on('data', collect(stderr));
    child.on('error', (error) => finish(error));
    child.on('close', (code) => {
      const output = Buffer.concat(stdout).toString('utf8').replace(/^\uFEFF/, '').trim();
      const errorOutput = Buffer.concat(stderr).toString('utf8').trim();
      if (code !== 0) finish(Object.assign(new Error(errorOutput || `OCR 进程退出码 ${code}`), { code:'OCR_PROCESS_FAILED' }));
      else finish(null, output);
    });
    const timer = setTimeout(() => {
      child.kill();
      finish(Object.assign(new Error('OCR 处理超时'), { code:'OCR_TIMEOUT' }));
    }, Number(options.timeoutMs || 45_000));
  });
}

export function parseTesseractTsv(tsv) {
  const rows = String(tsv || '').split(/\r?\n/).slice(1);
  const groups = new Map();
  for (const row of rows) {
    const columns = row.split('\t');
    if (columns.length < 12) continue;
    const [level, page, block, paragraph, line, word, left, top, width, height, confidence, ...textParts] = columns;
    const text = textParts.join('\t').trim();
    if (Number(level) !== 5 || !text || Number(confidence) < 0) continue;
    const key = `${page}:${block}:${paragraph}:${line}`;
    const item = groups.get(key) || { words:[], confidence:[], left:Infinity, top:Infinity, right:0, bottom:0 };
    const x = Number(left);
    const y = Number(top);
    const w = Number(width);
    const h = Number(height);
    item.words.push({ index:Number(word), text });
    item.confidence.push(Number(confidence));
    item.left = Math.min(item.left, x);
    item.top = Math.min(item.top, y);
    item.right = Math.max(item.right, x + w);
    item.bottom = Math.max(item.bottom, y + h);
    groups.set(key, item);
  }
  return [...groups.values()].map((item) => ({
    text:item.words.sort((left, right) => left.index - right.index).map((word) => word.text).join(' '),
    confidence:Number((item.confidence.reduce((sum, value) => sum + value, 0) / Math.max(1, item.confidence.length) / 100).toFixed(3)),
    bounds:{ x:item.left, y:item.top, width:item.right - item.left, height:item.bottom - item.top },
  }));
}

async function windowsMediaOcr(imagePath, root) {
  if (process.platform !== 'win32') return null;
  const script = path.join(root, 'scripts', 'windows-native-ocr.ps1');
  await readFile(script);
  const output = await runProcess('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script, '-ImagePath', imagePath], { cwd:root });
  const parsed = JSON.parse(output || '{}');
  return { adapter:parsed.adapter || 'windows-media-ocr', language:parsed.language || null, blocks:Array.isArray(parsed.blocks) ? parsed.blocks : [] };
}

async function tesseractOcr(imagePath, root) {
  const run = async (language) => runProcess('tesseract', [imagePath, 'stdout', '-l', language, '--psm', '11', 'tsv'], { cwd:root });
  let output;
  let language = 'chi_sim+eng';
  try { output = await run(language); }
  catch (error) {
    if (error.code === 'ENOENT') throw error;
    language = 'eng';
    output = await run(language);
  }
  return { adapter:'tesseract-cli', language, blocks:parseTesseractTsv(output) };
}

export async function runLocalOcr(pngBuffer, options = {}) {
  const root = path.resolve(options.root || process.cwd());
  const temporaryDirectory = await mkdtemp(path.join(os.tmpdir(), 'ui-studio-ocr-'));
  const imagePath = path.join(temporaryDirectory, 'capture.png');
  const failures = [];
  try {
    await writeFile(imagePath, pngBuffer, { flag:'wx' });
    const adapters = process.platform === 'win32'
      ? [() => windowsMediaOcr(imagePath, root), () => tesseractOcr(imagePath, root)]
      : [() => tesseractOcr(imagePath, root)];
    for (const adapter of adapters) {
      try {
        const result = await adapter();
        if (result) return { available:true, ...result, failures };
      } catch (error) {
        failures.push({ code:error.code || 'OCR_ADAPTER_FAILED', message:String(error.message || error).slice(0, 240) });
      }
    }
    return { available:false, adapter:null, language:null, blocks:[], failures };
  } finally {
    await rm(temporaryDirectory, { recursive:true, force:true });
  }
}

