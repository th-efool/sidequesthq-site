import { createHash, randomUUID } from 'node:crypto';
import { copyFile, mkdir, open, readFile, readdir, rename, stat, unlink } from 'node:fs/promises';
import path from 'node:path';
import {
  createUIDocumentV4, migrateUIDocument, normalizeSemanticOperations, UI_DOCUMENT_MAX_BYTES,
  validateUIDocumentV4,
} from './ui-document-v4.mjs';

export const PROTOCOL_VERSION = 1;
export const SOURCE_FILES = ['index.html', 'styles.css', 'app.js'];
export const GENERATED_PREVIEW_FILES = ['ui-studio-overrides.css', 'ui-studio-structure.js'];
export const MAX_DOCUMENT_BYTES = UI_DOCUMENT_MAX_BYTES;
export const MAX_REFERENCE_BYTES = 12 * 1024 * 1024;

export function syncPaths(projectRoot) {
  const root = path.resolve(projectRoot);
  const directory = path.join(root, '.ui-studio');
  return {
    root,
    directory,
    history: path.join(directory, 'history'),
    document: path.join(directory, 'ui-document.json'),
    state: path.join(directory, 'sync-state.json'),
    sourceMap: path.join(directory, 'source-map.json'),
    identityRegistry: path.join(directory, 'identity-registry.json'),
    handoff: path.join(directory, 'handoff.json'),
    evidence: path.join(directory, 'evidence.json'),
    operations: path.join(directory, 'operations.jsonl'),
    transaction: path.join(directory, 'transaction.json'),
    references: path.join(directory, 'references'),
    canvasContract: path.join(directory, 'canvas-core-contract.json'),
  };
}

export async function readJSON(file, fallback = null) {
  try { return JSON.parse(await readFile(file, 'utf8')); }
  catch (error) {
    if (error.code === 'ENOENT' && fallback !== null) return structuredClone(fallback);
    throw error;
  }
}

const WINDOWS_REPLACE_ERRORS = new Set(['EPERM', 'EACCES', 'EEXIST']);

async function replaceFlushedTemp(temp, file) {
  let lastError = null;
  for (let attempt = 0; attempt < 6; attempt += 1) {
    try { await rename(temp, file); return; }
    catch (error) {
      lastError = error;
      if (!WINDOWS_REPLACE_ERRORS.has(error.code)) throw error;
      await new Promise((resolve) => setTimeout(resolve, 20 * (attempt + 1)));
    }
  }
  if (process.platform !== 'win32') throw lastError;
  try {
    await copyFile(temp, file);
    await unlink(temp);
  } catch (error) {
    try { await unlink(temp); } catch {}
    throw new AggregateError([lastError, error], `无法替换同步文件：${path.basename(file)}`);
  }
}

export async function atomicWriteJSON(file, value) {
  await mkdir(path.dirname(file), { recursive: true });
  const temp = `${file}.${process.pid}.${Date.now()}.${randomUUID()}.tmp`;
  const handle = await open(temp, 'w');
  try { await handle.writeFile(`${JSON.stringify(value, null, 2)}\n`, 'utf8'); await handle.sync(); }
  finally { await handle.close(); }
  try { await replaceFlushedTemp(temp, file); }
  catch (error) { try { await unlink(temp); } catch {} throw error; }
}

export async function atomicWriteText(file, value) {
  await mkdir(path.dirname(file), { recursive: true });
  const temp = `${file}.${process.pid}.${Date.now()}.${randomUUID()}.tmp`;
  const handle = await open(temp, 'w');
  try { await handle.writeFile(value, 'utf8'); await handle.sync(); }
  finally { await handle.close(); }
  try { await replaceFlushedTemp(temp, file); }
  catch (error) { try { await unlink(temp); } catch {} throw error; }
}

export async function atomicWriteBuffer(file, value) {
  await mkdir(path.dirname(file), { recursive:true });
  const temp = `${file}.${process.pid}.${Date.now()}.${randomUUID()}.tmp`;
  const handle = await open(temp, 'w');
  try { await handle.writeFile(value); await handle.sync(); }
  finally { await handle.close(); }
  try { await replaceFlushedTemp(temp, file); }
  catch (error) { try { await unlink(temp); } catch {} throw error; }
}

async function writeFlushedTemp(file, value) {
  await mkdir(path.dirname(file), { recursive:true });
  const temp = `${file}.${process.pid}.${Date.now()}.${randomUUID()}.txn`;
  const handle = await open(temp, 'w');
  try {
    if (Buffer.isBuffer(value)) await handle.writeFile(value);
    else if (typeof value === 'string') await handle.writeFile(value, 'utf8');
    else await handle.writeFile(`${JSON.stringify(value, null, 2)}\n`, 'utf8');
    await handle.sync();
  } finally { await handle.close(); }
  return temp;
}

export async function recoverAtomicBundle(transactionFile) {
  let manifest;
  try { manifest = JSON.parse(await readFile(transactionFile, 'utf8')); }
  catch (error) {
    if (error.code === 'ENOENT') return false;
    throw new Error(`同步事务日志损坏：${error.message}`);
  }
  if (!manifest || manifest.version !== 1 || !Array.isArray(manifest.entries)) throw new Error('同步事务日志格式无效');
  for (const entry of manifest.entries) {
    if (!entry?.temp || !entry?.target) throw new Error('同步事务日志缺少文件路径');
    try { await stat(entry.temp); await replaceFlushedTemp(entry.temp, entry.target); }
    catch (error) {
      if (error.code !== 'ENOENT') throw error;
      try { await stat(entry.target); }
      catch { throw new Error(`无法恢复同步事务：${path.basename(entry.target)}`); }
    }
  }
  await unlink(transactionFile);
  return true;
}

// A save updates several project records. The journal makes that group
// recoverable after a crash instead of leaving mixed revisions on disk.
export async function atomicWriteBundle(transactionFile, entries) {
  if (!Array.isArray(entries) || !entries.length) return;
  await recoverAtomicBundle(transactionFile);
  const staged = [];
  let manifestWritten = false;
  try {
    for (const entry of entries) {
      if (!entry?.file) throw new Error('事务写入缺少目标文件');
      const target = path.resolve(entry.file);
      staged.push({ target, temp:await writeFlushedTemp(target, entry.value) });
    }
    await atomicWriteJSON(transactionFile, {
      version:1,
      id:randomUUID(),
      createdAt:new Date().toISOString(),
      entries:staged,
    });
    manifestWritten = true;
    for (const entry of staged) await replaceFlushedTemp(entry.temp, entry.target);
    await unlink(transactionFile);
  } catch (error) {
    if (!manifestWritten) {
      for (const entry of staged) { try { await unlink(entry.temp); } catch {} }
    }
    throw error;
  }
}

export async function appendOperationLog(file, value) {
  await mkdir(path.dirname(file), { recursive:true });
  const handle = await open(file, 'a');
  try { await handle.writeFile(`${JSON.stringify(value)}\n`, 'utf8'); await handle.sync(); }
  finally { await handle.close(); }
}

async function hashProjectFiles(projectRoot, files) {
  const digest = createHash('sha256');
  for (const relative of files) {
    const file = path.join(projectRoot, relative);
    digest.update(`${relative}\0`);
    try { digest.update(await readFile(file)); }
    catch (error) {
      if (error.code !== 'ENOENT') throw error;
      digest.update('<missing>');
    }
    digest.update('\0');
  }
  return digest.digest('hex');
}

export async function sourceHash(projectRoot) {
  return hashProjectFiles(projectRoot, SOURCE_FILES);
}

export async function executableSourceHash(projectRoot) {
  return hashProjectFiles(projectRoot, [...SOURCE_FILES, ...GENERATED_PREVIEW_FILES]);
}

export async function generatedSourceHash(projectRoot) {
  return hashProjectFiles(projectRoot, GENERATED_PREVIEW_FILES);
}

export async function collectSourceIdentities(projectRoot) {
  const root = path.resolve(projectRoot);
  const identityFiles = SOURCE_FILES.filter((relative) => !relative.endsWith('.css'));
  const registry = new Map();
  for (const relative of identityFiles) {
    const file = path.join(root, relative);
    let source = '';
    try { source = await readFile(file, 'utf8'); }
    catch (error) { if (error.code === 'ENOENT') continue; else throw error; }
    const pattern = /\bdata-ui-id\s*=\s*(["'])([^"']+)\1/g;
    for (const match of source.matchAll(pattern)) {
      if (match.index > 0 && source[match.index - 1] === '[') continue;
      const id = match[2].trim();
      if (!id) continue;
      const line = source.slice(0, match.index).split('\n').length;
      if (!registry.has(id)) registry.set(id, []);
      registry.get(id).push({ file:relative, line });
    }
  }
  const entries = [...registry.entries()]
    .map(([id, locations]) => ({ id, locations }))
    .sort((left, right) => left.id.localeCompare(right.id));
  return {
    entries,
    ids:new Set(entries.map((entry) => entry.id)),
    duplicates:entries.filter((entry) => entry.locations.length > 1),
  };
}

export function defaultDocument(hash) {
  return createUIDocumentV4(hash, PROTOCOL_VERSION);
}

export function defaultState(hash, previewHash = hash, generatedHash = previewHash) {
  return {
    protocolVersion: PROTOCOL_VERSION,
    documentRevision: 0,
    appliedRevision: 0,
    previewRevision: 0,
    previewStatus: 'clean',
    previewUpdatedAt: null,
    previewSourceHash: previewHash,
    previewGeneratedHash: generatedHash,
    baseSourceHash: hash,
    currentSourceHash: hash,
    state: 'clean',
    lastWriter: 'codex',
    updatedAt: new Date().toISOString(),
  };
}

export async function ensureSyncProject(projectRoot) {
  const paths = syncPaths(projectRoot);
  await Promise.all([mkdir(paths.history, { recursive:true }), mkdir(paths.references, { recursive:true })]);
  await recoverAtomicBundle(paths.transaction);
  const [hash, previewHash, generatedHash] = await Promise.all([
    sourceHash(paths.root),
    executableSourceHash(paths.root),
    generatedSourceHash(paths.root),
  ]);
  const present = Object.fromEntries(await Promise.all([
    ['document', paths.document], ['state', paths.state], ['sourceMap', paths.sourceMap],
    ['handoff', paths.handoff], ['evidence', paths.evidence], ['operations', paths.operations],
  ].map(async ([key, file]) => [key, await fileExists(file)])));
  const originalDocument = await readJSON(paths.document, defaultDocument(hash));
  const document = migrateUIDocument(originalDocument, hash, PROTOCOL_VERSION);
  const storedState = await readJSON(paths.state, defaultState(hash, previewHash, generatedHash));
  const state = {
    ...storedState,
    previewSourceHash:storedState.previewSourceHash || previewHash,
    previewGeneratedHash:storedState.previewGeneratedHash || generatedHash,
  };
  const storedSourceMap = await readJSON(paths.sourceMap, {
    protocolVersion: PROTOCOL_VERSION,
    selectors: 'data-ui-id',
    sourceFiles: SOURCE_FILES,
    generatedFiles: GENERATED_PREVIEW_FILES,
  });
  const sourceMap = {
    ...storedSourceMap,
    protocolVersion:PROTOCOL_VERSION,
    selectors:'data-ui-id',
    sourceFiles:SOURCE_FILES,
    generatedFiles:GENERATED_PREVIEW_FILES,
  };
  const handoff = await readJSON(paths.handoff, {
    protocolVersion: PROTOCOL_VERSION,
    revision: 0,
    status: 'idle',
    summary: [],
    requestedAt: null,
  });
  const evidence = await readJSON(paths.evidence, document.evidence);
  if (originalDocument.version !== document.version) await archiveDocument(paths, originalDocument);
  const writes = [];
  if (!present.document || JSON.stringify(originalDocument) !== JSON.stringify(document)) writes.push(atomicWriteJSON(paths.document, document));
  if (!present.state || JSON.stringify(storedState) !== JSON.stringify(state)) writes.push(atomicWriteJSON(paths.state, state));
  if (!present.sourceMap || JSON.stringify(storedSourceMap) !== JSON.stringify(sourceMap)) writes.push(atomicWriteJSON(paths.sourceMap, sourceMap));
  if (!present.handoff) writes.push(atomicWriteJSON(paths.handoff, handoff));
  if (!present.evidence) writes.push(atomicWriteJSON(paths.evidence, document.evidence));
  if (!present.operations) writes.push(atomicWriteText(paths.operations, ''));
  await Promise.all(writes);
  return { paths, document, state, sourceMap, handoff, evidence };
}

export function effectiveState(state, document, currentHash, currentPreviewHash = null, currentGeneratedHash = null) {
  const pending = Number(document.revision) > Number(state.appliedRevision || 0);
  let name = 'clean';
  if (pending && currentHash !== state.baseSourceHash) name = 'conflict';
  else if (pending) name = 'pending-codex';
  else if (currentHash !== state.baseSourceHash) name = 'source-ahead';
  return {
    ...state,
    state: name,
    documentRevision: Number(document.revision || 0),
    previewRevision: Number(state.previewRevision || 0),
    previewIsCurrent: Number(state.previewRevision || 0) === Number(document.revision || 0)
      && (!state.previewGeneratedHash || !currentGeneratedHash || state.previewGeneratedHash === currentGeneratedHash),
    previewExecutableIsCurrent:!state.previewSourceHash || !currentPreviewHash || state.previewSourceHash === currentPreviewHash,
    currentSourceHash: currentHash,
    pendingChanges: pending,
  };
}

export async function readSyncSnapshot(projectRoot) {
  const initialized = await ensureSyncProject(projectRoot);
  const document = await readJSON(initialized.paths.document);
  const state = await readJSON(initialized.paths.state);
  const [currentHash, currentPreviewHash, currentGeneratedHash] = await Promise.all([
    sourceHash(initialized.paths.root),
    executableSourceHash(initialized.paths.root),
    generatedSourceHash(initialized.paths.root),
  ]);
  return {
    ...initialized,
    document,
    state:effectiveState(state, document, currentHash, currentPreviewHash, currentGeneratedHash),
    storedState:state,
    currentHash,
    currentPreviewHash,
    currentGeneratedHash,
  };
}

export function validateDocument(document) {
  return validateUIDocumentV4(document, { protocolVersion:PROTOCOL_VERSION, maxBytes:MAX_DOCUMENT_BYTES });
}

export function buildSemanticOperations(operations, revision, writer = 'studio') {
  return normalizeSemanticOperations(operations, revision, writer);
}

export function documentChangeSummary(document) {
  const overrideEntries = Object.entries(document.overrides || {}).filter(([, value]) => value && Object.keys(value).length);
  const textCount = overrideEntries.filter(([, value]) => Object.hasOwn(value, 'textContent')).length;
  const styleCount = overrideEntries.filter(([, value]) => Object.keys(value).some((key) => key !== 'textContent')).length;
  const iconCount = Object.keys(document.iconReplacements || {}).length;
  const insertionCount = document.structuralEdits?.insertions?.length || 0;
  const renamedCount = Object.keys(document.layerMetadata || {}).length;
  const paths = [];
  for (const [id, values] of overrideEntries) {
    for (const key of Object.keys(values)) paths.push(`overrides.${id}.${key}`);
  }
  for (const id of Object.keys(document.iconReplacements || {})) paths.push(`iconReplacements.${id}`);
  for (const insertion of document.structuralEdits?.insertions || []) paths.push(`structuralEdits.insertions.${insertion.id}`);
  for (const id of Object.keys(document.layerMetadata || {})) paths.push(`layerMetadata.${id}.name`);
  const activeRun = document.evidence?.runs?.find((run) => run.id === document.evidence?.activeRunId) || null;
  return {
    nodes:overrideEntries.length,
    text:textCount,
    styles:styleCount,
    icons:iconCount,
    insertions:insertionCount,
    renamed:renamedCount,
    analyses:document.evidence?.runs?.length || 0,
    candidates:activeRun?.candidateCount || 0,
    manual:document.manualQueue?.length || 0,
    paths,
  };
}

export async function archiveDocument(paths, document) {
  if (!document) return;
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  await atomicWriteJSON(path.join(paths.history, `${String(document.revision).padStart(6, '0')}-${stamp}.json`), document);
  const files = (await readdir(paths.history)).filter((name) => name.endsWith('.json')).sort();
  for (const name of files.slice(0, Math.max(0, files.length - 20))) await unlink(path.join(paths.history, name));
}

export async function listDocumentHistory(paths) {
  const files = (await readdir(paths.history)).filter((name) => name.endsWith('.json')).sort().reverse();
  const revisions = [];
  for (const name of files) {
    const document = await readJSON(path.join(paths.history, name));
    if (!document) continue;
    revisions.push({
      revision:Number(document.revision || 0),
      updatedAt:document.updatedAt || null,
      updatedBy:document.updatedBy || null,
      summary:documentChangeSummary(document),
      file:name,
    });
  }
  return revisions;
}

export async function readDocumentRevision(paths, revision) {
  const prefix = `${String(Number(revision)).padStart(6, '0')}-`;
  const files = (await readdir(paths.history)).filter((name) => name.startsWith(prefix) && name.endsWith('.json')).sort().reverse();
  if (!files.length) return null;
  return readJSON(path.join(paths.history, files[0]));
}

function cssValue(key, value) {
  const pixelKeys = new Set(['width','height','fontSize','lineHeight','letterSpacing','borderRadius','borderWidth','padding']);
  return `${value}${pixelKeys.has(key) && value !== '' ? 'px' : ''}`;
}

export function buildOverrideCSS(document) {
  const propertyNames = {
    width:'width', height:'height', backgroundColor:'background-color', color:'color', fontSize:'font-size', fontFamily:'font-family',
    fontWeight:'font-weight', lineHeight:'line-height', letterSpacing:'letter-spacing', textAlign:'text-align', borderRadius:'border-radius',
    borderWidth:'border-width', borderColor:'border-color', borderStyle:'border-style', opacity:'opacity', padding:'padding', display:'display', zIndex:'z-index', position:'position',
  };
  const blocks = [];
  for (const [id, values] of Object.entries(document.overrides || {})) {
    const declarations = [];
    if (Number(values.x) || Number(values.y)) declarations.push(`  translate: ${Number(values.x) || 0}px ${Number(values.y) || 0}px !important;`);
    if (values.scale !== undefined && values.scale !== '') declarations.push(`  scale: ${values.scale} !important;`, '  transform-origin: top left !important;');
    if (values.rotation !== undefined && values.rotation !== '') declarations.push(`  rotate: ${values.rotation}deg !important;`);
    for (const [key, cssName] of Object.entries(propertyNames)) {
      if (values[key] === undefined || values[key] === '') continue;
      declarations.push(`  ${cssName}: ${cssValue(key, values[key])} !important;`);
    }
    if (['shadowX','shadowY','shadowBlur','shadowSpread','shadowColor'].some((key) => values[key] !== undefined && values[key] !== '')) {
      declarations.push(`  box-shadow: ${Number(values.shadowX) || 0}px ${Number(values.shadowY) || 0}px ${Math.max(0, Number(values.shadowBlur) || 0)}px ${Number(values.shadowSpread) || 0}px ${values.shadowColor || '#00000033'} !important;`);
    }
    if (declarations.length) blocks.push(`[data-ui-id="${id.replaceAll('"', '\\"')}"] {\n${declarations.join('\n')}\n}`);
  }
  return `/* Generated by UI Studio. Edit through Studio or Codex, then run npm run sync:apply. */\n\n${blocks.join('\n\n')}\n`;
}

export function buildStructuralScript(document) {
  const serialized = JSON.stringify(document.structuralEdits?.insertions || []).replaceAll('<', '\\u003c');
  return `/* Generated by UI Studio. Structural insertions use stable IDs and run before app.js. */
(() => {
  const insertions = ${serialized};
  const find = (id) => id ? document.querySelector('[data-ui-id="' + CSS.escape(id) + '"]') : null;
  const apply = () => {
    for (const insertion of insertions) {
      if (find(insertion.id)) continue;
      const source = find(insertion.sourceId);
      if (!source) continue;
      const parent = find(insertion.parentId) || source.parentElement;
      if (!parent) continue;
      const clone = source.cloneNode(true);
      const mapped = [clone, ...clone.querySelectorAll('[data-ui-id]')];
      for (const element of mapped) {
        const nextId = insertion.idMap[element.dataset.uiId];
        if (nextId) element.dataset.uiId = nextId;
      }
      clone.dataset.uiStudioInsertion = insertion.id;
      if (insertion.name) clone.dataset.uiName = insertion.name;
      const after = find(insertion.afterId);
      if (after?.parentElement === parent) after.after(clone);
      else parent.append(clone);
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apply, { once:true });
  else apply();
})();
`;
}

function escapeRegExp(value) { return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function escapeHTML(value) { return String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;'); }

export function applyDocumentToHTML(source, document) {
  let output = source;
  for (const [id, values] of Object.entries(document.overrides || {})) {
    if (!Object.hasOwn(values, 'textContent')) continue;
    const escapedId = escapeRegExp(id);
    const pattern = new RegExp(`(<([a-z][\\w:-]*)\\b[^>]*\\bdata-ui-id=(['"])${escapedId}\\3[^>]*>)([^<]*)(<\\/\\2>)`, 'i');
    output = output.replace(pattern, `$1${escapeHTML(values.textContent)}$5`);
  }
  for (const [id, replacement] of Object.entries(document.iconReplacements || {})) {
    const escapedId = escapeRegExp(id);
    const pattern = new RegExp(`(<svg\\b[^>]*\\bdata-ui-id=(['"])${escapedId}\\2[^>]*>)[\\s\\S]*?(<\\/svg>)`, 'i');
    output = output.replace(pattern, (match, opening, quote, closing) => {
      let nextOpening = opening;
      const viewBox = replacement.viewBox || `0 0 ${replacement.width || 24} ${replacement.height || 24}`;
      if (/\bviewBox\s*=/.test(nextOpening)) nextOpening = nextOpening.replace(/\bviewBox\s*=\s*(['"])[^'"]*\1/i, `viewBox="${viewBox}"`);
      else nextOpening = nextOpening.replace(/>$/, ` viewBox="${viewBox}">`);
      return `${nextOpening}${replacement.body}${closing}`;
    });
  }
  if (!/href=["']ui-studio-overrides\.css["']/.test(output)) {
    output = output.replace(/(<link\b[^>]*href=["']styles\.css["'][^>]*>)/i, `$1\n    <link rel="stylesheet" href="ui-studio-overrides.css" />`);
  }
  if (!/src=["']ui-studio-structure\.js["']/.test(output)) {
    output = output.replace(/(<script\b[^>]*src=["']app\.js["'][^>]*><\/script>)/i, `    <script src="ui-studio-structure.js"></script>\n$1`);
  }
  return output;
}

export async function applyDocumentToProject(projectRoot, document) {
  validateDocument(document);
  const htmlFile = path.join(projectRoot, 'index.html');
  const cssFile = path.join(projectRoot, 'ui-studio-overrides.css');
  const structureFile = path.join(projectRoot, 'ui-studio-structure.js');
  const html = await readFile(htmlFile, 'utf8');
  await atomicWriteText(htmlFile, applyDocumentToHTML(html, document));
  await atomicWriteText(cssFile, buildOverrideCSS(document));
  await atomicWriteText(structureFile, buildStructuralScript(document));
}

export async function inspectPreviewTargets(projectRoot, document) {
  const sourceIdentities = await collectSourceIdentities(projectRoot);
  const targetIds = Object.entries(document.overrides || {})
    .filter(([, values]) => values && Object.keys(values).some((key) => key !== 'textContent'))
    .map(([id]) => id);
  const unresolvedTargetIds = targetIds.filter((id) => !sourceIdentities.ids.has(id));
  const insertionIds = new Set((document.structuralEdits?.insertions || []).flatMap((insertion) => Object.values(insertion.idMap || {})));
  const structuralSourceIds = (document.structuralEdits?.insertions || []).flatMap((insertion) => [insertion.sourceId, insertion.parentId, insertion.afterId].filter(Boolean));
  const unresolvedStructuralIds = structuralSourceIds.filter((id) => !sourceIdentities.ids.has(id) && !insertionIds.has(id));
  const summary = documentChangeSummary(document);
  const coverage = summary.styles
    ? (summary.text || summary.icons ? 'partial' : 'complete')
    : (summary.text || summary.icons ? 'none' : 'complete');
  return {
    valid:sourceIdentities.duplicates.length === 0 && unresolvedTargetIds.every((id) => insertionIds.has(id)) && unresolvedStructuralIds.length === 0,
    coverage,
    styleTargets:targetIds.length,
    duplicateIds:sourceIdentities.duplicates.map((entry) => entry.id),
    unresolvedTargetIds:[...unresolvedTargetIds.filter((id) => !insertionIds.has(id)), ...unresolvedStructuralIds],
  };
}

export async function inspectSafeConflictRebase(projectRoot, snapshot) {
  const reasons = [];
  const state = snapshot?.state || {};
  const document = snapshot?.document || {};
  const currentHash = snapshot?.currentHash || await sourceHash(projectRoot);
  const pending = Number(document.revision || 0) > Number(state.appliedRevision || 0);
  const baseline = await readDocumentRevision(syncPaths(projectRoot), Number(state.appliedRevision || 0)) || defaultDocument(state.baseSourceHash || currentHash);
  const changedText = Object.entries(document.overrides || {}).some(([id, values]) => (
    Object.hasOwn(values || {}, 'textContent')
    && values.textContent !== baseline.overrides?.[id]?.textContent
  ));
  const changedIcons = JSON.stringify(document.iconReplacements || {}) !== JSON.stringify(baseline.iconReplacements || {});
  const changedInsertions = JSON.stringify(document.structuralEdits?.insertions || []) !== JSON.stringify(baseline.structuralEdits?.insertions || []);
  if (state.state !== 'conflict') reasons.push('state-is-not-conflict');
  if (!pending) reasons.push('no-pending-studio-revision');
  if (currentHash === state.baseSourceHash) reasons.push('source-hash-did-not-change');
  if (state.previewStatus !== 'applied' || !state.previewIsCurrent || (state.previewBlockedTargets || []).length) reasons.push('latest-preview-is-not-current');
  if (changedInsertions) reasons.push('structural-insertions-require-manual-merge');
  if (changedIcons) reasons.push('icon-replacements-require-manual-merge');
  if (changedText) reasons.push('text-overrides-require-manual-merge');
  const targets = await inspectPreviewTargets(projectRoot, document);
  if (!targets.valid) reasons.push('stable-targets-do-not-resolve');
  return {
    safe:reasons.length === 0,
    reasons,
    currentHash,
    fromHash:state.baseSourceHash,
    revision:Number(document.revision || 0),
    appliedRevision:Number(state.appliedRevision || 0),
    targetCount:targets.styleTargets,
    targets,
  };
}

export async function applyPreviewDocumentToProject(projectRoot, document) {
  validateDocument(document);
  const inspection = await inspectPreviewTargets(projectRoot, document);
  if (!inspection.valid) return { applied:false, status:'blocked', ...inspection };
  const htmlFile = path.join(projectRoot, 'index.html');
  const html = await readFile(htmlFile, 'utf8');
  if (!/href=["']ui-studio-overrides\.css["']/.test(html)) {
    return { applied:false, status:'blocked', issue:'preview-stylesheet-not-linked', ...inspection };
  }
  const cssFile = path.join(projectRoot, 'ui-studio-overrides.css');
  const structureFile = path.join(projectRoot, 'ui-studio-structure.js');
  await atomicWriteText(cssFile, buildOverrideCSS(document));
  await atomicWriteText(structureFile, buildStructuralScript(document));
  return { applied:true, status:'applied', ...inspection };
}

export async function fileExists(file) {
  try { return (await stat(file)).isFile(); } catch { return false; }
}
