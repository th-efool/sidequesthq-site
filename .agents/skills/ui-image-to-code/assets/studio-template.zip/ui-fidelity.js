import { compareImageData, computeFidelityGate, FIDELITY_LABELS, FIDELITY_WEIGHTS } from './ui-fidelity-core.mjs';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const state = { reference:null, result:null, comparison:null, mode:'overlay', blinkTimer:null, blinkVisible:true, persistenceTimer:null };

function setFeatureMode(feature) {
  const active = feature === 'compare';
  document.body.classList.toggle('feature-compare-active', active);
  $('#fidelity-workspace').hidden = !active;
  if (active) requestAnimationFrame(renderAll);
  else stopBlink();
}

window.addEventListener('ui-studio-featurechange', (event) => setFeatureMode(event.detail.feature));

async function bitmapFromBlob(blob) {
  if ('createImageBitmap' in window) return createImageBitmap(blob);
  const image = new Image();
  const url = URL.createObjectURL(blob);
  try {
    await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = reject; image.src = url; });
    return image;
  } finally { URL.revokeObjectURL(url); }
}

async function evidenceFromBlob(blob, name) {
  const bitmap = await bitmapFromBlob(blob);
  const width = bitmap.width || bitmap.naturalWidth;
  const height = bitmap.height || bitmap.naturalHeight;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d', { willReadFrequently:true });
  context.drawImage(bitmap, 0, 0);
  const imageData = context.getImageData(0, 0, width, height);
  return { name, width, height, bitmap, imageData };
}

function closeEvidence(evidence) { evidence?.bitmap?.close?.(); }

function status(message, tone = '') {
  const element = $('#fidelity-status');
  element.textContent = message;
  element.dataset.tone = tone;
}

function updateFileMeta() {
  $('#fidelity-reference-meta').textContent = state.reference ? `${state.reference.name} · ${state.reference.width}×${state.reference.height}` : '尚未载入参考图';
  $('#fidelity-result-meta').textContent = state.result ? `${state.result.name} · ${state.result.width}×${state.result.height}` : '尚未载入结果图';
  $('#fidelity-run').disabled = !(state.reference && state.result);
  $('#fidelity-self-test').disabled = !state.reference;
}

async function setEvidence(kind, blob, name, { proofKind = kind === 'result' ? 'browser-capture' : 'reference' } = {}) {
  const evidence = await evidenceFromBlob(blob, name);
  evidence.proofKind = proofKind;
  closeEvidence(state[kind]);
  state[kind] = evidence;
  state.comparison = null;
  updateFileMeta();
  renderAll();
  status(`${kind === 'reference' ? '参考图' : '结果图'}已载入。`);
}

async function loadProjectReference() {
  try {
    const response = await fetch('reference.png', { cache:'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    await setEvidence('reference', await response.blob(), 'reference.png');
  } catch (error) { status(`参考图载入失败：${error.message}`, 'error'); }
}

function drawEvidence(canvas, evidence) {
  const context = canvas.getContext('2d');
  context.clearRect(0, 0, canvas.width, canvas.height);
  if (!evidence) return;
  canvas.width = evidence.width;
  canvas.height = evidence.height;
  context.drawImage(evidence.bitmap, 0, 0);
}

function drawHeatmap() {
  const canvas = $('#fidelity-heatmap-canvas');
  const heatmap = state.comparison?.heatmap;
  if (!heatmap) { canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height); return; }
  canvas.width = heatmap.width;
  canvas.height = heatmap.height;
  canvas.getContext('2d').putImageData(new ImageData(heatmap.data, heatmap.width, heatmap.height), 0, 0);
}

function drawOverlay() {
  const canvas = $('#fidelity-overlay-canvas');
  const source = state.reference || state.result;
  if (!source) return;
  canvas.width = source.width;
  canvas.height = source.height;
  const context = canvas.getContext('2d');
  context.clearRect(0, 0, canvas.width, canvas.height);
  if (state.reference) context.drawImage(state.reference.bitmap, 0, 0);
  if (state.result) {
    context.globalAlpha = Number($('#fidelity-overlay-opacity').value) / 100;
    context.drawImage(state.result.bitmap, 0, 0);
    context.globalAlpha = 1;
  }
}

function setMode(mode) {
  state.mode = mode;
  $$('[data-fidelity-mode]').forEach((button) => button.classList.toggle('active', button.dataset.fidelityMode === mode));
  $$('.fidelity-view').forEach((view) => { view.hidden = view.dataset.fidelityView !== mode; });
  stopBlink();
  if (mode === 'blink') startBlink();
}

function startBlink() {
  if (!(state.reference && state.result)) return;
  const canvas = $('#fidelity-blink-canvas');
  canvas.width = state.reference.width;
  canvas.height = state.reference.height;
  const draw = () => {
    const context = canvas.getContext('2d');
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.drawImage((state.blinkVisible ? state.reference : state.result).bitmap, 0, 0);
    $('#fidelity-blink-label').textContent = state.blinkVisible ? '参考图' : '结果图';
    state.blinkVisible = !state.blinkVisible;
  };
  draw();
  state.blinkTimer = setInterval(draw, 650);
}

function stopBlink() {
  if (state.blinkTimer) clearInterval(state.blinkTimer);
  state.blinkTimer = null;
}

function renderMetrics() {
  const metrics = state.comparison?.metrics;
  $('#fidelity-pixel-score').textContent = metrics ? `${metrics.pixelSimilarity.toFixed(2)}%` : '—';
  $('#fidelity-edge-score').textContent = metrics ? `${metrics.edgeSimilarity.toFixed(2)}%` : '—';
  $('#fidelity-changed-score').textContent = metrics ? `${(metrics.changedPixelRatio * 100).toFixed(2)}%` : '—';
  $('#fidelity-mae-score').textContent = metrics ? metrics.meanAbsoluteError.toFixed(2) : '—';
}

function renderMismatchQueue() {
  const container = $('#fidelity-mismatch-list');
  const queue = state.comparison?.mismatchQueue || [];
  if (!queue.length) {
    container.innerHTML = `<p>${state.comparison ? '未发现超过阈值的区域差异。' : '完成一次对比后显示高差异区域。'}</p>`;
    return;
  }
  container.replaceChildren(...queue.map((item, index) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.mismatchId = item.id;
    button.innerHTML = `<span>${String(index + 1).padStart(2,'0')}</span><div><b>${item.category === 'geometry' ? '几何 / 边缘' : '颜色 / 效果'}</b><small>X ${item.bounds.x} · Y ${item.bounds.y} · ${item.bounds.width}×${item.bounds.height}</small></div><em>${Math.round(item.severity * 100)}%</em>`;
    button.addEventListener('click', () => {
      $$('[data-mismatch-id]').forEach((row) => row.classList.toggle('active', row === button));
      $('#fidelity-selected-mismatch').textContent = `${item.category === 'geometry' ? '几何 / 边缘' : '颜色 / 效果'} · X ${item.bounds.x}, Y ${item.bounds.y}, W ${item.bounds.width}, H ${item.bounds.height}`;
      setMode('heatmap');
    });
    return button;
  }));
}

function scoreInputs() {
  return Object.fromEntries($$('[data-fidelity-score]').map((input) => [input.dataset.fidelityScore, input.value.trim()]));
}

function criticalFailures() {
  return $$('[data-fidelity-critical]:checked').map((input) => input.value);
}

function renderGate() {
  const gate = computeFidelityGate(scoreInputs(), criticalFailures());
  const score = gate.score ?? gate.provisionalScore;
  $('#fidelity-gate-score').textContent = score === null ? '待评分' : `${gate.complete ? '' : '暂估 '}${score.toFixed(2)}%`;
  $('#fidelity-gate-coverage').textContent = `覆盖 ${gate.coverage}%`;
  const summary = $('#fidelity-gate-summary');
  summary.dataset.state = gate.passed ? 'pass' : gate.complete ? 'fail' : 'pending';
  summary.querySelector('strong').textContent = gate.passed ? '95% 门禁通过' : gate.complete ? (gate.criticalFailures.length ? '存在关键缺陷，最高封顶 94%' : '尚未达到 95%') : '完成全部 8 项评分后出结论';
  summary.querySelector('small').textContent = gate.criticalFailures.length ? `关键缺陷：${gate.criticalFailures.join('、')}` : '像素分只作诊断，不能替代响应式、交互和代码验收。';
  return gate;
}

function scheduleGatePersistence() {
  clearTimeout(state.persistenceTimer);
  if (!state.comparison) return;
  state.persistenceTimer = setTimeout(persistGate, 320);
}

async function persistGate() {
  if (!state.comparison) return;
  try {
    const statusResponse = await fetch('/__ui_sync/status', { cache:'no-store' });
    if (!statusResponse.ok) return;
    const syncStatus = await statusResponse.json();
    const response = await fetch('/__ui_sync/fidelity', {
      method:'PUT',
      cache:'no-store',
      headers:{ 'Content-Type':'application/json' },
      body:JSON.stringify({
        expectedRevision:syncStatus.documentRevision,
        scores:scoreInputs(),
        criticalFailures:criticalFailures(),
        proofKind:state.result?.proofKind || 'diagnostic',
        metrics:state.comparison.metrics,
      }),
    });
    if (!response.ok) return;
    const payload = await response.json();
    window.dispatchEvent(new CustomEvent('ui-fidelity-updated', { detail:payload }));
  } catch {}
}

function suggestVisualScores() {
  if (!state.comparison) return;
  const pixel = state.comparison.metrics.pixelSimilarity;
  const edge = state.comparison.metrics.edgeSimilarity;
  const suggestions = { geometry:edge, typography:Math.min(pixel, edge), assets:pixel, effects:pixel };
  for (const [key, value] of Object.entries(suggestions)) {
    const input = $(`[data-fidelity-score="${key}"]`);
    if (input && !input.value) input.value = Math.round(value);
  }
  renderGate();
  scheduleGatePersistence();
}

function renderAll() {
  $('.fidelity-empty').hidden = Boolean(state.reference || state.result);
  drawEvidence($('#fidelity-reference-canvas'), state.reference);
  drawEvidence($('#fidelity-result-canvas'), state.result);
  drawOverlay();
  drawHeatmap();
  renderMetrics();
  renderMismatchQueue();
  setMode(state.mode);
}

function runComparison() {
  if (!(state.reference && state.result)) return;
  try {
    state.comparison = compareImageData(state.reference.imageData, state.result.imageData, { maxMismatches:8 });
    renderAll();
    suggestVisualScores();
    const similarity = state.comparison.metrics.pixelSimilarity.toFixed(2);
    status(`对比完成 · 像素诊断相似度 ${similarity}%`, 'success');
  } catch (error) {
    state.comparison = null;
    renderAll();
    status(error.message, 'error');
  }
}

$('#fidelity-load-reference').addEventListener('click', loadProjectReference);
$('#fidelity-reference-file').addEventListener('change', (event) => event.target.files[0] && setEvidence('reference', event.target.files[0], event.target.files[0].name));
$('#fidelity-result-file').addEventListener('change', (event) => event.target.files[0] && setEvidence('result', event.target.files[0], event.target.files[0].name));
$('#fidelity-self-test').addEventListener('click', async () => {
  if (!state.reference) return;
  closeEvidence(state.result);
  state.result = await evidenceFromBlob(await (await fetch('reference.png', { cache:'no-store' })).blob(), '引擎自检 · 同图');
  state.result.proofKind = 'diagnostic';
  updateFileMeta();
  runComparison();
  status('引擎自检完成：同图应为 100%。这不是项目保真度结论。', 'success');
});
$('#fidelity-run').addEventListener('click', runComparison);
$$('[data-fidelity-mode]').forEach((button) => button.addEventListener('click', () => setMode(button.dataset.fidelityMode)));
$('#fidelity-overlay-opacity').addEventListener('input', (event) => { $('#fidelity-overlay-value').textContent = `${event.target.value}%`; drawOverlay(); });
$$('[data-fidelity-score], [data-fidelity-critical]').forEach((input) => input.addEventListener('input', () => { renderGate(); scheduleGatePersistence(); }));

for (const [key, weight] of Object.entries(FIDELITY_WEIGHTS)) {
  const label = $(`[data-fidelity-label="${key}"]`);
  if (label) label.textContent = `${FIDELITY_LABELS[key]} · ${weight}%`;
}
updateFileMeta();
renderGate();
setMode('overlay');
