const TYPE_LABELS = {
  page:'页面画布', frame:'容器', section:'区域', text:'文字候选', icon:'图标候选', image:'图片候选', control:'控件候选', divider:'分割线', unknown:'待判断元素',
};

const clamp = (value, minimum, maximum) => Math.min(maximum, Math.max(minimum, value));
const boxArea = (box) => Math.max(0, box.width) * Math.max(0, box.height);

function rgbHex(red, green, blue) {
  return `#${[red, green, blue].map((value) => clamp(Math.round(value), 0, 255).toString(16).padStart(2, '0')).join('')}`;
}

function paletteFromPixels(data, width, height) {
  const histogram = new Map();
  const stride = Math.max(1, Math.floor(Math.sqrt((width * height) / 32000)));
  for (let y = 0; y < height; y += stride) {
    for (let x = 0; x < width; x += stride) {
      const offset = (y * width + x) * 4;
      if (data[offset + 3] < 180) continue;
      const red = Math.round(data[offset] / 16) * 16;
      const green = Math.round(data[offset + 1] / 16) * 16;
      const blue = Math.round(data[offset + 2] / 16) * 16;
      const key = `${clamp(red, 0, 255)},${clamp(green, 0, 255)},${clamp(blue, 0, 255)}`;
      histogram.set(key, (histogram.get(key) || 0) + 1);
    }
  }
  return [...histogram.entries()].sort((left, right) => right[1] - left[1]).slice(0, 8).map(([key, count], index) => {
    const [red, green, blue] = key.split(',').map(Number);
    return { name:`observed.${index + 1}`, value:rgbHex(red, green, blue), count };
  });
}

function luminanceBuffer(data, width, height) {
  const output = new Uint8Array(width * height);
  for (let index = 0; index < output.length; index += 1) {
    const offset = index * 4;
    output[index] = Math.round(data[offset] * 0.2126 + data[offset + 1] * 0.7152 + data[offset + 2] * 0.0722);
  }
  return output;
}

function estimateEdgeThreshold(luma, width, height) {
  let sum = 0;
  let sumSquares = 0;
  let count = 0;
  const stride = Math.max(2, Math.floor(Math.sqrt((width * height) / 50000)));
  for (let y = stride; y < height; y += stride) {
    for (let x = stride; x < width; x += stride) {
      const index = y * width + x;
      const gradient = Math.max(Math.abs(luma[index] - luma[index - 1]), Math.abs(luma[index] - luma[index - width]));
      sum += gradient;
      sumSquares += gradient * gradient;
      count += 1;
    }
  }
  const mean = count ? sum / count : 24;
  const deviation = count ? Math.sqrt(Math.max(0, sumSquares / count - mean * mean)) : 10;
  return clamp(Math.round(mean + deviation * 0.55), 20, 72);
}

function edgeMask(luma, width, height, threshold) {
  const output = new Uint8Array(width * height);
  let active = 0;
  for (let y = 1; y < height - 1; y += 1) {
    for (let x = 1; x < width - 1; x += 1) {
      const index = y * width + x;
      const horizontal = Math.abs(luma[index + 1] - luma[index - 1]);
      const vertical = Math.abs(luma[index + width] - luma[index - width]);
      if (Math.max(horizontal, vertical) >= threshold) {
        output[index] = 1;
        active += 1;
      }
    }
  }
  return { mask:output, active };
}

function dilate(mask, width, height, radiusX = 3, radiusY = 1) {
  const output = new Uint8Array(mask.length);
  for (let y = 1; y < height - 1; y += 1) {
    for (let x = 1; x < width - 1; x += 1) {
      const index = y * width + x;
      if (!mask[index]) continue;
      for (let dy = -radiusY; dy <= radiusY; dy += 1) {
        const row = (y + dy) * width;
        for (let dx = -radiusX; dx <= radiusX; dx += 1) output[row + x + dx] = 1;
      }
    }
  }
  return output;
}

function connectedBoxes(mask, width, height) {
  const visited = new Uint8Array(mask.length);
  const queue = new Int32Array(mask.length);
  const boxes = [];
  for (let start = 0; start < mask.length; start += 1) {
    if (!mask[start] || visited[start]) continue;
    let head = 0;
    let tail = 0;
    let pixels = 0;
    let minimumX = width;
    let minimumY = height;
    let maximumX = 0;
    let maximumY = 0;
    queue[tail++] = start;
    visited[start] = 1;
    while (head < tail) {
      const index = queue[head++];
      const x = index % width;
      const y = Math.floor(index / width);
      pixels += 1;
      minimumX = Math.min(minimumX, x);
      maximumX = Math.max(maximumX, x);
      minimumY = Math.min(minimumY, y);
      maximumY = Math.max(maximumY, y);
      for (let dy = -1; dy <= 1; dy += 1) {
        for (let dx = -1; dx <= 1; dx += 1) {
          if (!dx && !dy) continue;
          const nextX = x + dx;
          const nextY = y + dy;
          if (nextX < 0 || nextY < 0 || nextX >= width || nextY >= height) continue;
          const next = nextY * width + nextX;
          if (mask[next] && !visited[next]) { visited[next] = 1; queue[tail++] = next; }
        }
      }
    }
    const box = { x:minimumX, y:minimumY, width:maximumX - minimumX + 1, height:maximumY - minimumY + 1, pixels };
    if (pixels >= 10 && box.width >= 3 && box.height >= 3 && boxArea(box) < width * height * 0.96) boxes.push(box);
  }
  return boxes;
}

function regionVariance(luma, width, height, box) {
  const xStep = Math.max(1, Math.floor(box.width / 24));
  const yStep = Math.max(1, Math.floor(box.height / 24));
  let sum = 0;
  let squares = 0;
  let count = 0;
  for (let y = Math.max(0, box.y); y < Math.min(height, box.y + box.height); y += yStep) {
    for (let x = Math.max(0, box.x); x < Math.min(width, box.x + box.width); x += xStep) {
      const value = luma[y * width + x];
      sum += value;
      squares += value * value;
      count += 1;
    }
  }
  const mean = count ? sum / count : 0;
  return count ? Math.max(0, squares / count - mean * mean) : 0;
}

function classifyBox(box, width, height, luma) {
  const widthRatio = box.width / width;
  const heightRatio = box.height / height;
  const aspect = box.width / Math.max(1, box.height);
  const areaRatio = boxArea(box) / (width * height);
  const variance = regionVariance(luma, width, height, box);
  if ((widthRatio > 0.35 && box.height <= 5) || (heightRatio > 0.35 && box.width <= 5)) return { type:'divider', confidence:0.9, variance };
  if (heightRatio <= 0.07 && aspect >= 1.5 && areaRatio < 0.12) return { type:'text', confidence:clamp(0.58 + Math.min(0.1, aspect / 80), 0.58, 0.68), variance };
  if (Math.max(box.width, box.height) <= Math.min(width, height) * 0.13 && aspect >= 0.55 && aspect <= 1.8) return { type:'icon', confidence:0.64, variance };
  if (heightRatio <= 0.13 && aspect >= 1.6 && widthRatio < 0.55) return { type:'control', confidence:0.7, variance };
  if (variance > 900 && widthRatio > 0.07 && heightRatio > 0.07) return { type:'image', confidence:0.73, variance };
  if (widthRatio > 0.12 && heightRatio > 0.06) return { type:areaRatio > 0.28 ? 'section' : 'frame', confidence:areaRatio > 0.08 ? 0.78 : 0.69, variance };
  return { type:'unknown', confidence:0.48, variance };
}

function assessPixelQuality(candidate, width, height) {
  const candidateArea = boxArea(candidate);
  const minimumTextHeight = Math.max(5, Math.round(height * 0.008));
  const minimumAtomicEdge = Math.max(5, Math.round(Math.min(width, height) * 0.007));
  let reason = '';
  if (candidate.type === 'text' && (candidate.height <= minimumTextHeight || candidate.width <= 8 || candidateArea <= 52)) reason = 'micro-text-fragment';
  else if (candidate.type === 'icon' && (Math.min(candidate.width, candidate.height) < minimumAtomicEdge || candidateArea <= 44)) reason = 'micro-icon-fragment';
  else if (candidate.type === 'unknown' && (Math.min(candidate.width, candidate.height) <= 4 || candidateArea <= 42)) reason = 'micro-edge-fragment';
  return reason
    ? { level:'noise', reason, recommendation:'exclude', confidence:0.94 }
    : { level:'candidate', reason:'pixel-structure', recommendation:'review', confidence:0.6 };
}

function overlap(left, right) {
  const x1 = Math.max(left.x, right.x);
  const y1 = Math.max(left.y, right.y);
  const x2 = Math.min(left.x + left.width, right.x + right.width);
  const y2 = Math.min(left.y + left.height, right.y + right.height);
  const intersection = Math.max(0, x2 - x1) * Math.max(0, y2 - y1);
  return intersection / Math.max(1, boxArea(left) + boxArea(right) - intersection);
}

function contains(outer, inner, margin = 2) {
  return outer.x <= inner.x + margin && outer.y <= inner.y + margin && outer.x + outer.width >= inner.x + inner.width - margin && outer.y + outer.height >= inner.y + inner.height - margin;
}

function separatorBoxes(mask, width, height) {
  const boxes = [];
  const scan = (length, crossLength, vertical) => {
    let runStart = null;
    for (let position = 0; position <= length; position += 1) {
      let count = 0;
      if (position < length) {
        for (let cross = 0; cross < crossLength; cross += 1) {
          const index = vertical ? cross * width + position : position * width + cross;
          count += mask[index];
        }
      }
      const active = position < length && count / crossLength > 0.52;
      if (active && runStart === null) runStart = position;
      if ((!active || position === length) && runStart !== null) {
        const thickness = position - runStart;
        if (thickness <= 5) boxes.push(vertical ? { x:runStart, y:0, width:thickness, height, pixels:count } : { x:0, y:runStart, width, height:thickness, pixels:count });
        runStart = null;
      }
    }
  };
  scan(width, height, true);
  scan(height, width, false);
  return boxes;
}

function deduplicate(candidates) {
  const result = [];
  for (const candidate of candidates.sort((left, right) => right.confidence - left.confidence || boxArea(right) - boxArea(left))) {
    const duplicate = result.find((existing) => overlap(existing, candidate) > 0.84 && existing.type === candidate.type);
    if (!duplicate) result.push(candidate);
  }
  const limits = { page:1, section:35, frame:60, text:100, icon:60, image:40, control:70, divider:35, unknown:35 };
  const counts = {};
  return result.filter((item) => {
    counts[item.type] = (counts[item.type] || 0) + 1;
    return counts[item.type] <= limits[item.type];
  });
}

function assignHierarchy(candidates) {
  const containers = candidates.filter((item) => ['page','section','frame'].includes(item.type));
  for (const candidate of candidates) {
    if (candidate.type === 'page') { candidate.parentIndex = null; continue; }
    const parents = containers.filter((container) => container !== candidate && boxArea(container) > boxArea(candidate) * 1.08 && contains(container, candidate));
    parents.sort((left, right) => boxArea(left) - boxArea(right));
    candidate.parentIndex = parents.length ? candidates.indexOf(parents[0]) : candidates.findIndex((item) => item.type === 'page');
  }
}

export function analyzeImageData(imageData, options = {}) {
  const { data, width, height } = imageData;
  if (!data || !Number.isInteger(width) || !Number.isInteger(height) || data.length !== width * height * 4) throw new Error('ImageData 无效');
  const sourceScaleX = Number(options.sourceScaleX || 1);
  const sourceScaleY = Number(options.sourceScaleY || 1);
  const idPrefix = String(options.idPrefix || 'analysis.capture').replace(/[^A-Za-z0-9_.:-]/g, '-').slice(0, 100);
  const luma = luminanceBuffer(data, width, height);
  const threshold = Number(options.edgeThreshold || estimateEdgeThreshold(luma, width, height));
  const edges = edgeMask(luma, width, height, threshold);
  const grouped = dilate(edges.mask, width, height, 3, 1);
  const components = connectedBoxes(grouped, width, height);
  const raw = components.map((box) => {
    const classified = { ...box, ...classifyBox(box, width, height, luma), source:'pixel-structure' };
    return { ...classified, quality:assessPixelQuality(classified, width, height) };
  });
  separatorBoxes(edges.mask, width, height).forEach((box) => raw.push({ ...box, type:'divider', confidence:0.9, variance:0, source:'edge-projection' }));
  raw.push({ x:0, y:0, width, height, pixels:width * height, type:'page', confidence:0.99, variance:regionVariance(luma, width, height, { x:0, y:0, width, height }), source:'image-boundary' });
  const candidates = deduplicate(raw).sort((left, right) => boxArea(right) - boxArea(left));
  assignHierarchy(candidates);

  const typeCounts = {};
  const nodes = candidates.map((candidate, index) => {
    typeCounts[candidate.type] = (typeCounts[candidate.type] || 0) + 1;
    const id = `${idPrefix}.${candidate.type}.${typeCounts[candidate.type]}`;
    return {
      id,
      name:`${TYPE_LABELS[candidate.type]} ${typeCounts[candidate.type]}`,
      type:candidate.type,
      parentIndex:candidate.parentIndex,
      bounds:{
        x:Math.round(candidate.x * sourceScaleX),
        y:Math.round(candidate.y * sourceScaleY),
        width:Math.max(1, Math.round(candidate.width * sourceScaleX)),
        height:Math.max(1, Math.round(candidate.height * sourceScaleY)),
      },
      confidence:Number(candidate.confidence.toFixed(3)),
      source:candidate.source,
      variance:Math.round(candidate.variance || 0),
      quality:candidate.quality ? { ...candidate.quality } : undefined,
      accepted:candidate.type === 'page' || candidate.confidence >= 0.92,
    };
  });
  nodes.forEach((node) => { node.parentId = Number.isInteger(node.parentIndex) && node.parentIndex >= 0 ? nodes[node.parentIndex]?.id || null : null; delete node.parentIndex; });
  const palette = paletteFromPixels(data, width, height);
  return {
    analyzerVersion:'0.1.0',
    analysisSize:{ width, height },
    sourceSize:{ width:Math.round(width * sourceScaleX), height:Math.round(height * sourceScaleY) },
    nodes,
    palette,
    metrics:{ threshold, edgePixels:edges.active, edgeRatio:Number((edges.active / (width * height)).toFixed(4)), components:components.length, candidates:nodes.length, noiseCandidates:nodes.filter((node) => node.quality?.level === 'noise').length },
  };
}
