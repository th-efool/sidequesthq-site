import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { atomicWriteBundle, atomicWriteJSON, applyDocumentToProject, collectSourceIdentities, documentChangeSummary, ensureSyncProject, executableSourceHash, generatedSourceHash, inspectSafeConflictRebase, readSyncSnapshot, sourceHash, syncPaths } from './ui-sync-core.mjs';

const root = process.cwd();
const command = process.argv[2] || 'status';
const labels = { clean:'干净', 'pending-codex':'待 Codex 应用', 'source-ahead':'源码领先', conflict:'冲突' };

async function printStatus() {
  const snapshot = await readSyncSnapshot(root);
  const summary = documentChangeSummary(snapshot.document);
  console.log(`UI Studio 同步：${labels[snapshot.state.state] || snapshot.state.state}`);
  console.log(`文档修订：r${snapshot.document.revision}；已应用：r${snapshot.state.appliedRevision}`);
  console.log(`实际页面：r${snapshot.state.previewRevision || 0}（${snapshot.state.previewIsCurrent ? '已更新' : snapshot.state.previewStatus || '未更新'}）`);
  console.log(`调整：${summary.nodes} 个节点，${summary.text} 个文字，${summary.styles} 个样式，${summary.icons} 个图标`);
  if (summary.analyses) console.log(`识别：${summary.analyses} 次分析，当前 ${summary.candidates} 个候选，${summary.manual} 项待确认`);
  console.log(`源码：${snapshot.currentHash.slice(0, 12)}；基线：${snapshot.state.baseSourceHash.slice(0, 12)}`);
  if (snapshot.state.state === 'pending-codex') console.log('下一步：运行 npm run sync:apply');
  if (snapshot.state.state === 'source-ahead') console.log('下一步：回到 Studio 点击“拉取 Codex 最新版”');
  if (snapshot.state.state === 'conflict') console.log('停止应用：Studio 修改与源码同时变化，请先比较并解决冲突。');
  return snapshot;
}

async function readOperationBatches(file) {
  let source = '';
  try { source = await readFile(file, 'utf8'); }
  catch (error) { if (error.code === 'ENOENT') return []; else throw error; }
  return source.split(/\r?\n/).filter(Boolean).map((line, index) => {
    try { return JSON.parse(line); }
    catch (error) { return { invalid:true, line:index + 1, error:error.message }; }
  });
}

async function buildCodexContext(snapshot) {
  const paths = syncPaths(root);
  const sourceIdentities = await collectSourceIdentities(root);
  const batches = await readOperationBatches(paths.operations);
  const appliedRevision = Number(snapshot.state.appliedRevision || 0);
  const pendingBatches = batches.filter((batch) => !batch.invalid && Number(batch.revision || 0) > appliedRevision);
  const pendingOperations = pendingBatches.flatMap((batch) => Array.isArray(batch.operations) ? batch.operations : []);
  const targetIds = [...new Set(pendingOperations.flatMap((operation) => Array.isArray(operation.targetIds) ? operation.targetIds : []))].sort();
  const evidenceIds = new Set();
  for (const run of snapshot.document.evidence?.runs || []) {
    for (const candidate of run.candidates || []) if (candidate?.id) evidenceIds.add(candidate.id);
  }
  for (const item of snapshot.document.manualQueue || []) if (item?.id) evidenceIds.add(item.id);
  const unresolvedTargetIds = targetIds.filter((id) => !sourceIdentities.ids.has(id) && !evidenceIds.has(id) && !id.startsWith('analysis.'));
  const identityRegistry = {
    schemaVersion:1,
    generatedAt:new Date().toISOString(),
    sourceHash:snapshot.currentHash,
    selector:'data-ui-id',
    identityCount:sourceIdentities.entries.length,
    entries:sourceIdentities.entries,
    duplicateIds:sourceIdentities.duplicates.map((entry) => entry.id),
    unresolvedTargetIds,
  };
  await atomicWriteJSON(paths.identityRegistry, identityRegistry);
  let nextAction = 'browser-verify-or-edit';
  if (snapshot.state.state === 'pending-codex') nextAction = unresolvedTargetIds.length || sourceIdentities.duplicates.length ? 'resolve-identity-errors' : 'apply-studio-revision';
  else if (snapshot.state.state === 'source-ahead') nextAction = 'refresh-studio-base';
  else if (snapshot.state.state === 'conflict') nextAction = 'resolve-studio-conflict';
  return {
    protocolVersion:1,
    persistedOnly:true,
    notice:'Codex can read saved project revisions only. Unsaved browser edits must be saved to the project first.',
    latestUI:{
      revision:Number(snapshot.document.revision || 0),
      appliedRevision,
      previewRevision:Number(snapshot.state.previewRevision || 0),
      previewStatus:snapshot.state.previewStatus || 'clean',
      previewCoverage:snapshot.state.previewCoverage || 'complete',
      previewIsCurrent:Boolean(snapshot.state.previewIsCurrent),
      state:snapshot.state.state,
      updatedAt:snapshot.document.updatedAt || snapshot.state.updatedAt || null,
      updatedBy:snapshot.document.updatedBy || snapshot.state.lastWriter || null,
      summary:documentChangeSummary(snapshot.document),
    },
    identity:{
      selector:'data-ui-id',
      registryPath:path.relative(root, paths.identityRegistry).replaceAll('\\', '/'),
      identityCount:sourceIdentities.entries.length,
      duplicateIds:identityRegistry.duplicateIds,
      unresolvedTargetIds,
      status:identityRegistry.duplicateIds.length || unresolvedTargetIds.length ? 'invalid' : 'valid',
    },
    pending:{ batches:pendingBatches, operations:pendingOperations },
    source:{ currentHash:snapshot.currentHash, baseHash:snapshot.state.baseSourceHash },
    files:{
      document:path.relative(root, paths.document).replaceAll('\\', '/'),
      operations:path.relative(root, paths.operations).replaceAll('\\', '/'),
      handoff:path.relative(root, paths.handoff).replaceAll('\\', '/'),
      state:path.relative(root, paths.state).replaceAll('\\', '/'),
    },
    nextAction,
  };
}

if (command === 'init') {
  await ensureSyncProject(root);
  await printStatus();
} else if (command === 'status') {
  await printStatus();
} else if (command === 'changes') {
  const snapshot = await printStatus();
  const summary = documentChangeSummary(snapshot.document);
  if (!summary.paths.length && !summary.analyses) console.log('没有参数级调整。');
  else if (!summary.paths.length) console.log('没有参数级调整；存在结构识别证据。');
  else summary.paths.forEach((item) => console.log(`- ${item}`));
} else if (command === 'context') {
  const snapshot = await readSyncSnapshot(root);
  console.log(JSON.stringify(await buildCodexContext(snapshot), null, 2));
} else if (command === 'apply') {
  const snapshot = await readSyncSnapshot(root);
  if (snapshot.state.state === 'conflict') throw new Error('检测到源码与 Studio 同时变化，拒绝自动覆盖。请先解决冲突。');
  if (snapshot.state.state !== 'pending-codex') {
    console.log(`无需应用：当前状态为 ${labels[snapshot.state.state] || snapshot.state.state}。`);
    process.exit(0);
  }
  await applyDocumentToProject(root, snapshot.document);
  const [hash, previewHash, generatedHash] = await Promise.all([sourceHash(root), executableSourceHash(root), generatedSourceHash(root)]);
  const paths = syncPaths(root);
  const now = new Date().toISOString();
  const document = { ...snapshot.document, baseSourceHash:hash, updatedAt:now, updatedBy:'codex' };
  const state = {
    ...snapshot.storedState,
    documentRevision:document.revision,
    appliedRevision:document.revision,
    previewRevision:document.revision,
    previewStatus:'applied',
    previewCoverage:'complete',
    previewBlockedTargets:[],
    previewIssue:null,
    previewUpdatedAt:now,
    previewSourceHash:previewHash,
    previewGeneratedHash:generatedHash,
    baseSourceHash:hash,
    currentSourceHash:hash,
    state:'clean',
    lastWriter:'codex',
    updatedAt:now,
  };
  const handoff = { protocolVersion:1, revision:document.revision, status:'applied', summary:documentChangeSummary(document), appliedAt:now };
  await atomicWriteBundle(paths.transaction, [
    { file:paths.document, value:document },
    { file:paths.state, value:state },
    { file:paths.handoff, value:handoff },
  ]);
  console.log(`已应用 Studio 修订 r${document.revision}，生成 ui-studio-overrides.css，并更新可用页面。`);
} else if (command === 'refresh-generated') {
  const snapshot = await readSyncSnapshot(root);
  if (snapshot.state.state === 'conflict') throw new Error('检测到未解决的 Studio 冲突，拒绝刷新生成资产。');
  await applyDocumentToProject(root, snapshot.document);
  const [hash, previewHash, generatedHash] = await Promise.all([sourceHash(root), executableSourceHash(root), generatedSourceHash(root)]);
  if (hash !== snapshot.currentHash) throw new Error('刷新生成资产意外改变了生产源码哈希。');
  const paths = syncPaths(root);
  const now = new Date().toISOString();
  const state = {
    ...snapshot.storedState,
    previewRevision:Number(snapshot.document.revision || 0),
    previewStatus:'applied',
    previewCoverage:'complete',
    previewBlockedTargets:[],
    previewIssue:null,
    previewUpdatedAt:now,
    previewSourceHash:previewHash,
    previewGeneratedHash:generatedHash,
    currentSourceHash:hash,
    updatedAt:now,
  };
  await atomicWriteJSON(paths.state, state);
  console.log(`已从 UI Document r${snapshot.document.revision} 重新生成 Studio 资产。`);
} else if (command === 'resolve-safe') {
  const snapshot = await readSyncSnapshot(root);
  const inspection = await inspectSafeConflictRebase(root, snapshot);
  if (!inspection.safe) throw new Error(`拒绝自动重基线：${inspection.reasons.join(', ') || 'unknown-reason'}`);
  const paths = syncPaths(root);
  const now = new Date().toISOString();
  const document = { ...snapshot.document, baseSourceHash:inspection.currentHash, updatedAt:now, updatedBy:'codex' };
  const resolution = {
    strategy:'safe-visual-rebase',
    fromHash:inspection.fromHash,
    toHash:inspection.currentHash,
    revision:inspection.revision,
    appliedRevision:inspection.appliedRevision,
    targetCount:inspection.targetCount,
    resolvedAt:now,
  };
  const state = {
    ...snapshot.storedState,
    baseSourceHash:inspection.currentHash,
    currentSourceHash:inspection.currentHash,
    state:'pending-codex',
    lastWriter:'codex',
    conflictResolution:resolution,
    updatedAt:now,
  };
  const handoff = {
    protocolVersion:1,
    revision:document.revision,
    status:'rebased-waiting-codex',
    summary:documentChangeSummary(document),
    conflictResolution:resolution,
    requestedAt:now,
  };
  await atomicWriteJSON(paths.document, document);
  await atomicWriteJSON(paths.state, state);
  await atomicWriteJSON(paths.handoff, handoff);
  console.log(`已安全重基线 Studio 修订 r${document.revision}；${inspection.targetCount} 个视觉目标等待应用。`);
} else if (command === 'source-updated') {
  const snapshot = await readSyncSnapshot(root);
  const hash = await sourceHash(root);
  const paths = syncPaths(root);
  const pending = Number(snapshot.document.revision) > Number(snapshot.storedState.appliedRevision || 0);
  const state = {
    ...snapshot.storedState,
    currentSourceHash:hash,
    state:pending ? 'conflict' : (hash === snapshot.storedState.baseSourceHash ? 'clean' : 'source-ahead'),
    lastWriter:'codex',
    updatedAt:new Date().toISOString(),
  };
  await atomicWriteJSON(paths.state, state);
  await printStatus();
} else {
  throw new Error(`未知命令：${command}`);
}
