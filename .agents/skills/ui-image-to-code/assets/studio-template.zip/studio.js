(() => {
  const CANVAS_CORE_VERSION = '2.13.0';
  const SHORTCUT_LAYER_VERSION = '1.2.0';
  const STORAGE_KEY = 'ui-image-to-code-studio-overrides-v1';
  const ICONS_KEY = 'ui-image-to-code-studio-icons-v1';
  const LOCKS_KEY = 'ui-image-to-code-studio-locks-v1';
  const GUIDES_KEY = 'ui-image-to-code-studio-guides-v1';
  const GUIDES_VISIBILITY_KEY = 'ui-image-to-code-studio-guides-visible-v1';
  const CANVAS_MODE_KEY = 'ui-image-to-code-studio-canvas-mode-v1';
  const CANVAS_VIEW_KEY = 'ui-image-to-code-studio-canvas-view-v1';
  const TREE_STATE_KEY = 'ui-image-to-code-studio-tree-state-v3';
  const PANEL_STATE_KEY = 'ui-image-to-code-studio-panel-state-v1';
  const FEATURE_STATE_KEY = 'ui-image-to-code-studio-feature-state-v1';
  const DRAFT_META_KEY = 'ui-image-to-code-studio-draft-meta-v1';
  const RECOVERY_DRAFT_KEY = 'ui-image-to-code-studio-recovery-draft-v2';
  const CLIENT_ID_KEY = 'ui-image-to-code-studio-client-id-v1';
  const DRAFT_SCHEMA_VERSION = 2;
  const CLIPBOARD_KEY = 'ui-image-to-code-studio-layer-clipboard-v1';
  const STRUCTURE_KEY = 'ui-image-to-code-studio-structure-v1';
  const LAYER_META_KEY = 'ui-image-to-code-studio-layer-meta-v1';
  const REFERENCE_VIEW_KEY = 'ui-image-to-code-studio-reference-view-v1';
  const PAGE_WORKSPACE_KEY = 'ui-image-to-code-studio-page-workspace-v1';
  const PAGE_LAYER_COUNTS_KEY = 'ui-image-to-code-studio-page-layer-counts-v1';
  const PAGE_EXPANDED_KEY = 'ui-image-to-code-studio-expanded-page-v1';
  const SYNC_API = '/__ui_sync';
  const STYLE_KEYS = ['width', 'height', 'translate', 'scale', 'rotate', 'transformOrigin', 'backgroundColor', 'color', 'fontSize', 'fontFamily', 'fontWeight', 'lineHeight', 'letterSpacing', 'textAlign', 'borderRadius', 'borderWidth', 'borderColor', 'borderStyle', 'boxShadow', 'opacity', 'padding', 'zIndex', 'position', 'display'];
  const FONT_FAMILIES = {
    system: '"Microsoft YaHei", "PingFang SC", Arial, sans-serif',
    'noto-sans': '"Noto Sans SC", "Microsoft YaHei", sans-serif',
    'noto-serif': '"Noto Serif SC", "Songti SC", SimSun, serif',
    lxgw: '"LXGW WenKai", "KaiTi", serif',
    jetbrains: '"JetBrains Mono", Consolas, monospace'
  };
  const LABELS = {
    'app.shell': '应用框架', sidebar: '左侧导航', 'sidebar.brand': '品牌标识', 'sidebar.navigation': '菜单栏', 'sidebar.account': '账户区域',
    'sidebar.brand.mark': '品牌图标', 'sidebar.brand.copy': '品牌文字', 'sidebar.nav.home': '菜单 · 首页', 'sidebar.nav.all': '菜单 · 全品类商品图',
    'sidebar.nav.replica': '菜单 · 复刻商品图', 'sidebar.nav.assets': '菜单 · 素材库资产', 'sidebar.nav.tools': '菜单 · 工具箱', 'sidebar.nav.admin': '菜单 · 管理员工具',
    'sidebar.account.credit': '积分充值', 'sidebar.account.profile': '用户资料', 'controls.heading': '面板标题', 'controls.content': '参数滚动区',
    'controls.panel': '复刻参数面板', 'controls.reference': '参考图外框', 'controls.reference.title': '参考图标题区',
    'controls.reference.drop': '参考图上传框', 'controls.reference.plus': '参考图加号', 'controls.reference.primary': '参考图主文字',
    'controls.reference.secondary': '参考图说明文字', 'controls.product': '产品素材外框', 'controls.product.title': '产品素材标题区',
    'controls.product.drop': '产品素材上传框', 'controls.product.plus': '产品素材加号', 'controls.product.primary': '产品素材主文字',
    'controls.product.secondary': '产品素材说明文字', 'controls.prompt': '辅助词输入框', 'controls.prompt.label': '辅助词标题',
    'controls.prompt.input': '辅助词文本域', 'controls.prompt.assist': 'AI 辅助按钮',
    'controls.settings': '生成设置', 'controls.settings.details': '生成设置详情', 'controls.quality': '输出清晰度', 'controls.scope': '生成范围', 'controls.count': '生成数量', 'controls.submit': '提交按钮',
    'controls.quality.label': '清晰度标题', 'controls.quality.options': '清晰度选项组', 'controls.scope.label': '生成范围标题',
    'controls.quality.fast': '快速选项', 'controls.quality.1k': '1K 选项', 'controls.quality.2k': '2K 选项',
    'controls.scope.options': '生成范围选项组', 'controls.scope.single': '单图选项', 'controls.scope.batch': '批量选项',
    'controls.count.next': '更多数量', 'preview.panel': '结果预览区', 'preview.header': '结果预览顶栏',
    'preview.heading': '结果预览标题', 'preview.progress': '步骤进度', 'preview.download': '批量下载按钮', 'preview.assist': '悬浮 AI 按钮',
    'preview.empty': '等待结果状态', 'preview.empty.icon': '等待结果图标', 'preview.empty.title': '等待结果标题', 'preview.empty.caption': '等待结果说明'
  };
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const clone = (value) => JSON.parse(JSON.stringify(value));

  function sessionClientId() {
    try {
      let id = sessionStorage.getItem(CLIENT_ID_KEY);
      if (!id) {
        id = globalThis.crypto?.randomUUID?.() || `tab-${Date.now()}-${Math.random().toString(36).slice(2)}`;
        sessionStorage.setItem(CLIENT_ID_KEY, id);
      }
      return id;
    } catch { return `tab-${Date.now()}-${Math.random().toString(36).slice(2)}`; }
  }
  const CLIENT_ID = sessionClientId();

  function ensureReliabilityUI() {
    if (!document.querySelector('#studio-update-banner')) {
      const banner = document.createElement('div');
      banner.id = 'studio-update-banner';
      banner.className = 'studio-update-banner';
      banner.hidden = true;
      banner.setAttribute('role', 'status');
      banner.setAttribute('aria-live', 'polite');
      banner.innerHTML = '<div><strong>UI Studio 已更新</strong><span id="studio-update-detail">重新载入后使用最新画布核心；本地草稿会先安全保存。</span></div><button id="studio-update-reload" type="button">保存草稿并重新载入</button>';
      document.querySelector('.studio-toolbar')?.after(banner);
    }
    const historyRow = document.querySelector('.sync-history-row');
    if (historyRow && !document.querySelector('#sync-recovery-actions')) {
      const actions = document.createElement('div');
      actions.id = 'sync-recovery-actions';
      actions.className = 'sync-recovery-actions';
      actions.hidden = true;
      actions.innerHTML = '<button id="sync-recover-draft" type="button"><b>恢复隔离草稿</b><small>把旧标签或旧修订中的本地调整恢复为当前草稿</small></button><button id="sync-discard-recovery" class="danger-quiet" type="button"><b>丢弃隔离草稿</b><small>当前项目修订不会受到影响</small></button>';
      historyRow.before(actions);
    }
  }
  ensureReliabilityUI();

  const canvasContractBadge = document.querySelector('#canvas-contract-badge');
  if (canvasContractBadge) canvasContractBadge.title = `中间画布核心 ${CANVAS_CORE_VERSION}：外壳调整不得改变选择、缩放、吸附、参考线与导出语义`;

  const frame = $('#preview-frame');
  const transform = $('#preview-transform');
  const stage = $('#canvas-stage');
  const world = $('#canvas-world');
  const overlayImage = $('#reference-overlay');
  const toast = $('#studio-toast');
  let frameDocument;
  let selectionBox;
  let snapVertical;
  let snapHorizontal;
  let suppressCanvasClick = false;
  let nodes = [];
  const baseSizes = new Map();
  const baseTexts = new Map();
  const baseStyles = new Map();
  const baseNames = new Map();
  const originalIcons = new Map();
  let selectedId = null;
  let selectedIds = new Set();
  let pageWorkspaceState = loadJSON(PAGE_WORKSPACE_KEY, {});
  let pageLayerCounts = loadJSON(PAGE_LAYER_COUNTS_KEY, {});
  let activePageIdentity = '';
  let pageDirectoryOpen = true;
  let expandedPageKey = String(localStorage.getItem(PAGE_EXPANDED_KEY) || '');
  let pendingPageExpansionKey = '';
  let pageDirectoryLoadingKey = '';
  let activeTransientMenuKey = '';
  let pageDirectoryActivationTimer = 0;
  let pageMutationObserver = null;
  let pageRefreshTimer = 0;
  let pageLayerScanTimer = 0;
  let pageLayerScanToken = 0;
  let pageLayerScanFrame = null;
  const pageLayerScanningKeys = new Set();
  let allowBoundPageAction = false;
  let selectionMarkerSignature = '';
  let selectionScope = 'layer';
  let layerFilter = 'all';
  let activeFeature = 'layers';
  let featureState = loadJSON(FEATURE_STATE_KEY, { selections:{}, scroll:{}, showDeveloper:false });
  let referenceViewState = loadJSON(REFERENCE_VIEW_KEY, { visible:false, layer:'above', strength:45 });
  referenceViewState = {
    visible: Boolean(referenceViewState?.visible),
    layer: referenceViewState?.layer === 'below' ? 'below' : 'above',
    strength: Math.max(10, Math.min(90, number(referenceViewState?.strength, 45))),
  };
  let featureHoverElement = null;
  let canvasHoverElement = null;
  let overrides = loadJSON(STORAGE_KEY, {});
  let iconReplacements = loadJSON(ICONS_KEY, {});
  let layerClipboard = loadJSON(CLIPBOARD_KEY, null);
  let structuralEdits = loadJSON(STRUCTURE_KEY, { insertions:[] });
  let layerMetadata = loadJSON(LAYER_META_KEY, {});
  let locks = new Set(loadJSON(LOCKS_KEY, []));
  let guides = loadJSON(GUIDES_KEY, []);
  const UICommandHistory = window.UICommandCore?.UICommandHistory;
  if (!UICommandHistory) throw new Error('UI Command Core 未加载');
  let commandHistory = new UICommandHistory(snapshotState(), { limit:200, mergeWindow:520, baselineLabel:'打开项目' });
  let iconImportEntries = [];
  let iconImportCandidate = null;
  let iconImportRequestId = 0;
  const CANVAS_WORLD_SIZE = 65536;
  const MANIPULATION_AUTO_PAN_EDGE = 56;
  const MANIPULATION_AUTO_PAN_MAX_SPEED = 18;
  const SNAP_STRUCTURE_ACQUIRE_SCREEN_PX = 4;
  const SNAP_GUIDE_ACQUIRE_SCREEN_PX = 3;
  const SNAP_GRID_ACQUIRE_SCREEN_PX = 2.5;
  const SNAP_STRUCTURE_RELEASE_SCREEN_PX = 6;
  const SNAP_GUIDE_RELEASE_SCREEN_PX = 5;
  const SNAP_GRID_RELEASE_SCREEN_PX = 4.5;
  const SNAP_PRIORITY_TIE_SCREEN_PX = .75;
  const SNAP_SWITCH_ADVANTAGE_SCREEN_PX = 1;
  let canvasViewState = loadJSON(CANVAS_VIEW_KEY, { zoom:.52, scrollLeft:null, scrollTop:null });
  let zoom = Math.max(.05, Math.min(3, number(canvasViewState.zoom, .52)));
  let canvasFitMode = localStorage.getItem(CANVAS_MODE_KEY) || 'contain';
  let autoFitCanvas = canvasFitMode !== 'manual';
  let handToolEnabled = false;
  let spacePanPressed = false;
  let snapEnabled = true;
  let gridEnabled = false;
  let guidesVisible = localStorage.getItem(GUIDES_VISIBILITY_KEY) !== 'false';
  let lastSnapStatus = '';
  let collapsedNodes = new Set(loadJSON(TREE_STATE_KEY, [
    'app.shell',
    'sidebar.nav.home',
    'sidebar.nav.all',
    'sidebar.nav.replica',
    'sidebar.nav.assets',
    'sidebar.nav.tools',
    'sidebar.nav.admin',
  ]));
  let panelState = loadJSON(PANEL_STATE_KEY, { layersCollapsed:false, inspectorCollapsed:false, layersWidth:null });
  let viewport = { width: 1920, height: 919 };
  let syncStatus = null;
  let syncDocument = null;
  let studioDirty = false;
  let syncPollTimer = null;
  let syncInitialized = false;
  let wheelZoomFrame = 0;
  let wheelZoomDelta = 0;
  let wheelZoomPoint = null;
  let zoomSettleTimer = 0;
  let rulerSyncFrame = 0;
  let panInertiaFrame = 0;
  let cameraSaveTimer = 0;
  let cameraMotionFrame = 0;
  let cameraHudTimer = 0;
  let canvasPanActive = false;
  let canvasAutoFitSuspended = 0;
  let parkedFeatureCamera = null;

  const FEATURE_META = {
    layers: { title:'页面结构', subtitle:'菜单、页面与真实图层', inspector:'属性' },
    recognize: { title:'截图转 UI', subtitle:'分析、审核并生成可编辑结构', inspector:'识别证据' },
    icons: { title:'图标资源', subtitle:'选择、预览并替换独立图标', inspector:'图标属性' },
    text: { title:'文字系统', subtitle:'内容、排版与免费字体', inspector:'文字属性' },
    frames: { title:'框与样式', subtitle:'容器、卡片、按钮和输入框', inspector:'样式属性' },
    compare: { title:'原图对比', subtitle:'叠图检查位置、尺寸与间距', inspector:'对比检查' },
    export: { title:'项目交付', subtitle:'修订、源码、预览与 95% 验收', inspector:'交付中心' }
  };
  const DEDICATED_FEATURES = new Set(['recognize', 'compare', 'export']);
  const isDedicatedFeature = (feature = activeFeature) => DEDICATED_FEATURES.has(feature);
  const PAGE_ROUTES = [
    { id:'sidebar.nav.home', label:'首页', path:'/home' },
    { id:'sidebar.nav.all', label:'全品类商品图', path:'/all-category' },
    { id:'sidebar.nav.replica', label:'复刻商品图', path:'/replica', bound:true, content:['controls.panel','preview.panel'] },
    { id:'sidebar.nav.assets', label:'素材库资产', path:'/assets' },
    { id:'sidebar.nav.tools', label:'工具箱', path:'/tools' },
    { id:'sidebar.nav.admin', label:'管理员工具', path:'/admin' },
  ];

  function setExpandedPageKey(key = '') {
    expandedPageKey = String(key || '');
    pageDirectoryOpen = !expandedPageKey;
    if (expandedPageKey) localStorage.setItem(PAGE_EXPANDED_KEY, expandedPageKey);
    else localStorage.removeItem(PAGE_EXPANDED_KEY);
  }

  function discoveredPageEntries() {
    if (!frameDocument) return [];
    const candidates = [];
    const seenElements = new Set();
    const addCandidate = (element) => {
      const id = element?.dataset?.uiId;
      if (!id || seenElements.has(element)) return;
      let target = String(element.dataset.viewTarget || '').trim();
      const action = String(element.dataset.uiAction || element.dataset.action || '').trim();
      const rawHref = element.matches('a[href]') ? String(element.getAttribute('href') || '').trim() : '';
      if (!target && !action && (!rawHref || rawHref === '#' || /^javascript:/i.test(rawHref))) return;
      // A brand or breadcrumb link often points to the same hash-backed view as
      // a real navigation button.  Treat that hash as the existing view target
      // instead of inventing a duplicate page in the directory.
      if (!target && rawHref.startsWith('#')) {
        const hashTarget = decodeURIComponent(rawHref.slice(1)).trim();
        const matchingView = hashTarget
          ? frameDocument.querySelector(`[data-view="${CSS.escape(hashTarget)}"][data-ui-id]`)
          : null;
        const matchingTrigger = hashTarget
          ? frameDocument.querySelector(`[data-view-target="${CSS.escape(hashTarget)}"][data-ui-id]`)
          : null;
        if (matchingView && matchingTrigger) target = hashTarget;
      }
      let href = '';
      if (rawHref) {
        try {
          const url = new URL(rawHref, frame.contentWindow.location.href);
          if (url.origin !== frame.contentWindow.location.origin) return;
          href = `${url.pathname}${url.search}${url.hash}`;
        } catch { return; }
      }
      const container = target
        ? frameDocument.querySelector(`[data-view="${CSS.escape(target)}"][data-ui-id]`)
        : null;
      const inNavigation = Boolean(element.closest('nav,[role="navigation"],aside'));
      const explicitProjectMenu = Boolean(element.closest('[data-ui-project-menu]'));
      const score = (inNavigation ? 80 : 0)
        + (explicitProjectMenu ? 70 : 0)
        + (/^nav[.:-]/i.test(id) ? 40 : 0)
        + (element.classList.contains('nav-item') || element.classList.contains('sidebar-home') ? 30 : 0)
        + (element.offsetParent !== null ? 20 : 0)
        - (element.closest('[class*="quick"]') ? 25 : 0);
      const label = String(directLayerText(element) || element.textContent || element.getAttribute('aria-label') || target || href)
        .replace(/\s+/g, ' ').trim().slice(0, 42);
      const bodyView = String(frameDocument.body?.dataset.currentView || '').trim();
      const active = Boolean(
        element.getAttribute('aria-current') === 'page'
        || (target && bodyView === target)
        || (container && !container.hidden)
        || element.getAttribute('aria-pressed') === 'true'
        || element.dataset.active === 'true'
        || element.classList.contains('active')
        || (href && `${frame.contentWindow.location.pathname}${frame.contentWindow.location.search}${frame.contentWindow.location.hash}` === href)
      );
      const kind = target || href ? 'page' : 'action';
      const parentTrigger = element.parentElement?.closest?.('[data-view-target][data-ui-id], nav a[href][data-ui-id], aside a[href][data-ui-id], [role="navigation"] a[href][data-ui-id], nav button[data-action][data-ui-id], aside button[data-action][data-ui-id], [role="navigation"] button[data-action][data-ui-id]');
      candidates.push({
        id,
        key:target ? `view:${target}` : href ? `href:${href}` : `action:${action}:${id}`,
        label:label || '未命名页面',
        target,
        href,
        action,
        kind,
        triggerId:id,
        containerId:container?.dataset.uiId || null,
        bound:Boolean(target || href || action),
        active,
        score,
        dynamic:true,
        parentTriggerId:parentTrigger?.dataset?.uiId || '',
      });
      seenElements.add(element);
    };
    $$('[data-view-target][data-ui-id]', frameDocument).forEach(addCandidate);
    $$('nav a[href][data-ui-id], aside a[href][data-ui-id], [role="navigation"] a[href][data-ui-id]', frameDocument).forEach(addCandidate);
    $$('nav button[data-action][data-ui-id], aside button[data-action][data-ui-id], [role="navigation"] button[data-action][data-ui-id]', frameDocument).forEach(addCandidate);
    const bestByKey = new Map();
    candidates.forEach((entry) => {
      const current = bestByKey.get(entry.key);
      if (!current || entry.score > current.score) bestByKey.set(entry.key, entry);
    });
    const entries = [...bestByKey.values()];
    const keyByTriggerId = new Map(entries.map((entry) => [entry.triggerId, entry.key]));
    return entries.map((entry) => ({
      ...entry,
      parentKey:keyByTriggerId.get(entry.parentTriggerId) || '',
    }));
  }

  function activePageEntry(entries = discoveredPageEntries()) {
    // Action entries may briefly expose an active/pressed state while their
    // popover or tool surface is open.  They are not pages and must never win
    // the single current-page identity used by the directory, layer tree and
    // persisted workspace state.
    return entries.find((entry) => entry.kind === 'page' && entry.active) || null;
  }

  function pageLayerProjectIdentity() {
    try {
      const url = new URL(frame.getAttribute('src') || frame.src, window.location.href);
      url.hash = '';
      return url.href;
    } catch { return String(frame.getAttribute('src') || frame.src || 'preview'); }
  }

  function pageLayerCountKey(entry) {
    return `${pageLayerProjectIdentity()}::${entry?.key || entry?.target || entry?.id || 'unknown'}`;
  }

  function pageRootInDocument(entry, documentRoot = frameDocument) {
    if (!entry || !documentRoot) return null;
    if (entry.target) return documentRoot.querySelector(`[data-view="${CSS.escape(entry.target)}"][data-ui-id]`);
    if (entry.containerId) return documentRoot.querySelector(`[data-ui-id="${CSS.escape(entry.containerId)}"]`);
    return null;
  }

  function countPageLayers(entry, documentRoot = frameDocument) {
    const root = pageRootInDocument(entry, documentRoot);
    return root ? 1 + root.querySelectorAll('[data-ui-id]').length : 0;
  }

  function rememberPageLayerCount(entry, count) {
    const normalized = Math.max(0, Math.round(Number(count) || 0));
    if (!entry || !normalized) return false;
    const key = pageLayerCountKey(entry);
    if (Number(pageLayerCounts[key]) === normalized) return false;
    pageLayerCounts[key] = normalized;
    localStorage.setItem(PAGE_LAYER_COUNTS_KEY, JSON.stringify(pageLayerCounts));
    return true;
  }

  function knownPageLayerCount(entry) {
    const liveCount = countPageLayers(entry);
    if (liveCount) rememberPageLayerCount(entry, liveCount);
    return liveCount || Math.max(0, Number(pageLayerCounts[pageLayerCountKey(entry)]) || 0);
  }

  function syncActivePageLayerCount(entries = discoveredPageEntries()) {
    const active = activePageEntry(entries);
    if (!active || active.kind !== 'page') return false;
    return rememberPageLayerCount(active, countPageLayers(active));
  }

  function stopPageLayerScan() {
    clearTimeout(pageLayerScanTimer);
    pageLayerScanTimer = 0;
    pageLayerScanToken += 1;
    pageLayerScanningKeys.clear();
    pageLayerScanFrame?.remove();
    pageLayerScanFrame = null;
  }

  function waitForScanFrameLoad(scanFrame, timeout = 5000) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('page scan load timeout')), timeout);
      scanFrame.addEventListener('load', () => { clearTimeout(timer); resolve(); }, { once:true });
      scanFrame.addEventListener('error', () => { clearTimeout(timer); reject(new Error('page scan load failed')); }, { once:true });
    });
  }

  function waitForScanPaint(scanWindow, delay = 72) {
    return new Promise((resolve) => {
      const finish = () => setTimeout(resolve, delay);
      if (typeof scanWindow?.requestAnimationFrame === 'function') scanWindow.requestAnimationFrame(() => scanWindow.requestAnimationFrame(finish));
      else finish();
    });
  }

  async function scanProjectPageLayerCounts(entries = discoveredPageEntries()) {
    const scannable = entries.filter((entry) => entry.bound && entry.kind === 'page' && entry.target);
    if (!scannable.length || !frame.contentDocument) return;
    stopPageLayerScan();
    const token = pageLayerScanToken;
    const scanFrame = document.createElement('iframe');
    pageLayerScanFrame = scanFrame;
    scanFrame.className = 'page-layer-scan-frame';
    scanFrame.tabIndex = -1;
    scanFrame.setAttribute('aria-hidden', 'true');
    scanFrame.style.cssText = 'position:fixed;left:-10000px;top:-10000px;width:1920px;height:1080px;visibility:hidden;pointer-events:none;border:0;';
    document.body.append(scanFrame);
    const loaded = waitForScanFrameLoad(scanFrame);
    scanFrame.src = frame.getAttribute('src') || frame.src;
    try {
      await loaded;
      if (token !== pageLayerScanToken || scanFrame !== pageLayerScanFrame) return;
      const scanDocument = scanFrame.contentDocument;
      const scanWindow = scanFrame.contentWindow;
      for (const entry of scannable) {
        if (token !== pageLayerScanToken) return;
        pageLayerScanningKeys.add(entry.key);
        renderPageDirectory(discoveredPageEntries());
        const trigger = scanDocument.querySelector(`[data-ui-project-menu] [data-view-target="${CSS.escape(entry.target)}"]`)
          || scanDocument.querySelector(`[data-view-target="${CSS.escape(entry.target)}"][data-ui-id]`);
        if (!trigger) continue;
        trigger.click();
        await waitForScanPaint(scanWindow);
        const count = countPageLayers(entry, scanDocument);
        rememberPageLayerCount(entry, count);
        pageLayerScanningKeys.delete(entry.key);
        renderPageDirectory(discoveredPageEntries());
      }
    } catch {
      // A failed isolated scan must never disturb the editable canvas. The active
      // page continues to report its live DOM count and unscanned pages stay explicit.
    } finally {
      if (token === pageLayerScanToken) {
        pageLayerScanningKeys.clear();
        scanFrame.remove();
        pageLayerScanFrame = null;
        renderPageDirectory(discoveredPageEntries());
      }
    }
  }

  function scheduleProjectPageLayerScan(entries = discoveredPageEntries()) {
    clearTimeout(pageLayerScanTimer);
    pageLayerScanTimer = setTimeout(() => scanProjectPageLayerCounts(entries), 80);
  }

  function savePageWorkspace(key = activePageIdentity) {
    if (!key) return;
    const liveIds = new Set(nodes.map((node) => node.id));
    pageWorkspaceState[key] = {
      selectedId,
      selectedIds:[...selectedIds],
      layerScroll:$('#layers')?.scrollTop || 0,
      collapsedIds:[...collapsedNodes].filter((id) => liveIds.has(id)),
    };
    localStorage.setItem(PAGE_WORKSPACE_KEY, JSON.stringify(pageWorkspaceState));
  }

  function pageEntryRootIds(entry) {
    return new Set([entry?.id, entry?.triggerId, entry?.containerId].filter(Boolean));
  }

  function clearPageNavigationSelection() {
    selectedId = null;
    selectedIds.clear();
    syncCanvasSelectionMarkers();
    if (selectionBox) selectionBox.hidden = true;
    syncFeatureObjectSelection();
    updateContextInspector();
    hideSnapFeedback();
    renderStatusBar();
  }

  function focusProjectMenu() {
    clearPageNavigationSelection();
    renderLayers($('#layer-search')?.value || '');
    requestAnimationFrame(() => {
      const directory = $('#layer-page-directory');
      const target = directory?.querySelector('[aria-current="page"] .page-directory-main')
        || directory?.querySelector('.page-directory-main');
      target?.scrollIntoView({ block:'nearest', inline:'nearest' });
      target?.focus({ preventScroll:true });
    });
  }

  function restorePageWorkspace(key, excludedIds = []) {
    const saved = pageWorkspaceState[key] || {};
    const liveIds = new Set(nodes.map((node) => node.id));
    const excluded = excludedIds instanceof Set ? excludedIds : new Set(excludedIds || []);
    if (Array.isArray(saved.collapsedIds)) {
      const retained = [...collapsedNodes].filter((id) => !liveIds.has(id));
      collapsedNodes = new Set(retained);
      saved.collapsedIds.forEach((id) => {
        if (liveIds.has(id) && !excluded.has(id)) collapsedNodes.add(id);
      });
    }
    excluded.forEach((id) => collapsedNodes.delete(id));
    const restored = (saved.selectedIds || []).filter((id) => liveIds.has(id) && !excluded.has(id));
    if (restored.length) {
      selectedIds = new Set(restored);
      selectedId = restored.includes(saved.selectedId) ? saved.selectedId : restored.at(-1);
      ancestorIds(selectedId).forEach((id) => collapsedNodes.delete(id));
    } else {
      selectedIds.clear();
      selectedId = null;
    }
    localStorage.setItem(TREE_STATE_KEY, JSON.stringify([...collapsedNodes]));
    syncCanvasSelectionMarkers();
    renderLayers($('#layer-search').value);
    updateContextInspector();
    if (selectedId) drawSelection();
    else if (selectionBox) selectionBox.hidden = true;
    renderStatusBar();
    requestAnimationFrame(() => {
      if ($('#layers') && Number.isFinite(Number(saved.layerScroll))) $('#layers').scrollTop = Number(saved.layerScroll || 0);
    });
  }

  function escapePageLabel(value) {
    return String(value || '').replace(/[&<>"']/g, (character) => ({
      '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;',
    })[character]);
  }

  function renderPageDirectory(entries = discoveredPageEntries()) {
    const directory = $('#layer-page-directory');
    if (!directory) return false;
    const layerTree = $('#layers');
    if (layerTree && directory.contains(layerTree)) directory.after(layerTree);
    const uniqueEntries = entries.filter((entry, index, list) => list.findIndex((item) => item.key === entry.key) === index);
    const shouldShow = uniqueEntries.length > 0;
    directory.hidden = !shouldShow;
    if (!shouldShow) { directory.replaceChildren(); return false; }
    const fragment = document.createDocumentFragment();
    const root = document.createElement('div');
    root.className = 'page-directory-root';
    root.setAttribute('role', 'presentation');
    root.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16M4 12h16M4 19h16"/><circle cx="7" cy="5" r="1"/><circle cx="7" cy="12" r="1"/><circle cx="7" cy="19" r="1"/></svg><span>项目菜单</span>';
    fragment.append(root);
    const entryKeys = new Set(uniqueEntries.map((entry) => entry.key));
    const childrenByParent = new Map();
    uniqueEntries.forEach((entry) => {
      const parentKey = entryKeys.has(entry.parentKey) ? entry.parentKey : '';
      if (!childrenByParent.has(parentKey)) childrenByParent.set(parentKey, []);
      childrenByParent.get(parentKey).push(entry);
    });
    const appendEntry = (entry, depth = 0, parent = fragment) => {
      const loading = pageDirectoryLoadingKey === entry.key;
      const expanded = Boolean(entry.active && expandedPageKey === entry.key);
      const currentPage = Boolean(entry.kind === 'page' && entry.active);
      const branch = document.createElement('div');
      branch.className = `page-directory-branch${expanded ? ' is-expanded' : ''}`;
      branch.dataset.pageKey = entry.key;
      branch.style.setProperty('--page-depth', String(Math.min(5, depth)));
      branch.setAttribute('role', 'treeitem');
      branch.setAttribute('aria-expanded', String(expanded));
      if (currentPage) branch.setAttribute('aria-current', 'page');
      const row = document.createElement('div');
      row.className = 'page-directory-row';
      row.dataset.bound = String(Boolean(entry.bound));
      row.classList.toggle('is-loading', loading);
      row.setAttribute('aria-busy', String(loading));
      const layerCount = entry.kind === 'page' ? knownPageLayerCount(entry) : 0;
      const countLabel = loading
        ? '同步中'
        : pageLayerScanningKeys.has(entry.key)
          ? '扫描中'
          : layerCount
            ? `${layerCount} 层`
            : entry.kind === 'action'
              ? '动态'
              : '待扫描';
      const stateLabel = loading
        ? '正在执行并同步真实图层…'
        : currentPage
          ? expanded ? '当前页面 · 图层已展开' : '当前页面 · 双击展开图层'
          : entry.kind === 'action' && expanded
            ? '功能已执行 · 结果图层已展开'
          : entry.bound
            ? entry.kind === 'action' ? '单击执行 · 双击展开结果图层' : '单击切换页面 · 双击展开图层'
            : '尚未绑定真实入口';
      const main = document.createElement('button');
      main.type = 'button';
      main.className = 'page-directory-main';
      main.disabled = Boolean(pageDirectoryLoadingKey && !loading);
      main.innerHTML = `<span class="page-directory-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M6 3.5h9l3 3V20.5H6z"/><path d="M15 3.5v4h4M9 12h6M9 16h6"/></svg></span><span class="page-directory-copy"><strong>${escapePageLabel(entry.label)}</strong><small>${stateLabel}</small></span>`;
      main.title = currentPage
        ? `${entry.label}是当前页面；双击可原位展开图层`
        : entry.bound
          ? `切换到 ${entry.label}；保持当前画布缩放与位置`
          : `${entry.label} · 尚未绑定页面`;
      const disclosure = document.createElement('button');
      disclosure.type = 'button';
      disclosure.className = 'page-directory-disclosure';
      disclosure.disabled = Boolean(pageDirectoryLoadingKey && !loading);
      disclosure.setAttribute('aria-label', `${expanded ? '收起' : '展开'} ${entry.label} 的 ${countLabel}`);
      disclosure.setAttribute('aria-expanded', String(expanded));
      disclosure.innerHTML = `<span class="page-directory-count">${countLabel}</span><span class="page-directory-chevron" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m9 5 7 7-7 7"/></svg></span>`;
      main.addEventListener('click', () => {
        if (pageDirectoryLoadingKey) return;
        if (!entry.bound) { showToast(`${entry.label}尚未绑定页面`); return; }
        activatePageRoute(entry, { fromDirectory:true, expand:false });
      });
      main.addEventListener('dblclick', (event) => {
        event.preventDefault();
        if (!entry.bound) return;
        if (pageDirectoryLoadingKey === entry.key) {
          pendingPageExpansionKey = entry.key;
          return;
        }
        if (pageDirectoryLoadingKey) return;
        activatePageRoute(entry, { fromDirectory:true, expand:true });
      });
      disclosure.addEventListener('click', (event) => {
        event.stopPropagation();
        if (pageDirectoryLoadingKey) return;
        if (!entry.bound) { showToast(`${entry.label}尚未绑定页面`); return; }
        if (expanded) {
          savePageWorkspace(entry.key);
          setExpandedPageKey('');
          clearPageNavigationSelection();
          renderLayers($('#layer-search').value);
          showToast(`已收起 ${entry.label} 的图层`);
          return;
        }
        activatePageRoute(entry, { fromDirectory:true, expand:true });
      });
      row.append(main, disclosure);
      branch.append(row);
      const layerSlot = document.createElement('div');
      layerSlot.className = 'page-directory-layers';
      layerSlot.dataset.pageLayerSlot = entry.key;
      layerSlot.hidden = !expanded;
      branch.append(layerSlot);
      const children = childrenByParent.get(entry.key) || [];
      if (children.length) {
        const childGroup = document.createElement('div');
        childGroup.className = 'page-directory-children';
        childGroup.setAttribute('role', 'group');
        children.forEach((child) => appendEntry(child, depth + 1, childGroup));
        branch.append(childGroup);
      }
      parent.append(branch);
    };
    (childrenByParent.get('') || []).forEach((entry) => appendEntry(entry));
    directory.replaceChildren(fragment);
    const expandedEntry = uniqueEntries.find((entry) => entry.active && entry.key === expandedPageKey);
    const expandedSlot = expandedEntry ? directory.querySelector(`[data-page-layer-slot="${CSS.escape(expandedEntry.key)}"]`) : null;
    if (expandedSlot && layerTree) {
      expandedSlot.hidden = false;
      expandedSlot.append(layerTree);
      layerTree.hidden = false;
      pageDirectoryOpen = false;
    } else {
      if (expandedPageKey && !uniqueEntries.some((entry) => entry.key === expandedPageKey)) setExpandedPageKey('');
      if (layerTree) {
        directory.after(layerTree);
        layerTree.hidden = true;
      }
      pageDirectoryOpen = true;
    }
    return !expandedSlot;
  }

  function syncActivePageContext(force = false) {
    if (!frameDocument) return;
    const entries = discoveredPageEntries();
    syncActivePageLayerCount(entries);
    const pendingEntry = pageDirectoryLoadingKey
      ? entries.find((entry) => entry.key === pageDirectoryLoadingKey)
      : null;
    if (!force && pendingEntry?.kind === 'action') {
      renderLayers($('#layer-search').value);
      return;
    }
    if (!force && activeTransientMenuKey && !pageDirectoryOpen) {
      renderLayers($('#layer-search').value);
      return;
    }
    const active = activePageEntry(entries);
    const nextKey = active?.key || `document:${frame.contentWindow.location.pathname}${frame.contentWindow.location.search}`;
    if (!force && nextKey === activePageIdentity) {
      renderLayers($('#layer-search').value);
      return;
    }
    const completedDirectoryActivation = Boolean(pageDirectoryLoadingKey && pageDirectoryLoadingKey === nextKey);
    if (completedDirectoryActivation) {
      clearTimeout(pageDirectoryActivationTimer);
      pageDirectoryLoadingKey = '';
      setExpandedPageKey(pendingPageExpansionKey === nextKey ? nextKey : '');
      pendingPageExpansionKey = '';
    }
    activePageIdentity = nextKey;
    buildLayers();
    entries.forEach((entry) => collapsedNodes.add(entry.id));
    if (active) collapsedNodes.delete(active.id);
    localStorage.setItem(TREE_STATE_KEY, JSON.stringify([...collapsedNodes]));
    if (!expandedPageKey) {
      clearPageNavigationSelection();
      renderLayers($('#layer-search').value);
    } else {
      restorePageWorkspace(nextKey, pageEntryRootIds(active));
    }
  }

  function schedulePageContextRefresh() {
    clearTimeout(pageRefreshTimer);
    pageRefreshTimer = setTimeout(() => syncActivePageContext(false), 32);
  }

  function installPageContextObserver() {
    pageMutationObserver?.disconnect();
    pageMutationObserver = new MutationObserver((records) => {
      const relevant = records.some((record) => {
        if (record.type === 'attributes') return Boolean(
          record.target === frameDocument.body
          || record.target.matches?.('[data-view],[data-view-target],[data-action]')
        );
        return [...record.addedNodes, ...record.removedNodes].some((node) =>
          node.nodeType === 1 && (node.matches?.('[data-ui-id]') || node.querySelector?.('[data-ui-id]'))
        );
      });
      if (relevant) schedulePageContextRefresh();
    });
    pageMutationObserver.observe(frameDocument.documentElement, {
      subtree:true,
      childList:true,
      attributes:true,
      attributeFilter:['hidden','aria-current','aria-pressed','data-active','data-current-view','class'],
    });
  }

  function activatePageRoute(route, options = {}) {
    const entries = discoveredPageEntries();
    const latest = entries.find((entry) => entry.key === route?.key || entry.id === route?.id) || route;
    if (!latest?.bound) {
      pageDirectoryLoadingKey = '';
      showToast(`${latest?.label || '该菜单'}尚未绑定可进入的页面`);
      return false;
    }
    const fromDirectory = Boolean(options.fromDirectory || pageDirectoryOpen);
    const shouldExpand = options.expand === true;
    const current = activePageEntry(entries);
    if (current?.key === latest.key) {
      pageDirectoryLoadingKey = '';
      pendingPageExpansionKey = '';
      if (shouldExpand) {
        setExpandedPageKey(latest.key);
        collapsedNodes.delete(latest.id);
        restorePageWorkspace(latest.key, pageEntryRootIds(latest));
        showToast(`已在菜单下展开 ${latest.label} 的真实图层`);
      } else {
        renderLayers($('#layer-search').value);
        showToast(`${latest.label} 已是当前页面；双击或点击层数可展开图层`);
      }
      return true;
    }
    if (!fromDirectory) savePageWorkspace(activePageIdentity || current?.key);
    if (options.remember !== false && current?.key && current.key !== latest.key) {
    }
    const trigger = frameDocument.querySelector(`[data-ui-id="${CSS.escape(latest.triggerId || latest.id)}"]`);
    if (!trigger) {
      pageDirectoryLoadingKey = '';
      showToast(`${latest.label}的菜单入口已失效，请重新载入预览`);
      return false;
    }
    pageDirectoryLoadingKey = latest.key;
    pendingPageExpansionKey = shouldExpand ? latest.key : '';
    activeTransientMenuKey = '';
    setExpandedPageKey('');
    clearPageNavigationSelection();
    renderLayers($('#layer-search').value);
    allowBoundPageAction = true;
    try { trigger.click(); }
    finally { allowBoundPageAction = false; }
    if (latest.kind === 'action') {
      clearTimeout(pageDirectoryActivationTimer);
      pageDirectoryActivationTimer = setTimeout(() => {
        if (pageDirectoryLoadingKey !== latest.key) return;
        pageDirectoryLoadingKey = '';
        activeTransientMenuKey = latest.key;
        activePageIdentity = latest.key;
        setExpandedPageKey(pendingPageExpansionKey === latest.key ? latest.key : '');
        pendingPageExpansionKey = '';
        buildLayers();
        if (expandedPageKey) restorePageWorkspace(latest.key, pageEntryRootIds(latest));
        else renderLayers($('#layer-search').value);
        showToast(shouldExpand ? `已执行 ${latest.label} · 图层已在菜单下展开` : `已执行 ${latest.label} · 当前 UI 已同步`);
      }, 96);
      showToast(`正在执行 ${latest.label} · 等待界面稳定`);
      return true;
    }
    schedulePageContextRefresh();
    setTimeout(schedulePageContextRefresh, 140);
    clearTimeout(pageDirectoryActivationTimer);
    pageDirectoryActivationTimer = setTimeout(() => {
      if (pageDirectoryLoadingKey !== latest.key) return;
      const activeNow = activePageEntry();
      if (activeNow?.key === latest.key) {
        syncActivePageContext(false);
        return;
      }
      pageDirectoryLoadingKey = '';
      pendingPageExpansionKey = '';
      setExpandedPageKey('');
      renderLayers($('#layer-search').value);
      showToast(`${latest.label}没有完成切换，请检查该菜单的页面绑定`);
    }, 1200);
    showToast(shouldExpand ? `正在切换 ${latest.label} · 完成后原位展开图层` : `正在切换 ${latest.label} · 画布位置保持不变`);
    return true;
  }

  function loadJSON(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); }
    catch { return fallback; }
  }

  function hasProjectDraftData() {
    return [STORAGE_KEY, ICONS_KEY, STRUCTURE_KEY, LAYER_META_KEY].some((key) => localStorage.getItem(key) !== null);
  }

  function draftStateMatchesDocument(document) {
    return JSON.stringify(overrides) === JSON.stringify(document?.overrides || {})
      && JSON.stringify(iconReplacements) === JSON.stringify(document?.iconReplacements || {})
      && JSON.stringify(structuralEdits) === JSON.stringify(document?.structuralEdits || { insertions:[] })
      && JSON.stringify(layerMetadata) === JSON.stringify(document?.layerMetadata || {});
  }

  function draftMetaMatchesProject(meta, document, status) {
    if (!meta || Number(meta.schemaVersion) !== DRAFT_SCHEMA_VERSION) return false;
    if (meta.documentId !== document?.documentId) return false;
    if (status?.projectId && meta.projectId !== status.projectId) return false;
    if (Number(meta.baseRevision) !== Number(document?.revision || 0)) return false;
    return !status?.currentSourceHash || meta.baseSourceHash === status.currentSourceHash;
  }

  function updateRecoveryActions() {
    const actions = document.querySelector('#sync-recovery-actions');
    if (!actions) return;
    const recovery = loadJSON(RECOVERY_DRAFT_KEY, null);
    actions.hidden = !recovery || (syncDocument?.documentId && recovery.documentId !== syncDocument.documentId);
  }

  function isolateCurrentDraft(meta, reason) {
    localStorage.setItem(RECOVERY_DRAFT_KEY, JSON.stringify({
      schemaVersion:DRAFT_SCHEMA_VERSION,
      projectId:meta?.projectId || syncStatus?.projectId || null,
      documentId:meta?.documentId || syncDocument?.documentId || null,
      baseRevision:Number(meta?.baseRevision || 0),
      baseSourceHash:meta?.baseSourceHash || '',
      clientId:meta?.clientId || CLIENT_ID,
      isolatedAt:new Date().toISOString(),
      reason,
      snapshot:snapshotState(),
    }));
    updateRecoveryActions();
  }

  function restoreIsolatedDraft() {
    const recovery = loadJSON(RECOVERY_DRAFT_KEY, null);
    if (!recovery?.snapshot || recovery.documentId !== syncDocument?.documentId) return false;
    const projectBaseline = snapshotState();
    commandHistory.reset(projectBaseline, '当前项目修订');
    restore(recovery.snapshot, { markDirty:false });
    commit({ label:'恢复隔离草稿', type:'draft.restore', targetIds:[], detail:{ fromRevision:recovery.baseRevision, clientId:recovery.clientId } });
    localStorage.removeItem(RECOVERY_DRAFT_KEY);
    updateRecoveryActions();
    showToast('隔离草稿已恢复为未保存修改；保存后才会写入项目');
    return true;
  }

  function discardIsolatedDraft() {
    localStorage.removeItem(RECOVERY_DRAFT_KEY);
    updateRecoveryActions();
    showToast('隔离草稿已丢弃；项目修订未受影响');
  }

  function checkStudioBuild(status) {
    const banner = document.querySelector('#studio-update-banner');
    const serverVersion = status?.studioBuildVersion;
    if (!banner || !serverVersion || serverVersion === CANVAS_CORE_VERSION) {
      if (banner) banner.hidden = true;
      return true;
    }
    banner.hidden = false;
    const detail = document.querySelector('#studio-update-detail');
    if (detail) detail.textContent = `当前 ${CANVAS_CORE_VERSION}，项目服务已更新为 ${serverVersion}。重新载入前会保留本地草稿。`;
    return false;
  }

  function snapshotState() {
    return {
      overrides: clone(overrides),
      icons: clone(iconReplacements),
      locks: [...locks],
      guides: clone(guides),
      structure: clone(structuralEdits),
      layerMetadata: clone(layerMetadata),
    };
  }

  const PROPERTY_HISTORY_LABELS = {
    x:'调整水平位置', y:'调整垂直位置', width:'调整宽度', height:'调整高度', scale:'调整比例', rotation:'调整旋转',
    backgroundColor:'调整背景颜色', color:'调整前景颜色', fontSize:'调整字号', fontFamily:'更换字体', fontWeight:'调整字重',
    lineHeight:'调整行高', letterSpacing:'调整字距', textAlign:'调整文字对齐', borderRadius:'调整圆角', borderWidth:'调整描边',
    borderColor:'调整描边颜色', borderStyle:'调整描边样式', opacity:'调整透明度', padding:'调整内边距', textContent:'编辑文字',
    shadowX:'调整阴影位置', shadowY:'调整阴影位置', shadowBlur:'调整阴影模糊', shadowSpread:'调整阴影扩展', shadowColor:'调整阴影颜色',
  };

  function renderStatusBar() {
    const statusMode = $('#status-mode');
    if (!statusMode) return;
    const featureLabel = FEATURE_META[activeFeature]?.title || '页面结构';
    statusMode.textContent = handToolEnabled || spacePanPressed ? '手型平移' : activeFeature === 'layers' ? '选择编辑' : featureLabel;
    $('#status-selection').textContent = hasMultiSelection()
      ? `已选择 ${activeSelectionIds().length} 个对象`
      : selectedId ? selectionBreadcrumb(selectedId) : '未选择对象';
    const rect = selectedId ? selectionUnionRect() : null;
    $('#status-geometry').textContent = rect
      ? `X ${Math.round(rect.left)} · Y ${Math.round(rect.top)} · ${Math.round(rect.width)} × ${Math.round(rect.height)}`
      : '位置与尺寸 —';
    $('#status-snap').textContent = snapEnabled ? (lastSnapStatus || '精细吸附 3–4px · Alt 绕过') : '吸附关闭';
    $('#status-viewport').textContent = `${viewport.width} × ${viewport.height} · ${Math.round(zoom * 100)}%`;
    $('#status-history').textContent = commandHistory.currentLabel() === '打开项目' ? '尚无编辑操作' : `最近：${commandHistory.currentLabel()}`;
    const syncDisplay = syncDisplayState();
    const revision = syncStatus?.documentRevision || syncDocument?.revision || 0;
    const syncElement = $('#status-sync');
    syncElement.textContent = `${syncDisplay.label}${revision ? ` · r${revision}` : ''}`;
    syncElement.dataset.state = syncDisplay.key;
    $('#empty-node-count').textContent = nodes.length ? `${nodes.length} 层` : '载入中';
    const emptyPageName = $('#empty-page-name');
    if (emptyPageName) emptyPageName.textContent = currentPageContext().label;
    $('#empty-viewport-size').textContent = `${viewport.width} × ${viewport.height}`;
    $('#empty-sync-state').textContent = syncDisplay.label;
  }

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove('show'), 1700);
  }

  window.addEventListener('ui-analysis-generated', (event) => {
    const accepted = Number(event.detail?.accepted || 0);
    const unresolved = Number(event.detail?.unresolved || 0);
    showToast(`已生成 ${accepted} 个 UI 文档图层${unresolved ? ` · ${unresolved} 个候选仍待确认` : ''}；等待 Codex 转成生产代码`);
  });

  function localChangeSummary(document = { overrides, iconReplacements, structuralEdits, layerMetadata }) {
    const entries = Object.entries(document.overrides || {}).filter(([, value]) => value && Object.keys(value).length);
    const text = entries.filter(([, value]) => Object.prototype.hasOwnProperty.call(value, 'textContent')).length;
    const styles = entries.filter(([, value]) => Object.keys(value).some((key) => key !== 'textContent')).length;
    const icons = Object.keys(document.iconReplacements || {}).length;
    const insertions = document.structuralEdits?.insertions?.length || 0;
    const paths = [];
    entries.forEach(([id, values]) => Object.keys(values).forEach((key) => paths.push({ type:key === 'textContent' ? 'T' : 'S', id, key, value:values[key] })));
    Object.entries(document.iconReplacements || {}).forEach(([id, value]) => paths.push({ type:'I', id, key:'icon', value:value.name || 'custom SVG' }));
    (document.structuralEdits?.insertions || []).forEach((entry) => paths.push({ type:'N', id:entry.id, key:'duplicate', value:entry.sourceId }));
    Object.entries(document.layerMetadata || {}).forEach(([id, metadata]) => paths.push({ type:'M', id, key:'name', value:metadata.name }));
    return { nodes:entries.length, text, styles, icons, insertions, paths };
  }

  function syncDisplayState() {
    if (!syncStatus?.connected) return { key:'offline', label:'仅本机草稿', title:'同步桥未连接', detail:'请在项目目录运行 npm start，再通过该地址打开 Studio。' };
    if (studioDirty) return { key:'draft', label:'未保存', title:'Studio 有未保存修改', detail:'点击“保存到项目”生成新的项目修订，Codex 才能读取。' };
    const states = {
      clean:{ key:'clean', label:'已同步', title:'Studio 与源码一致', detail:'可以继续编辑；修改后保存到项目即可交给 Codex。' },
      'pending-codex':syncStatus.previewIsCurrent
        ? { key:'pending', label:'页面已更新', title:'实际项目已刷新 · 等待 Codex 固化', detail:'安全参数补丁已经写入实际项目；Codex 将同一修订吸收到正式源码。' }
        : { key:'pending', label:'待 Codex', title:'修订已保存但预览补丁未应用', detail:'请检查元素身份或让 Codex 运行 npm run sync:apply。' },
      'source-ahead':{ key:'ahead', label:'Codex 有更新', title:'Codex 源码领先', detail:'点击“拉取 Codex 最新版”重新载入源码，不会静默覆盖 Studio 草稿。' },
      conflict:{ key:'conflict', label:'有冲突', title:'两边同时发生修改', detail:'暂停自动覆盖，请查看差异后选择保留方向。' },
    };
    return states[syncStatus.state] || states.clean;
  }

  function setDeliveryStep(name, state, detail, revision) {
    const step = $(`[data-delivery-step="${name}"]`);
    if (!step) return;
    step.dataset.state = state;
    const detailElement = $(`#delivery-${name === 'verify' ? 'verify' : name}-detail`);
    const revisionElement = name === 'verify' ? $('#delivery-gate-score') : $(`#delivery-${name}-revision`);
    if (detailElement) detailElement.textContent = detail;
    if (revisionElement) revisionElement.textContent = revision;
  }

  function renderDeliveryStatus() {
    if (!$('#delivery-workflow')) return;
    const documentRevision = Number(syncStatus?.documentRevision || syncDocument?.revision || 0);
    const appliedRevision = Number(syncStatus?.appliedRevision || 0);
    const handoffRevision = Number(syncStatus?.handoffRevision || 0);
    const gate = syncStatus?.qualityGate || null;
    const connected = Boolean(syncStatus?.connected);

    if (!connected) setDeliveryStep('document', 'warning', '同步桥未连接，仅保留本机草稿', '离线');
    else if (studioDirty) setDeliveryStep('document', 'active', '有未保存修改，保存后生成新修订', `r${documentRevision} +`);
    else setDeliveryStep('document', 'complete', '当前 Studio 文档已写入项目', `r${documentRevision}`);

    if (!connected || !documentRevision) setDeliveryStep('codex', 'waiting', '保存项目后可交给 Codex', '—');
    else if (appliedRevision >= documentRevision) setDeliveryStep('codex', 'complete', 'Codex 已吸收到正式源码', `r${appliedRevision}`);
    else if (handoffRevision === documentRevision || syncStatus?.state === 'pending-codex') setDeliveryStep('codex', 'active', '接手说明已就绪，等待源码应用', `r${documentRevision}`);
    else setDeliveryStep('codex', 'waiting', '点击“交给 Codex”建立明确接手记录', `r${documentRevision}`);

    if (syncStatus?.state === 'conflict') setDeliveryStep('source', 'error', '源码与 Studio 同时变化，需要先解决冲突', '冲突');
    else if (syncStatus?.state === 'source-ahead') setDeliveryStep('source', 'warning', 'Codex 源码领先，请先拉取最新版', `r${appliedRevision}`);
    else if (appliedRevision >= documentRevision && documentRevision > 0) setDeliveryStep('source', 'complete', '正式项目文件与当前修订一致', `r${appliedRevision}`);
    else if (syncStatus?.previewIsCurrent) setDeliveryStep('source', 'active', '实际预览已更新，等待 Codex 固化源码', `预览 r${syncStatus.previewRevision}`);
    else setDeliveryStep('source', 'waiting', '尚未应用到正式项目文件', `r${appliedRevision}`);

    const gateCurrent = gate && Number(gate.revision) === appliedRevision && gate.sourceHash === syncStatus?.currentPreviewSourceHash;
    const gateScore = gate?.score ?? gate?.provisionalScore;
    if (!gate) setDeliveryStep('verify', 'waiting', '用真实浏览器截图完成 8 项验收', '待校验');
    else if (!gateCurrent) setDeliveryStep('verify', 'warning', '校验属于旧修订，源码更新后需要重跑', '已过期');
    else if (gate.passed) setDeliveryStep('verify', 'complete', '真实浏览器证据已达到交付门槛', `${Number(gate.score).toFixed(2)}%`);
    else if (gate.complete) setDeliveryStep('verify', 'error', gate.proofKind === 'browser-capture' ? '8 项已评分，但尚未达到 95%' : '诊断证据不能作为项目验收', `${Number(gateScore || 0).toFixed(2)}%`);
    else setDeliveryStep('verify', 'active', `已覆盖 ${Number(gate.coverage || 0)}%，继续完成评分`, gateScore == null ? '待评分' : `暂估 ${Number(gateScore).toFixed(2)}%`);

    const saveButton = $('#delivery-save-project');
    if (saveButton) {
      saveButton.querySelector('b').textContent = studioDirty ? '保存到项目 · 有修改' : '保存到项目';
      saveButton.disabled = !connected && !studioDirty;
    }
    const handoffButton = $('#delivery-handoff-codex');
    if (handoffButton) handoffButton.disabled = !connected || (!studioDirty && !documentRevision);
  }

  function renderSyncStatus() {
    const display = syncDisplayState();
    const dot = $('#sync-dot');
    dot.className = `sync-dot ${display.key}`;
    $('#sync-status-label').textContent = display.label;
    $('#sync-revision').textContent = `r${syncStatus?.documentRevision || syncDocument?.revision || 0}`;
    $('#sync-state-title').textContent = display.title;
    $('#sync-state-detail').textContent = display.detail;
    $('#sync-document-revision').textContent = `r${syncStatus?.documentRevision || syncDocument?.revision || 0}`;
    $('#sync-preview-revision').textContent = `r${syncStatus?.previewRevision || 0}`;
    $('#sync-applied-revision').textContent = `r${syncStatus?.appliedRevision || 0}`;
    $('#save').classList.toggle('has-draft', studioDirty);
    $('#save').textContent = studioDirty ? '保存到项目 ·' : '保存到项目';
    renderDeliveryStatus();
    renderStatusBar();
  }

  function markStudioDirty() {
    if (studioDirty) return;
    studioDirty = true;
    renderSyncStatus();
  }

  async function syncRequest(pathname, options = {}) {
    const response = await fetch(`${SYNC_API}${pathname}`, {
      cache:'no-store',
      headers:{ 'Content-Type':'application/json', ...(options.headers || {}) },
      ...options,
    });
    let data = {};
    try { data = await response.json(); } catch {}
    if (!response.ok) {
      const error = new Error(data.message || `同步请求失败 (${response.status})`);
      error.status = response.status;
      error.data = data;
      throw error;
    }
    return data;
  }

  function buildProjectDocument() {
    return {
      ...(syncDocument ? clone(syncDocument) : {
        source:{ references:[] }, tokens:{ color:{}, space:{}, radius:{}, type:{} }, components:{}, assets:{ icons:{} },
        breakpoints:{ desktop:{ minWidth:1200 }, tablet:{ minWidth:768, maxWidth:1199 }, mobile:{ maxWidth:767 } },
        nodes:[], evidence:{ activeRunId:null, runs:[], items:{} }, manualQueue:[], operations:[],
      }),
      protocolVersion:1,
      version:4,
      documentId:syncDocument?.documentId || 'tudoodoo-ai-studio',
      revision:syncDocument?.revision || 0,
      baseSourceHash:syncStatus?.currentSourceHash || syncDocument?.baseSourceHash || '',
      canvas:{ width:viewport.width, height:viewport.height },
      overrides:clone(overrides),
      iconReplacements:clone(iconReplacements),
      structuralEdits:clone(structuralEdits),
      layerMetadata:clone(layerMetadata),
      updatedAt:new Date().toISOString(),
      updatedBy:'studio',
    };
  }

  function saveLocalDraft() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(overrides));
    localStorage.setItem(ICONS_KEY, JSON.stringify(iconReplacements));
    localStorage.setItem(LOCKS_KEY, JSON.stringify([...locks]));
    localStorage.setItem(STRUCTURE_KEY, JSON.stringify(structuralEdits));
    localStorage.setItem(LAYER_META_KEY, JSON.stringify(layerMetadata));
    if (layerClipboard) localStorage.setItem(CLIPBOARD_KEY, JSON.stringify(layerClipboard));
    localStorage.setItem(DRAFT_META_KEY, JSON.stringify({
      schemaVersion:DRAFT_SCHEMA_VERSION,
      projectId:syncStatus?.projectId || null,
      documentId:syncDocument?.documentId || null,
      baseRevision:Number(syncDocument?.revision || 0),
      baseSourceHash:syncStatus?.currentSourceHash || syncDocument?.baseSourceHash || '',
      clientId:CLIENT_ID,
      studioBuildVersion:CANVAS_CORE_VERSION,
      updatedAt:new Date().toISOString(),
    }));
  }

  function applyProjectDocument(document, reloadFrame = true) {
    syncDocument = clone(document);
    overrides = clone(document.overrides || {});
    iconReplacements = clone(document.iconReplacements || {});
    structuralEdits = clone(document.structuralEdits || { insertions:[] });
    layerMetadata = clone(document.layerMetadata || {});
    viewport = { width:Number(document.canvas?.width || 1920), height:Number(document.canvas?.height || 919) };
    studioDirty = false;
    commandHistory.reset(snapshotState(), '打开项目');
    saveLocalDraft();
    updateHistoryButtons();
    if (reloadFrame) {
      selectedId = null;
      frame.src = `index.html?editor=1&render=parity&sync=${Date.now()}`;
    } else applyAll();
    renderSyncStatus();
  }

  async function refreshProjectSync({ initial = false, silent = true } = {}) {
    try {
      const status = await syncRequest('/status');
      const priorHash = syncStatus?.currentSourceHash;
      syncStatus = status;
      checkStudioBuild(status);
      if (initial) {
        const payload = await syncRequest('/document');
        syncDocument = payload.document;
        const hasLocalDraft = hasProjectDraftData();
        const sameDraft = draftStateMatchesDocument(syncDocument);
        const draftMeta = loadJSON(DRAFT_META_KEY, null);
        if (!hasLocalDraft || sameDraft) {
          applyProjectDocument(syncDocument, false);
        } else if (draftMetaMatchesProject(draftMeta, syncDocument, status)) {
          const localState = snapshotState();
          const projectState = {
            ...localState,
            overrides:clone(syncDocument.overrides || {}),
            icons:clone(syncDocument.iconReplacements || {}),
            structure:clone(syncDocument.structuralEdits || { insertions:[] }),
            layerMetadata:clone(syncDocument.layerMetadata || {}),
          };
          commandHistory.reset(projectState, '项目修订');
          commandHistory.commit(localState, { label:'恢复本地草稿', type:'draft.resume', targetIds:[], detail:{ baseRevision:draftMeta.baseRevision, clientId:draftMeta.clientId } });
          studioDirty = commandHistory.state().dirty;
          updateHistoryButtons();
        } else {
          isolateCurrentDraft(draftMeta, 'project-or-revision-mismatch');
          applyProjectDocument(syncDocument, false);
          showToast('检测到其他项目、旧修订或旧标签草稿，已安全隔离；可在同步菜单中恢复');
        }
        updateRecoveryActions();
      } else if (priorHash && priorHash !== status.currentSourceHash && status.state === 'source-ahead' && !silent) {
        showToast('检测到 Codex 源码更新，请拉取最新版');
      }
      renderSyncStatus();
      return status;
    } catch (error) {
      syncStatus = null;
      renderSyncStatus();
      if (!silent) showToast('同步桥未连接；当前修改只保存在本机草稿');
      return null;
    }
  }

  async function saveProject() {
    saveLocalDraft();
    const button = $('#save');
    button.disabled = true;
    try {
      if (!syncStatus?.connected || !syncDocument) await refreshProjectSync({ initial:!syncDocument, silent:false });
      if (!syncStatus?.connected || !syncDocument) throw new Error('同步桥未连接');
      const payload = await syncRequest('/document', {
        method:'PUT',
        body:JSON.stringify({
          expectedRevision:syncDocument.revision,
          document:buildProjectDocument(),
          operations:commandHistory.operations(),
        }),
      });
      syncDocument = payload.document;
      syncStatus = payload.status;
      studioDirty = false;
      commandHistory.markSaved();
      saveLocalDraft();
      renderSyncStatus();
      const live = syncStatus.previewIsCurrent ? '实际页面已更新' : '等待预览应用';
      showToast(`已保存 r${syncDocument.revision} · ${live} · 待 Codex 固化`);
      return true;
    } catch (error) {
      if (error.data?.status) syncStatus = error.data.status;
      renderSyncStatus();
      showSyncDiff(error.message);
      showToast(error.status === 409 ? '发现同步冲突，未覆盖项目文件' : '已保存本机草稿；项目同步失败');
      return false;
    } finally { button.disabled = false; }
  }

  async function pullCodexLatest() {
    if (studioDirty) {
      showSyncDiff('Studio 还有未保存修改。请先保存并交给 Codex，或撤销这些修改，再拉取源码。');
      return false;
    }
    try {
      const status = await refreshProjectSync({ silent:false });
      if (!status) return false;
      if (status.state === 'conflict') { showSyncDiff('Studio 修订与源码同时变化，不能直接覆盖。请先让 Codex 检查 .ui-studio 文件。'); return false; }
      if (status.state === 'source-ahead') {
        const acknowledged = await syncRequest('/reload-source', { method:'POST', body:'{}' });
        syncStatus = acknowledged.status;
      }
      const payload = await syncRequest('/document');
      syncStatus = payload.status;
      applyProjectDocument(payload.document, true);
      showToast(`已拉取 Codex 最新版 · r${payload.document.revision}`);
      return true;
    } catch (error) {
      if (error.data?.status) syncStatus = error.data.status;
      renderSyncStatus();
      showSyncDiff(error.message);
      return false;
    }
  }

  function copyText(text) {
    if (navigator.clipboard?.writeText) return navigator.clipboard.writeText(text);
    const input = document.createElement('textarea');
    input.value = text; input.style.position = 'fixed'; input.style.opacity = '0';
    document.body.appendChild(input); input.select(); document.execCommand('copy'); input.remove();
    return Promise.resolve();
  }

  async function handoffToCodex() {
    if (studioDirty && !(await saveProject())) return;
    if (!syncDocument) { showToast('没有可交接的项目修订'); return; }
    try {
      const handoff = await syncRequest('/handoff', { method:'POST', body:JSON.stringify({ expectedRevision:syncDocument.revision }) });
      syncStatus = { ...syncStatus, handoffStatus:handoff.status, handoffRevision:handoff.revision };
      await copyText(handoff.prompt);
      showToast(`修订 r${handoff.revision} 已交给 Codex；接手说明已复制`);
      renderSyncStatus();
    } catch (error) { showToast(error.message || '交接失败'); }
  }

  async function loadSyncHistory() {
    const select = $('#sync-history-select');
    const restore = $('#sync-restore');
    try {
      const history = await syncRequest('/history');
      select.replaceChildren(new Option(`当前修订 r${history.current.revision}`, ''));
      const seen = new Set();
      history.archived.forEach((item) => {
        if (seen.has(item.revision)) return;
        seen.add(item.revision);
        const time = item.updatedAt ? new Date(item.updatedAt).toLocaleString('zh-CN', { hour12:false }) : '历史记录';
        select.add(new Option(`r${item.revision} · ${time}`, String(item.revision)));
      });
      restore.disabled = true;
    } catch (error) {
      select.replaceChildren(new Option('历史不可用', ''));
      restore.disabled = true;
    }
  }

  async function restoreSyncHistory() {
    const select = $('#sync-history-select');
    const targetRevision = Number(select.value);
    if (!Number.isInteger(targetRevision) || !syncDocument) return;
    if (studioDirty) { showSyncDiff('当前还有未保存修改。请先保存或撤销，再恢复历史修订。'); return; }
    try {
      const result = await syncRequest('/rollback', {
        method:'POST',
        body:JSON.stringify({ expectedRevision:syncDocument.revision, targetRevision }),
      });
      syncStatus = result.status;
      applyProjectDocument(result.document, true);
      showToast(`已将 r${targetRevision} 恢复为新修订 r${result.document.revision}；交给 Codex 后更新真实项目`);
      await loadSyncHistory();
    } catch (error) {
      if (error.data?.status) syncStatus = error.data.status;
      renderSyncStatus();
      showSyncDiff(error.message || '恢复历史修订失败');
    }
  }

  function openProjectPreview() {
    if (studioDirty) showToast('精准预览显示已应用源码；当前未保存调整尚未进入真实项目');
    else if (syncStatus?.state === 'pending-codex' && !syncStatus?.previewIsCurrent) showToast('预览补丁尚未应用；请检查身份映射或让 Codex 接管');
    const width = Math.max(320, Math.round(viewport.width || 1920));
    const height = Math.max(320, Math.round(viewport.height || 919));
    const appliedRevision = Number(syncStatus?.appliedRevision || 0);
    const previewRevision = Number(syncStatus?.previewRevision || 0);
    const revision = syncStatus?.previewIsCurrent ? previewRevision : (appliedRevision || previewRevision || syncDocument?.revision || 0);
    const url = `project-preview.html?width=${width}&height=${height}&embedded=1&revision=${revision}`;
    const dialog = $('#project-preview-dialog');
    $('#project-preview-frame').src = url;
    $('#project-preview-size').textContent = `${width} × ${height}`;
    $('#project-preview-revision').textContent = revision
      ? (previewRevision > appliedRevision && syncStatus?.previewIsCurrent ? `实际预览 r${previewRevision} · 正式源码 r${appliedRevision}` : `正式源码 r${revision}`)
      : '实际项目源码';
    if (!dialog.open) dialog.showModal();
  }

  function reloadProjectPreview() {
    const previewFrame = $('#project-preview-frame');
    if (!previewFrame?.src) return;
    const url = new URL(previewFrame.src, location.href);
    url.searchParams.set('reload', Date.now().toString(36));
    previewFrame.src = url.href;
  }

  function openProjectPreviewWindow() {
    const previewFrame = $('#project-preview-frame');
    const width = Math.max(320, Math.round(viewport.width || 1920));
    const height = Math.max(320, Math.round(viewport.height || 919));
    const url = previewFrame?.getAttribute('src') || `project-preview.html?width=${width}&height=${height}`;
    window.open(url, '_blank', 'noopener');
  }

  function openLiveProjectPreview() {
    if (studioDirty) showToast('实机预览显示已应用源码；未保存调整不会出现');
    window.open('index.html?preview=live&render=live', '_blank', 'noopener');
  }

  function showSyncDiff(alertMessage = '') {
    const draft = buildProjectDocument();
    const summary = localChangeSummary(draft);
    $('#sync-count-nodes').textContent = summary.nodes;
    $('#sync-count-text').textContent = summary.text;
    $('#sync-count-styles').textContent = summary.styles;
    $('#sync-count-icons').textContent = summary.icons;
    const alert = $('#sync-dialog-alert');
    alert.hidden = !alertMessage;
    alert.textContent = alertMessage;
    const list = $('#sync-change-list');
    list.replaceChildren(...summary.paths.map((change) => {
      const row = document.createElement('div');
      row.className = 'sync-change-row';
      const value = typeof change.value === 'string' ? change.value : JSON.stringify(change.value);
      row.innerHTML = `<i>${change.type}</i><span><b>${labelFor(change.id)}</b><small></small></span><code></code>`;
      $('small', row).textContent = `${change.id} · ${change.key}`;
      $('code', row).textContent = String(value).slice(0, 38);
      return row;
    }));
    const dialog = $('#sync-dialog');
    if (!dialog.open) dialog.showModal();
  }

  async function initializeProjectSync() {
    if (syncInitialized) return;
    syncInitialized = true;
    await refreshProjectSync({ initial:true, silent:true });
    syncPollTimer = window.setInterval(() => {
      if (document.visibilityState === 'visible') refreshProjectSync({ silent:true });
    }, 2500);
  }

  function cleanLayerText(value, limit = 42) {
    return String(value || '').replace(/\s+/g, ' ').trim().slice(0, limit);
  }
  function frameLanguage() {
    const declared = cleanLayerText(frameDocument?.documentElement?.lang, 12).toLowerCase();
    if (/^zh\b/.test(declared)) return 'zh';
    if (/^ja\b/.test(declared)) return 'ja';
    if (/^ko\b/.test(declared)) return 'ko';
    if (/^en\b/.test(declared)) return 'en';
    const sample = cleanLayerText(frameDocument?.body?.innerText, 6000);
    const kana = (sample.match(/[\u3040-\u30ff]/g) || []).length;
    const hangul = (sample.match(/[\uac00-\ud7af]/g) || []).length;
    const han = (sample.match(/[\u3400-\u9fff]/g) || []).length;
    const latin = (sample.match(/[A-Za-z]/g) || []).length;
    if (kana >= 2) return 'ja';
    if (hangul >= 2) return 'ko';
    if (han >= Math.max(3, latin * 0.12)) return 'zh';
    return 'en';
  }
  const GENERIC_LAYER_TOKENS = {
    page:['root','page','document','app'], header:['header','topbar'], footer:['footer','bottombar'],
    navigation:['nav','navigation','sidebar','aside','menu'], main:['main','content','workspace'],
    section:['section','container','wrapper','group','panel','card'], list:['list','table'], item:['item','row','column','cell'],
    icon:['icon','glyph','symbol','mark'], image:['image','img','picture','photo','avatar','logo'],
    text:['text','label','title','subtitle','caption','paragraph'], button:['button','action','control','link','tab'],
    input:['input','textarea','select','field','form'], divider:['divider','separator','line'], dialog:['dialog','modal','popover','tooltip'],
  };
  const LOCAL_LAYER_NAMES = {
    zh:{ page:'页面', header:'顶部栏', footer:'底部栏', navigation:'导航', main:'主内容', section:'区域', list:'列表', item:'列表项', icon:'图标', image:'图片', text:'文字', button:'按钮', input:'输入控件', divider:'分隔线', dialog:'对话框', layer:'图层' },
    ja:{ page:'ページ', header:'ヘッダー', footer:'フッター', navigation:'ナビゲーション', main:'メイン', section:'セクション', list:'リスト', item:'項目', icon:'アイコン', image:'画像', text:'テキスト', button:'ボタン', input:'入力', divider:'区切り線', dialog:'ダイアログ', layer:'レイヤー' },
    ko:{ page:'페이지', header:'헤더', footer:'푸터', navigation:'탐색', main:'주 콘텐츠', section:'영역', list:'목록', item:'항목', icon:'아이콘', image:'이미지', text:'텍스트', button:'버튼', input:'입력', divider:'구분선', dialog:'대화 상자', layer:'레이어' },
    en:{ page:'Page', header:'Header', footer:'Footer', navigation:'Navigation', main:'Main content', section:'Section', list:'List', item:'Item', icon:'Icon', image:'Image', text:'Text', button:'Button', input:'Input', divider:'Divider', dialog:'Dialog', layer:'Layer' },
  };
  function genericLayerKey(name, element) {
    const tag = element?.tagName?.toLowerCase() || '';
    const role = cleanLayerText(element?.getAttribute?.('role'), 24).toLowerCase();
    if (tag === 'svg' || role === 'img' && !element?.getAttribute?.('alt')) return 'icon';
    if (tag === 'img' || tag === 'picture' || tag === 'canvas') return 'image';
    if (/^h[1-6]$/.test(tag) || ['p','span','strong','small','label'].includes(tag)) return 'text';
    if (tag === 'button' || role === 'button' || tag === 'a') return 'button';
    if (['input','textarea','select','form'].includes(tag)) return 'input';
    if (['header','footer','main','nav','aside','section','dialog'].includes(tag)) return tag === 'nav' || tag === 'aside' ? 'navigation' : tag;
    const normalized = cleanLayerText(name, 80).replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase().replace(/[^a-z]+/g, ' ').trim();
    for (const [key, tokens] of Object.entries(GENERIC_LAYER_TOKENS)) {
      if (tokens.some((token) => normalized.split(' ').includes(token))) return key;
    }
    return 'layer';
  }
  function localizedLayerKind(key, language = frameLanguage()) {
    return (LOCAL_LAYER_NAMES[language] || LOCAL_LAYER_NAMES.en)[key] || (LOCAL_LAYER_NAMES[language] || LOCAL_LAYER_NAMES.en).layer;
  }
  function directLayerText(element) {
    return cleanLayerText([...(element?.childNodes || [])]
      .filter((node) => node.nodeType === 3)
      .map((node) => node.textContent)
      .filter(Boolean)
      .join(' '));
  }
  function attributeLayerText(element) {
    for (const attribute of ['aria-label','alt','title','placeholder']) {
      const value = cleanLayerText(element?.getAttribute?.(attribute));
      if (value) return value;
    }
    return '';
  }
  function rawNameMatchesLanguage(value, language) {
    if (!value) return false;
    if (language === 'zh') return /[\u3400-\u9fff]/.test(value);
    if (language === 'ja') return /[\u3040-\u30ff]/.test(value);
    if (language === 'ko') return /[\uac00-\ud7af]/.test(value);
    return true;
  }
  function iconContextLabel(element, language) {
    if (genericLayerKey(element?.dataset?.uiName, element) !== 'icon') return '';
    const control = element?.closest?.('button,a,[role="button"],[role="menuitem"],label');
    if (!control || control === element) return '';
    const value = attributeLayerText(control) || cleanLayerText(control.innerText || control.textContent, 28);
    if (!value || genericLayerKey(value, null) !== 'layer') return '';
    const suffix = localizedLayerKind('icon', language);
    if (value.toLocaleLowerCase().endsWith(suffix.toLocaleLowerCase())) return value;
    return language === 'ko' || language === 'en' ? `${value} ${suffix}` : `${value}${suffix}`;
  }
  function describeLayer(element, suppliedDirectText = '', language = frameLanguage()) {
    const directText = cleanLayerText(suppliedDirectText || directLayerText(element));
    if (directText) return { label:directText, generic:false };
    const attributeText = attributeLayerText(element);
    if (attributeText && genericLayerKey(attributeText, null) === 'layer') return { label:attributeText, generic:false };
    const tag = element?.tagName?.toLowerCase() || '';
    const controlText = ['button','a'].includes(tag) || element?.getAttribute?.('role') === 'button'
      ? cleanLayerText(element.innerText || element.textContent, 36)
      : '';
    if (controlText) return { label:controlText, generic:false, kind:'button' };
    const contextualIcon = iconContextLabel(element, language);
    if (contextualIcon) return { label:contextualIcon, generic:false };
    const rawName = cleanLayerText(element?.dataset?.uiName);
    const key = genericLayerKey(rawName || element?.dataset?.uiId, element);
    if (rawName && key === 'layer' && rawNameMatchesLanguage(rawName, language)) return { label:rawName, generic:false };
    if (key === 'page') {
      const explicitPageName = cleanLayerText(frameDocument?.documentElement?.dataset.uiPageName || frameDocument?.body?.dataset.uiPageName || frameDocument?.title);
      if (explicitPageName) return { label:explicitPageName, generic:false, kind:key };
    }
    return { label:localizedLayerKind(key, language), generic:true, kind:key };
  }
  function labelFor(id) {
    if (!id) return '未选择对象';
    const built = nodes.find((node) => node.id === id)?.displayName;
    if (built) return built;
    const element = frameDocument?.querySelector(`[data-ui-id="${CSS.escape(id)}"]`);
    if (element) return describeLayer(element).label;
    return LABELS[id] || id.split('.').slice(-1)[0].replace(/(^\w|[-_]\w)/g, (value) => value.replace(/[-_]/, '').toUpperCase());
  }
  function selectedElement() { return selectedId && frameDocument ? frameDocument.querySelector(`[data-ui-id="${CSS.escape(selectedId)}"]`) : null; }
  function activeSelectionIds() {
    if (selectedIds.size) return [...selectedIds].filter((id) => nodes.some((node) => node.id === id));
    return selectedId ? [selectedId] : [];
  }
  function hasMultiSelection() { return activeSelectionIds().length > 1; }
  function selectedElements() {
    if (!frameDocument) return [];
    return activeSelectionIds().map((id) => ({ id, element:frameDocument.querySelector(`[data-ui-id="${CSS.escape(id)}"]`) })).filter((item) => item.element && overrides[item.id]?.display !== 'none');
  }
  function selectionUnionRect() {
    const entries = selectedElements().map((item) => ({ ...item, rect:item.element.getBoundingClientRect() }));
    if (!entries.length) return null;
    const left = Math.min(...entries.map((item) => item.rect.left));
    const top = Math.min(...entries.map((item) => item.rect.top));
    const right = Math.max(...entries.map((item) => item.rect.right));
    const bottom = Math.max(...entries.map((item) => item.rect.bottom));
    return { left, top, right, bottom, width:right - left, height:bottom - top, entries };
  }
  function isTextElement(element) {
    if (!element) return false;
    return ['span','strong','small','b','h1','h2','h3','h4','p','label','em','i','code'].includes(element.tagName.toLowerCase()) && element.children.length === 0;
  }
  function nodeMatchesFilter(node, filter) {
    if (filter === 'all') return true;
    if (filter === 'menu') return Boolean(node.route) || node.id === 'sidebar.navigation' || node.id.startsWith('sidebar.nav.');
    if (filter === 'visual') return ['svg','img','picture','canvas'].includes(node.tag) || /(icon|image|logo|mark)/i.test(node.id);
    const element = frameDocument?.querySelector(`[data-ui-id="${CSS.escape(node.id)}"]`);
    if (filter === 'text') return isTextElement(element);
    if (filter === 'frame') return !isTextElement(element) && node.tag !== 'svg' && ['aside','nav','main','section','article','form','button','input','textarea','select','div'].includes(node.tag);
    return false;
  }
  function scopedElement(element) {
    if (!element) return null;
    if (selectionScope === 'whole') return frameDocument.querySelector('[data-ui-id="app.shell"]') || frameDocument.querySelector('[data-ui-id]');
    if (selectionScope === 'section') {
      let cursor = element;
      const sectionTags = new Set(['nav','aside','header','footer','main','section','article','form']);
      while (cursor?.matches?.('[data-ui-id]')) {
        if (sectionTags.has(cursor.tagName.toLowerCase()) || descendantIds(cursor.dataset.uiId).size >= 1) return cursor;
        cursor = cursor.parentElement?.closest('[data-ui-id]');
      }
    }
    return element;
  }
  function refreshSelectionScope() {
    $$('[data-selection-scope]').forEach((button) => button.classList.toggle('active', button.dataset.selectionScope === selectionScope));
    const select = $('#selection-scope-select');
    if (select) select.value = selectionScope;
  }

  function selectionScopeNotice() {
    return selectionScope === 'whole' ? '整体选择：点击画布选择整个页面' : selectionScope === 'section' ? '区块选择：点击文字或图标会选择所属菜单或面板' : '单层选择：点击画布选择最细图层';
  }

  function applySelectionScope(nextScope) {
    selectionScope = nextScope;
    refreshSelectionScope();
    const target = scopedElement(selectedElement());
    if (target?.dataset.uiId) select(target.dataset.uiId);
    else if (selectionScope === 'whole') select('app.shell');
    showToast(selectionScopeNotice());
  }
  function number(value, fallback = 0) {
    const parsed = Number.parseFloat(value);
    if (Number.isFinite(parsed)) return parsed;
    const parsedFallback = Number.parseFloat(fallback);
    return Number.isFinite(parsedFallback) ? parsedFallback : 0;
  }
  function px(value) { return Math.round(number(value)); }

  const GEOMETRY_LIMITS = {
    x:[-1_000_000, 1_000_000], y:[-1_000_000, 1_000_000],
    width:[1, 1_000_000], height:[1, 1_000_000], scale:[.05, 10], rotation:[-360, 360],
  };
  function normalizedGeometryValue(key, value) {
    if (!Object.prototype.hasOwnProperty.call(GEOMETRY_LIMITS, key)) return value;
    const parsed = Number.parseFloat(value);
    if (!Number.isFinite(parsed)) return null;
    const [minimum, maximum] = GEOMETRY_LIMITS[key];
    return Math.max(minimum, Math.min(maximum, parsed));
  }
  function sanitizeOverrideGeometry(collection) {
    let repaired = 0;
    for (const [id, values] of Object.entries(collection || {})) {
      if (!values || typeof values !== 'object') { delete collection[id]; repaired += 1; continue; }
      for (const key of Object.keys(GEOMETRY_LIMITS)) {
        if (values[key] === undefined || values[key] === '') continue;
        const normalized = normalizedGeometryValue(key, values[key]);
        if (normalized === null) { delete values[key]; repaired += 1; }
        else if (normalized !== values[key]) { values[key] = normalized; repaired += 1; }
      }
      if (!Object.keys(values).length) delete collection[id];
    }
    return repaired;
  }

  function resolveViewBox(value, width = 24, height = 24) {
    const parts = String(value || '').trim().split(/[\s,]+/).filter(Boolean).map(Number);
    if (parts.length === 4 && parts.every(Number.isFinite) && parts[2] > 0 && parts[3] > 0) return parts.join(' ');
    const safeWidth = Math.max(1, number(width, 24));
    const safeHeight = Math.max(1, number(height, 24));
    return `0 0 ${safeWidth} ${safeHeight}`;
  }

  function sanitizeSvgMarkup(markup, width = 24, height = 24, explicitViewBox = '') {
    if (typeof markup !== 'string' || !markup.trim()) throw new Error('图标内容为空');
    const fullSvg = /^\s*<svg[\s>]/i.test(markup);
    const source = fullSvg ? markup.trim() : `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${resolveViewBox(explicitViewBox, width, height)}">${markup}</svg>`;
    const documentXml = new DOMParser().parseFromString(source, 'image/svg+xml');
    if (documentXml.querySelector('parsererror') || documentXml.documentElement.localName.toLowerCase() !== 'svg') throw new Error('SVG 结构无法解析');

    const root = documentXml.documentElement;
    const allowedTags = new Set(['svg','g','path','circle','ellipse','rect','line','polyline','polygon','defs','clippath','mask','lineargradient','radialgradient','stop','symbol','title','desc','use']);
    const allowedAttributes = new Set([
      'd','fill','stroke','color','opacity','fill-opacity','stroke-opacity','stroke-width','stroke-linecap','stroke-linejoin','stroke-miterlimit','stroke-dasharray','stroke-dashoffset',
      'fill-rule','clip-rule','paint-order','vector-effect','transform','transform-origin','x','y','x1','x2','y1','y2','cx','cy','r','rx','ry','width','height','viewbox',
      'points','pathlength','id','href','xlink:href','clip-path','mask','offset','stop-color','stop-opacity','gradientunits','gradienttransform','spreadmethod','preserveaspectratio','role','aria-hidden','focusable'
    ]);

    [...root.querySelectorAll('*')].forEach((node) => {
      if (!allowedTags.has(node.localName.toLowerCase())) { node.remove(); return; }
      [...node.attributes].forEach((attribute) => {
        const name = attribute.name.toLowerCase();
        const value = attribute.value.trim();
        const unsafeUrl = /url\s*\(/i.test(value) && !/^url\(\s*#[\w:.-]+\s*\)$/i.test(value);
        const unsafeHref = (name === 'href' || name === 'xlink:href') && !value.startsWith('#');
        if (name.startsWith('on') || !allowedAttributes.has(name) || unsafeUrl || unsafeHref || /javascript:/i.test(value)) node.removeAttribute(attribute.name);
      });
    });
    const inheritedRootAttributes = new Set(['fill','stroke','color','opacity','fill-opacity','stroke-opacity','stroke-width','stroke-linecap','stroke-linejoin','stroke-miterlimit','stroke-dasharray','stroke-dashoffset','fill-rule','clip-rule','paint-order','vector-effect','clip-path','mask']);
    [...root.attributes].forEach((attribute) => {
      const name = attribute.name.toLowerCase();
      const value = attribute.value.trim();
      const unsafeUrl = /url\s*\(/i.test(value) && !/^url\(\s*#[\w:.-]+\s*\)$/i.test(value);
      if (!['xmlns','viewbox','width','height','preserveaspectratio', ...inheritedRootAttributes].includes(name) || unsafeUrl || /javascript:/i.test(value)) root.removeAttribute(attribute.name);
    });

    const parsedViewBox = resolveViewBox(explicitViewBox || root.getAttribute('viewBox'), width || root.getAttribute('width'), height || root.getAttribute('height'));
    const inherited = [...root.attributes].filter((attribute) => inheritedRootAttributes.has(attribute.name.toLowerCase()));
    if (inherited.length) {
      const wrapper = documentXml.createElementNS('http://www.w3.org/2000/svg', 'g');
      inherited.forEach((attribute) => wrapper.setAttribute(attribute.name, attribute.value));
      while (root.firstChild) wrapper.append(root.firstChild);
      root.append(wrapper);
    }
    const body = root.innerHTML.trim();
    if (!body || !root.querySelector('path,circle,ellipse,rect,line,polyline,polygon,use,g')) throw new Error('没有识别到可用的 SVG 图形');
    return { body, viewBox: parsedViewBox };
  }

  function extractIconifyReferences(text) {
    const source = String(text || '');
    const references = new Map();
    const add = (prefix, iconName) => {
      const normalizedPrefix = String(prefix || '').toLowerCase();
      const normalizedName = String(iconName || '').toLowerCase();
      if (!/^[a-z0-9][a-z0-9-]{1,40}$/.test(normalizedPrefix) || !/^[a-z0-9][a-z0-9-]{1,80}$/.test(normalizedName)) return;
      const name = `${normalizedPrefix}:${normalizedName}`;
      if (!references.has(name)) references.set(name, {
        name,
        format:'Iconify 名称',
        remote:true,
        prefix:normalizedPrefix,
        iconName:normalizedName
      });
    };
    [
      /(?:^|[^a-z0-9_-])([a-z0-9][a-z0-9-]{1,40}):([a-z0-9][a-z0-9-]{1,80})(?=$|[^a-z0-9_-])/gi,
      /(?:^|[^a-z0-9_-])([a-z0-9][a-z0-9-]{1,40})\/([a-z0-9][a-z0-9-]{1,80})(?=$|[^a-z0-9_-])/gi,
      /icon-\[([a-z0-9][a-z0-9-]{1,40})--([a-z0-9][a-z0-9-]{1,80})\]/gi
    ].forEach((pattern) => {
      for (const match of source.matchAll(pattern)) {
        add(match[1], match[2]);
        if (references.size >= 100) break;
      }
    });
    return [...references.values()];
  }

  function parseIconImport(text) {
    const source = String(text || '').trim();
    if (!source) return [];
    if (/^<svg[\s>]/i.test(source)) {
      const parsed = sanitizeSvgMarkup(source);
      return [{ name:'粘贴的 SVG', format:'SVG', body:parsed.body, viewBox:parsed.viewBox, width:24, height:24 }];
    }

    let json;
    try { json = JSON.parse(source); }
    catch {
      const references = extractIconifyReferences(source);
      if (references.length) return references;
      throw new Error('未找到图标名称。请复制类似 tdesign:abstract-filled 的名称，或粘贴完整 SVG');
    }
    if (typeof json === 'string') return parseIconImport(json);
    if (!json || typeof json !== 'object') throw new Error('JSON 中没有可识别的图标数据');
    if (typeof json.svg === 'string') return parseIconImport(json.svg);

    const direct = typeof json.body === 'string' ? json : json.icon && typeof json.icon.body === 'string' ? json.icon : null;
    if (direct) {
      return [{
        name: [json.prefix, json.name || json.iconName].filter(Boolean).join(':') || '单个图标',
        format:'Iconify JSON', body:direct.body, viewBox:direct.viewBox || json.viewBox || '',
        width:direct.width || json.width || 24, height:direct.height || json.height || 24
      }];
    }

    if (json.icons && typeof json.icons === 'object') {
      const names = Object.keys(json.icons).filter((name) => typeof json.icons[name]?.body === 'string').slice(0, 10000);
      if (!names.length) throw new Error('图标集中没有找到 icons.*.body');
      return names.map((name) => {
        const icon = json.icons[name];
        return {
          name: [json.prefix, name].filter(Boolean).join(':'), format:`Iconify 图标集 · ${names.length} 个`,
          body:icon.body, viewBox:icon.viewBox || json.viewBox || '', width:icon.width || json.width || 24, height:icon.height || json.height || 24
        };
      });
    }
    throw new Error('未找到可用图标。请粘贴 Iconify 名称、Iconify JSON 或完整 SVG');
  }

  function resolveSelectedSvgTarget() {
    const selected = selectedElement();
    if (!selected) return null;
    const svg = selected.matches('svg[data-ui-id]') ? selected : selected.querySelector('svg[data-ui-id]');
    if (!svg?.dataset.uiId) return null;
    return { id:svg.dataset.uiId, element:svg, name:labelFor(svg.dataset.uiId) };
  }

  function captureOriginalIcons() {
    originalIcons.clear();
    $$('svg[data-ui-id]', frameDocument).forEach((svg) => {
      originalIcons.set(svg.dataset.uiId, {
        body:svg.innerHTML,
        viewBox:svg.getAttribute('viewBox') || '',
        source:svg.getAttribute('data-ui-icon-source') || ''
      });
    });
  }

  function restoreOriginalIcon(id) {
    const original = originalIcons.get(id);
    const svg = frameDocument?.querySelector(`svg[data-ui-id="${CSS.escape(id)}"]`);
    if (!original || !svg) return false;
    svg.innerHTML = original.body;
    if (original.viewBox) svg.setAttribute('viewBox', original.viewBox); else svg.removeAttribute('viewBox');
    if (original.source) svg.setAttribute('data-ui-icon-source', original.source); else svg.removeAttribute('data-ui-icon-source');
    return true;
  }

  function applyIconReplacement(id) {
    const replacement = iconReplacements[id];
    const svg = frameDocument?.querySelector(`svg[data-ui-id="${CSS.escape(id)}"]`);
    if (!replacement || !svg) return false;
    svg.innerHTML = replacement.body;
    svg.setAttribute('viewBox', replacement.viewBox);
    svg.setAttribute('data-ui-icon-source', replacement.name || 'custom');
    return true;
  }

  function applyAllIconReplacements() {
    if (!frameDocument) return;
    originalIcons.forEach((_, id) => restoreOriginalIcon(id));
    Object.keys(iconReplacements).forEach(applyIconReplacement);
  }

  function updateIconToolTarget() {
    const target = resolveSelectedSvgTarget();
    $('#icon-target-name').textContent = target?.name || '请先在画布或图层面板选择一个图标';
    $('#icon-target-id').textContent = target?.id || '—';
    $('#apply-icon-json').disabled = !target || !iconImportCandidate;
    $('#restore-original-icon').disabled = !target || !iconReplacements[target.id];
    updateIconImportFlow();
    return target;
  }

  function updateIconImportFlow(mode = '') {
    const steps = $$('.icon-import-step');
    if (!steps.length) return;
    const hasTarget = Boolean(resolveSelectedSvgTarget());
    const hasSource = Boolean(iconImportCandidate);
    const states = mode === 'applied'
      ? ['ready','ready','ready']
      : [hasTarget ? 'ready' : 'current', hasSource ? 'ready' : hasTarget ? 'current' : 'pending', hasSource ? 'current' : 'pending'];
    steps.forEach((step, index) => {
      step.dataset.state = states[index];
      step.setAttribute('aria-current', states[index] === 'current' ? 'step' : 'false');
    });
  }

  function setIconImportStatus(message, kind = '', title = '') {
    const status = $('#icon-import-status');
    status.className = `icon-import-status${kind ? ` ${kind}` : ''}`;
    const titles = { error:'需要处理', success:'可以替换', loading:'正在识别' };
    const heading = $('b', status) || document.createElement('b');
    const detail = $('span', status) || document.createElement('span');
    heading.textContent = title || titles[kind] || '下一步';
    detail.textContent = message;
    status.replaceChildren(heading, detail);
  }

  async function fetchIconifyReference(entry) {
    const url = `https://api.iconify.design/${encodeURIComponent(entry.prefix)}/${encodeURIComponent(entry.iconName)}.svg`;
    const response = await fetch(url, { headers:{ Accept:'image/svg+xml' } });
    if (!response.ok) throw new Error(`Iconify 返回 ${response.status}`);
    const source = await response.text();
    const parsed = sanitizeSvgMarkup(source);
    return { ...entry, body:parsed.body, viewBox:parsed.viewBox, width:24, height:24 };
  }

  async function renderIconCandidate(entry) {
    const preview = $('#icon-preview');
    const requestId = ++iconImportRequestId;
    iconImportCandidate = null;
    if (!entry) {
      preview.innerHTML = '<span><b>预览会显示在这里</b><small>粘贴名称后自动识别</small></span>';
      $('#icon-meta-name').textContent = $('#icon-meta-size').textContent = $('#icon-meta-format').textContent = '—';
      setIconImportStatus('粘贴一个图标名称，右侧会自动显示预览');
      updateIconToolTarget();
      return;
    }
    if (entry.remote) {
      preview.innerHTML = `<span><b>正在获取图标</b><small>${entry.name}</small></span>`;
      $('#icon-meta-name').textContent = entry.name;
      $('#icon-meta-size').textContent = '—';
      $('#icon-meta-format').textContent = entry.format;
      setIconImportStatus(`正在从 Iconify 获取 ${entry.name}`, 'loading');
      updateIconImportFlow();
      try {
        entry = await fetchIconifyReference(entry);
        if (requestId !== iconImportRequestId) return;
      } catch {
        if (requestId !== iconImportRequestId) return;
        preview.innerHTML = '<span><b>无法在线加载</b><small>也可以复制 SVG 内容后粘贴</small></span>';
        setIconImportStatus(`已识别 ${entry.name}，但暂时无法从 Iconify 加载。请在图标站选择“SVG”并复制完整内容`, 'error');
        updateIconToolTarget();
        return;
      }
    }
    try {
      const parsed = sanitizeSvgMarkup(entry.body, entry.width, entry.height, entry.viewBox);
      iconImportCandidate = { name:entry.name, format:entry.format, body:parsed.body, viewBox:parsed.viewBox };
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('viewBox', parsed.viewBox);
      svg.setAttribute('aria-label', entry.name);
      svg.innerHTML = parsed.body;
      preview.replaceChildren(svg);
      $('#icon-meta-name').textContent = entry.name;
      $('#icon-meta-size').textContent = parsed.viewBox;
      $('#icon-meta-format').textContent = entry.format;
      setIconImportStatus(`已识别 ${entry.name}。检查预览后，点击“替换图标”`, 'success');
    } catch (error) {
      preview.innerHTML = '<span><b>预览失败</b><small>请换用名称或完整 SVG</small></span>';
      setIconImportStatus(error.message || '图标解析失败', 'error');
    }
    updateIconToolTarget();
  }

  function refreshIconImport() {
    const text = $('#icon-json-input').value;
    if (!text.trim()) {
      iconImportEntries = [];
      $('#icon-choice-wrap').hidden = true;
      renderIconCandidate(null);
      return;
    }
    try {
      iconImportEntries = parseIconImport(text);
      const choice = $('#icon-choice');
      choice.replaceChildren(...iconImportEntries.map((entry, index) => {
        const option = document.createElement('option');
        option.value = String(index);
        option.textContent = entry.name;
        return option;
      }));
      $('#icon-choice-wrap').hidden = iconImportEntries.length < 2;
      renderIconCandidate(iconImportEntries[0]);
    } catch (error) {
      iconImportRequestId += 1;
      iconImportEntries = [];
      $('#icon-choice-wrap').hidden = true;
      iconImportCandidate = null;
      $('#icon-preview').innerHTML = '<span><b>没有识别到图标</b><small>请复制类似 tdesign:abstract-filled 的名称</small></span>';
      $('#icon-meta-name').textContent = $('#icon-meta-size').textContent = $('#icon-meta-format').textContent = '—';
      setIconImportStatus(error.message || '解析失败', 'error');
      updateIconToolTarget();
    }
  }

  function openIconTool() {
    updateIconToolTarget();
    const dialog = $('#icon-tool-dialog');
    if (!dialog.open) dialog.showModal();
    requestAnimationFrame(() => $('#icon-json-input').focus());
  }

  function applyImportedIcon() {
    const target = updateIconToolTarget();
    if (!target) { setIconImportStatus('请先选择 SVG 图标层，或包含独立 SVG 图标层的菜单项', 'error'); return; }
    if (!iconImportCandidate) { setIconImportStatus('请先粘贴图标名称、JSON 或 SVG，并等待右侧出现预览', 'error'); return; }
    iconReplacements[target.id] = clone(iconImportCandidate);
    applyIconReplacement(target.id);
    if (selectedId !== target.id) select(target.id); else drawSelection();
    commit({ label:`替换 ${target.name} 图标`, type:'replace.asset', targetIds:[target.id], detail:{ name:iconImportCandidate.name || 'custom SVG' } });
    updateIconToolTarget();
    updateIconImportFlow('applied');
    setIconImportStatus(`已替换 ${target.name}，Ctrl+Z 可撤销`, 'success');
    showToast(`图标已替换 · ${iconImportCandidate.name}`);
    $('#icon-tool-dialog').close();
    requestAnimationFrame(() => {
      drawSelection();
      frame?.focus?.();
    });
  }

  function injectEditorStyles() {
    const style = frameDocument.createElement('style');
    style.id = 'ui-studio-runtime';
    style.textContent = `
      [data-ui-id] { cursor: default !important; }
      [data-ui-studio-selected="true"], [data-ui-studio-selected="true"] * { cursor: move !important; }
      [data-ui-studio-canvas-hover="true"]:not([data-ui-studio-selected="true"]) { outline: 1px solid rgba(68,125,255,.54); outline-offset: 1px; }
      [data-ui-studio-list-hover="true"] { outline: 2px solid rgba(88,145,255,.75) !important; outline-offset: 2px !important; }
      .ui-studio-selection { position: fixed; z-index: 2147483646; border: 2px solid #3478f6; background: rgba(52,120,246,.025); pointer-events: none; }
      .ui-studio-selection::before { content: attr(data-label); position: absolute; top: -22px; left: -2px; height: 20px; padding: 2px 6px; border-radius: 4px 4px 0 0; background: #3478f6; color: white; font: 11px/16px Arial,sans-serif; white-space: nowrap; }
      .ui-studio-selection::after { content: attr(data-size); position: absolute; right: -2px; bottom: -21px; height: 19px; padding: 1px 6px; border-radius: 0 0 4px 4px; background: #3478f6; color: white; font: 10px/16px Arial,sans-serif; white-space: nowrap; }
      .ui-studio-handle { position: absolute; width: 10px; height: 10px; border: 1px solid #2868de; background: white; border-radius: 2px; pointer-events: auto; }
      .ui-studio-move-grip { position: absolute; top: -22px; right: -2px; display: grid; place-items: center; height: 20px; padding: 0 7px; border-radius: 4px 4px 0 0; background: #1f57bd; color: white; font: 10px/20px Arial,sans-serif; cursor: move; pointer-events: auto; user-select: none; }
      .ui-studio-handle[data-dir="nw"] { left:-5px; top:-5px; cursor:nwse-resize; }
      .ui-studio-handle[data-dir="n"] { left:50%; top:-5px; transform:translateX(-50%); cursor:ns-resize; }
      .ui-studio-handle[data-dir="ne"] { right:-5px; top:-5px; cursor:nesw-resize; }
      .ui-studio-handle[data-dir="e"] { right:-5px; top:50%; transform:translateY(-50%); cursor:ew-resize; }
      .ui-studio-handle[data-dir="se"] { right:-5px; bottom:-5px; cursor:nwse-resize; }
      .ui-studio-handle[data-dir="s"] { left:50%; bottom:-5px; transform:translateX(-50%); cursor:ns-resize; }
      .ui-studio-handle[data-dir="sw"] { left:-5px; bottom:-5px; cursor:nesw-resize; }
      .ui-studio-handle[data-dir="w"] { left:-5px; top:50%; transform:translateY(-50%); cursor:ew-resize; }
      .ui-studio-selection[data-multi="true"] { border-color:#6f9df7; background:rgba(52,120,246,.055); }
      .ui-studio-selection[data-multi="true"] .ui-studio-handle { display:none; }
      .ui-studio-selection[data-multi="true"] .ui-studio-move-grip { background:#315fba; }
      .ui-studio-snap-line { position: fixed; z-index: 2147483644; display: none; background: #ff3ca6; pointer-events: none; }
      .ui-studio-snap-line.vertical { top: 0; bottom: 0; width: 1px; }
      .ui-studio-snap-line.horizontal { right: 0; left: 0; height: 1px; }
      .ui-studio-snap-line::after { content: attr(data-label); position: absolute; padding: 2px 5px; border-radius: 3px; background: #ff3ca6; color: white; font: 9px/12px Arial,sans-serif; white-space: nowrap; }
      .ui-studio-snap-line.vertical::after { top: 7px; left: 4px; }
      .ui-studio-snap-line.horizontal::after { top: 4px; left: 7px; }
      .ui-studio-marquee { position: fixed; z-index: 2147483645; display: none; border: 1px solid #4d8dff; background: rgba(64,132,255,.12); pointer-events: none; }
    `;
    frameDocument.head.append(style);
  }

  function buildSelectionBox() {
    selectionBox?.remove();
    selectionBox = document.createElement('div');
    selectionBox.className = 'ui-studio-selection';
    selectionBox.hidden = true;
    const selectionLabel = document.createElement('span');
    selectionLabel.className = 'ui-studio-selection-label ui-studio-move-grip';
    selectionLabel.dataset.dir = 'move';
    selectionLabel.setAttribute('aria-label', '拖动当前选择');
    selectionLabel.title = '拖动对象 · Shift 锁定方向 · Alt 复制';
    selectionBox.append(selectionLabel);
    const moveSurface = document.createElement('span');
    moveSurface.className = 'ui-studio-move-surface';
    moveSurface.dataset.dir = 'move';
    moveSurface.setAttribute('aria-label', '拖动已选择对象；双击进入下一层');
    moveSurface.title = '拖动对象 · 双击进入下一层';
    selectionBox.append(moveSurface);
    moveSurface.addEventListener('dblclick', (event) => {
      event.preventDefault();
      event.stopPropagation();
      const frameRect = frame.getBoundingClientRect();
      const renderScale = canvasRenderScale(frameRect);
      const localX = (event.clientX - frameRect.left) / Math.max(.05, renderScale.x);
      const localY = (event.clientY - frameRect.top) / Math.max(.05, renderScale.y);
      const child = frameDocument.elementFromPoint(localX, localY)?.closest?.('[data-ui-id]');
      if (child && child.dataset.uiId !== selectedId) select(child.dataset.uiId);
    });
    ['n','e','s','w'].forEach((direction) => {
      const edge = document.createElement('span');
      edge.className = 'ui-studio-edge';
      edge.dataset.dir = direction;
      edge.setAttribute('aria-label', `${direction === 'n' || direction === 's' ? '调整高度' : '调整宽度'} · 拖动整条边线`);
      edge.title = direction === 'n' || direction === 's' ? '拖动整条边调整高度' : '拖动整条边调整宽度';
      selectionBox.append(edge);
    });
    ['nw','n','ne','e','se','s','sw','w'].forEach((direction) => {
      const handle = document.createElement('span');
      handle.className = 'ui-studio-handle';
      handle.dataset.dir = direction;
      selectionBox.append(handle);
    });
    $('.canvas-area').append(selectionBox);
    selectionBox.addEventListener('pointerdown', beginManipulation);

    snapVertical = frameDocument.createElement('div');
    snapVertical.className = 'ui-studio-snap-line vertical';
    snapHorizontal = frameDocument.createElement('div');
    snapHorizontal.className = 'ui-studio-snap-line horizontal';
    frameDocument.body.append(snapVertical, snapHorizontal);
  }

  function buildRulers() {
    const horizontal = $('#ruler-horizontal');
    const vertical = $('#ruler-vertical');
    const xFragment = document.createDocumentFragment();
    const yFragment = document.createDocumentFragment();
    const steps = [5,10,25,50,100,200,500,1000,2000];
    const minorStep = steps.find((step) => step * zoom >= 8) || 2000;
    const majorStep = steps.find((step) => step * zoom >= 58) || 2000;
    const isMajor = (value) => Math.abs(value / majorStep - Math.round(value / majorStep)) < .001;
    for (let x = 0; x <= viewport.width; x += minorStep) {
      const tick = document.createElement('span');
      const major = isMajor(x);
      tick.className = `ruler-tick${major ? ' major' : ''}`;
      tick.dataset.value = String(x);
      if (major) tick.innerHTML = `<span>${Math.round(x)}</span>`;
      xFragment.append(tick);
    }
    for (let y = 0; y <= viewport.height; y += minorStep) {
      const tick = document.createElement('span');
      const major = isMajor(y);
      tick.className = `ruler-tick${major ? ' major' : ''}`;
      tick.dataset.value = String(y);
      if (major) tick.innerHTML = `<span>${Math.round(y)}</span>`;
      yFragment.append(tick);
    }
    horizontal.replaceChildren(xFragment);
    vertical.replaceChildren(yFragment);
    positionRulerTicks();
  }

  function positionRulerTicks() {
    const canvas = $('#canvas-viewport');
    const horizontalOrigin = stage.offsetLeft - canvas.scrollLeft - 23;
    const verticalOrigin = stage.offsetTop - canvas.scrollTop - 23;
    $$('.ruler-tick', $('#ruler-horizontal')).forEach((tick) => {
      tick.style.left = `${horizontalOrigin + number(tick.dataset.value) * zoom}px`;
    });
    $$('.ruler-tick', $('#ruler-vertical')).forEach((tick) => {
      tick.style.top = `${verticalOrigin + number(tick.dataset.value) * zoom}px`;
    });
  }

  function scheduleRulerSync() {
    if (rulerSyncFrame) return;
    rulerSyncFrame = requestAnimationFrame(() => {
      rulerSyncFrame = 0;
      positionRulerTicks();
      positionCanvasGuides();
    });
  }

  function beginRulerGuideDrag(event, axis) {
    if (event.button !== 0 || !guidesVisible) return;
    event.preventDefault();
    const source = event.currentTarget;
    const preview = $('#ruler-guide-preview');
    const area = $('.canvas-area');
    const startX = event.clientX;
    const startY = event.clientY;
    let lastX = startX;
    let lastY = startY;
    source.setPointerCapture?.(event.pointerId);
    preview.className = `ruler-guide-preview ${axis} visible`;
    const updatePreview = (clientX, clientY) => {
      const areaRect = area.getBoundingClientRect();
      if (axis === 'horizontal') preview.style.top = `${clientY - areaRect.top}px`;
      else preview.style.left = `${clientX - areaRect.left}px`;
    };
    updatePreview(lastX, lastY);
    const move = (moveEvent) => {
      lastX = moveEvent.clientX;
      lastY = moveEvent.clientY;
      updatePreview(lastX, lastY);
    };
    const finish = () => {
      source.removeEventListener('pointermove', move);
      source.removeEventListener('pointerup', finish);
      source.removeEventListener('pointercancel', cancel);
      preview.className = 'ruler-guide-preview';
      preview.removeAttribute('style');
      const distance = Math.hypot(lastX - startX, lastY - startY);
      if (distance < 3) return;
      const frameRect = frame.getBoundingClientRect();
      const renderScale = canvasRenderScale(frameRect);
      const position = axis === 'horizontal'
        ? (lastY - frameRect.top) / renderScale.y
        : (lastX - frameRect.left) / renderScale.x;
      const limit = axis === 'horizontal' ? viewport.height : viewport.width;
      if (position < 0 || position > limit) return;
      guides.push({ id:`${axis}-${Date.now()}`, axis, position });
      saveGuides();
      renderGuides();
      commit({ label:`从标尺添加${axis === 'vertical' ? '垂直' : '水平'}参考线`, type:'guide.add', targetIds:[], detail:{ axis, position:Math.round(position) } });
      showToast(`${axis === 'vertical' ? '垂直' : '水平'}参考线 ${Math.round(position)} px`);
    };
    const cancel = () => {
      source.removeEventListener('pointermove', move);
      source.removeEventListener('pointerup', finish);
      source.removeEventListener('pointercancel', cancel);
      preview.className = 'ruler-guide-preview';
      preview.removeAttribute('style');
    };
    source.addEventListener('pointermove', move);
    source.addEventListener('pointerup', finish);
    source.addEventListener('pointercancel', cancel);
  }

  function saveGuides() {
    localStorage.setItem(GUIDES_KEY, JSON.stringify(guides));
  }

  function positionCanvasGuides() {
    const overlay = $('#canvas-ruler-overlay');
    const area = $('.canvas-area');
    if (!overlay || !area || !frame) return;
    const areaRect = area.getBoundingClientRect();
    const frameRect = frame.getBoundingClientRect();
    const renderScale = canvasRenderScale(frameRect);
    $$('.canvas-guide', overlay).forEach((element) => {
      const guide = guides.find((item) => item.id === element.dataset.guideId);
      if (!guide) return;
      if (guide.axis === 'vertical') element.style.left = `${frameRect.left - areaRect.left + guide.position * renderScale.x}px`;
      else element.style.top = `${frameRect.top - areaRect.top + guide.position * renderScale.y}px`;
      element.dataset.value = `${Math.round(guide.position)} px`;
    });
  }

  function renderGuides() {
    const overlay = $('#canvas-ruler-overlay');
    if (!overlay) return;
    if (frameDocument) $$('.ui-studio-guide', frameDocument).forEach((element) => element.remove());
    $$('.canvas-guide', overlay).forEach((element) => element.remove());
    if (!guidesVisible) return;
    guides.forEach((guide) => {
      const element = document.createElement('button');
      element.type = 'button';
      element.className = `canvas-guide ${guide.axis}`;
      element.dataset.guideId = guide.id;
      element.dataset.value = `${Math.round(guide.position)} px`;
      element.setAttribute('aria-label', `${guide.axis === 'vertical' ? '垂直' : '水平'}辅助线 ${Math.round(guide.position)} 像素；拖回标尺可删除`);
      element.addEventListener('pointerdown', (event) => beginCanvasGuideDrag(event, guide, element));
      element.addEventListener('dblclick', (event) => {
        event.preventDefault(); event.stopPropagation();
        guides = guides.filter((item) => item.id !== guide.id);
        saveGuides(); renderGuides();
        commit({ label:'删除参考线', type:'guide.remove', targetIds:[], detail:{ axis:guide.axis } });
        showToast('参考线已删除');
      });
      overlay.append(element);
    });
    positionCanvasGuides();
  }

  function beginCanvasGuideDrag(event, guide, element) {
    if (event.button !== 0) return;
    event.preventDefault(); event.stopPropagation();
    const startPosition = guide.position;
    let deleteTarget = false;
    element.classList.add('dragging');
    try { element.setPointerCapture(event.pointerId); } catch {}

    const update = (moveEvent) => {
      const areaRect = $('.canvas-area').getBoundingClientRect();
      const frameRect = frame.getBoundingClientRect();
      const renderScale = canvasRenderScale(frameRect);
      deleteTarget = guide.axis === 'horizontal'
        ? moveEvent.clientY >= areaRect.top && moveEvent.clientY <= areaRect.top + 31
        : moveEvent.clientX >= areaRect.left && moveEvent.clientX <= areaRect.left + 31;
      element.classList.toggle('delete-target', deleteTarget);
      if (deleteTarget) return;
      const pointer = guide.axis === 'vertical' ? moveEvent.clientX : moveEvent.clientY;
      const origin = guide.axis === 'vertical' ? frameRect.left : frameRect.top;
      const scale = guide.axis === 'vertical' ? renderScale.x : renderScale.y;
      const limit = guide.axis === 'vertical' ? viewport.width : viewport.height;
      guide.position = Math.max(0, Math.min(limit, (pointer - origin) / scale));
      positionCanvasGuides();
    };
    const cleanup = () => {
      window.removeEventListener('pointermove', move, true);
      window.removeEventListener('pointerup', end, true);
      window.removeEventListener('pointercancel', cancel, true);
      element.classList.remove('dragging', 'delete-target');
      try { element.releasePointerCapture(event.pointerId); } catch {}
    };
    const move = (moveEvent) => update(moveEvent);
    const end = (endEvent) => {
      update(endEvent);
      cleanup();
      if (deleteTarget) {
        guides = guides.filter((item) => item.id !== guide.id);
        saveGuides(); renderGuides();
        commit({ label:'删除辅助线', type:'guide.remove', targetIds:[], detail:{ axis:guide.axis } });
        showToast('辅助线已放回标尺并删除');
        return;
      }
      saveGuides();
      if (Math.round(startPosition) !== Math.round(guide.position)) {
        commit({ label:'移动辅助线', type:'guide.move', targetIds:[], detail:{ axis:guide.axis, position:Math.round(guide.position) }, mergeKey:`guide:${guide.id}` });
      }
      renderGuides();
    };
    const cancel = () => {
      cleanup();
      guide.position = startPosition;
      positionCanvasGuides();
    };
    window.addEventListener('pointermove', move, true);
    window.addEventListener('pointerup', end, true);
    window.addEventListener('pointercancel', cancel, true);
  }

  function beginGuideDrag(event, guide, element) {
    if (event.button !== 0) return;
    event.preventDefault(); event.stopPropagation();
    const startPointer = guide.axis === 'vertical' ? event.clientX : event.clientY;
    const startPosition = guide.position;
    function move(moveEvent) {
      const pointer = guide.axis === 'vertical' ? moveEvent.clientX : moveEvent.clientY;
      const limit = guide.axis === 'vertical' ? viewport.width : viewport.height;
      guide.position = Math.max(0, Math.min(limit, startPosition + pointer - startPointer));
      element.dataset.value = `${Math.round(guide.position)} px`;
      if (guide.axis === 'vertical') element.style.left = `${guide.position}px`;
      else element.style.top = `${guide.position}px`;
    }
    function end() {
      frameDocument.removeEventListener('pointermove', move, true);
      frameDocument.removeEventListener('pointerup', end, true);
      saveGuides();
      if (Math.round(startPosition) !== Math.round(guide.position)) {
        commit({ label:'移动参考线', type:'guide.move', targetIds:[], detail:{ axis:guide.axis, position:Math.round(guide.position) }, mergeKey:`guide:${guide.id}` });
      }
    }
    frameDocument.addEventListener('pointermove', move, true);
    frameDocument.addEventListener('pointerup', end, true);
  }

  function addGuide(axis) {
    const position = axis === 'vertical' ? viewport.width / 2 : viewport.height / 2;
    guides.push({ id: `${axis}-${Date.now()}`, axis, position });
    saveGuides(); renderGuides();
    commit({ label:`添加${axis === 'vertical' ? '竖向' : '横向'}参考线`, type:'guide.add', targetIds:[], detail:{ axis, position:Math.round(position) } });
    showToast(`${axis === 'vertical' ? '垂直' : '水平'}参考线已添加，可拖动或双击删除`);
  }

  function refreshGuideVisibilityControl({ persist = false } = {}) {
    const button = $('#toggle-guides');
    document.body.classList.toggle('guides-hidden', !guidesVisible);
    button.classList.toggle('active', guidesVisible);
    button.setAttribute('aria-pressed', String(guidesVisible));
    const label = guidesVisible ? '隐藏标尺与辅助线' : '显示标尺与辅助线';
    button.setAttribute('aria-label', label);
    button.title = label;
    if (persist) localStorage.setItem(GUIDES_VISIBILITY_KEY, String(guidesVisible));
    renderGuides();
  }

  function hideSnapFeedback() {
    [snapVertical, snapHorizontal].forEach((element) => { if (element) element.style.display = 'none'; });
    lastSnapStatus = '';
    if ($('#status-snap')) $('#status-snap').textContent = snapEnabled ? '精细吸附 3–4px · Alt 绕过' : '吸附关闭';
  }

  function showSnapFeedback(x, y, xLabel = '', yLabel = '') {
    if (x === null) snapVertical.style.display = 'none';
    else { snapVertical.style.display = 'block'; snapVertical.style.left = `${x}px`; snapVertical.dataset.label = xLabel; }
    if (y === null) snapHorizontal.style.display = 'none';
    else { snapHorizontal.style.display = 'block'; snapHorizontal.style.top = `${y}px`; snapHorizontal.dataset.label = yLabel; }
    const nextStatus = [x !== null ? xLabel : '', y !== null ? yLabel : ''].filter(Boolean).join(' ＋ ');
    if (nextStatus && nextStatus !== lastSnapStatus) {
      lastSnapStatus = `吸附到 ${nextStatus}`;
      if ($('#status-snap')) $('#status-snap').textContent = lastSnapStatus;
    }
  }

  function dedupeSnapTargets(targets) {
    const unique = new Map();
    targets.forEach((item) => {
      const key = Math.round(item.value * 100) / 100;
      const current = unique.get(key);
      if (!current || item.priority < current.priority) unique.set(key, item);
    });
    return [...unique.values()];
  }

  function collectSnapTargets(element, excludedIds = new Set()) {
    const target = (value, priority, label, kind = 'structure') => ({ value, priority, label, kind });
    const x = [target(0,0,'画布左边'), target(viewport.width / 2,5,'画布水平中心','center'), target(viewport.width,0,'画布右边')];
    const y = [target(0,0,'画布顶部'), target(viewport.height / 2,5,'画布垂直中心','center'), target(viewport.height,0,'画布底部')];
    guides.forEach((guide) => (guide.axis === 'vertical' ? x : y).push(target(guide.position,-2,'参考线','guide')));
    const parent = element.parentElement;
    if (parent) {
      const parentRect = parent.getBoundingClientRect();
      const parentStyle = getComputedStyle(parent);
      x.push(target(parentRect.left,0,'父级左边'), target(parentRect.right,0,'父级右边'));
      y.push(target(parentRect.top,0,'父级顶部'), target(parentRect.bottom,0,'父级底部'));
      x.push(target(parentRect.left + number(parentStyle.paddingLeft),-1,'父级内容左边'), target(parentRect.right - number(parentStyle.paddingRight),-1,'父级内容右边'));
      y.push(target(parentRect.top + number(parentStyle.paddingTop),-1,'父级内容顶部'), target(parentRect.bottom - number(parentStyle.paddingBottom),-1,'父级内容底部'));
    }
    const excludedElements = [...excludedIds].map((id) => frameDocument.querySelector(`[data-ui-id="${CSS.escape(id)}"]`)).filter(Boolean);
    $$('[data-ui-id]', frameDocument).forEach((candidate) => {
      if (candidate === element || element.contains(candidate) || candidate.contains(element)) return;
      if (excludedElements.some((excluded) => candidate === excluded || excluded.contains(candidate) || candidate.contains(excluded))) return;
      const rect = candidate.getBoundingClientRect();
      if ((!rect.width && !rect.height) || rect.bottom < 0 || rect.right < 0 || rect.top > viewport.height || rect.left > viewport.width) return;
      const style = getComputedStyle(candidate);
      if (style.display === 'none' || style.visibility === 'hidden') return;
      const label = labelFor(candidate.dataset.uiId);
      const isText = candidate.childElementCount === 0 && (candidate.textContent || '').trim();
      const isLayoutLine = ['SECTION','ASIDE','NAV','HEADER','MAIN','FORM'].includes(candidate.tagName) || number(style.borderTopWidth) > 0 || number(style.borderBottomWidth) > 0;
      const edgePriority = isLayoutLine ? 1 : isText ? 4 : 3;
      x.push(target(rect.left,edgePriority,`${label}左边`), target(rect.right,edgePriority,`${label}右边`), target(rect.left + rect.width / 2,6,`${label}中心`));
      y.push(target(rect.top,edgePriority,`${label}顶部`), target(rect.bottom,edgePriority,`${label}底部`), target(rect.top + rect.height / 2,6,`${label}中心`));
      if (isText) {
        const fontSize = number(style.fontSize, 14);
        const lineHeight = style.lineHeight === 'normal' ? fontSize * 1.2 : number(style.lineHeight, fontSize * 1.2);
        const baseline = rect.top + Math.max(0, (rect.height - lineHeight) / 2) + fontSize * .82;
        y.push(target(baseline,0,`${label}文字基线`,'baseline'));
      }
    });
    return { x:dedupeSnapTargets(x), y:dedupeSnapTargets(y) };
  }

  function snapDocumentDistance(screenPixels, renderScale = zoom) {
    return screenPixels / Math.max(.05, renderScale);
  }

  function snapAcquireScreenPixels(kind) {
    if (kind === 'guide') return SNAP_GUIDE_ACQUIRE_SCREEN_PX;
    if (kind === 'grid') return SNAP_GRID_ACQUIRE_SCREEN_PX;
    return SNAP_STRUCTURE_ACQUIRE_SCREEN_PX;
  }

  function snapReleaseScreenPixels(kind) {
    if (kind === 'guide') return SNAP_GUIDE_RELEASE_SCREEN_PX;
    if (kind === 'grid') return SNAP_GRID_RELEASE_SCREEN_PX;
    return SNAP_STRUCTURE_RELEASE_SCREEN_PX;
  }

  function snapAxis(candidates, targets, sticky = null, renderScale = zoom) {
    if (!snapEnabled) return { delta: 0, target: null };
    const tieDistance = snapDocumentDistance(SNAP_PRIORITY_TIE_SCREEN_PX, renderScale);
    let best = { delta:0, target:null, distance:Infinity, priority:Infinity, label:'', kind:'', sticky:null };
    const consider = (candidate, candidateIndex, item) => {
      const delta = item.value - candidate;
      const distance = Math.abs(delta);
      const threshold = snapDocumentDistance(snapAcquireScreenPixels(item.kind), renderScale);
      if (distance > threshold) return;
      const clearlyCloser = distance < best.distance - tieDistance;
      const nearlyEqual = Math.abs(distance - best.distance) <= tieDistance;
      if (!clearlyCloser && !(nearlyEqual && item.priority < best.priority)) return;
      best = {
        delta,
        target:item.value,
        distance,
        priority:item.priority,
        label:item.label,
        kind:item.kind,
        sticky:{ target:item.value, label:item.label, kind:item.kind, candidateIndex },
      };
    };
    candidates.forEach((candidate, candidateIndex) => {
      targets.forEach((target) => {
        const item = typeof target === 'number' ? { value:target, priority:3, label:'', kind:'structure' } : target;
        consider(candidate, candidateIndex, item);
      });
      if (gridEnabled) {
        consider(candidate, candidateIndex, { value:Math.round(candidate / 8) * 8, priority:7, label:'8px 网格', kind:'grid' });
      }
    });
    if (sticky && Number.isFinite(sticky.target) && Number.isInteger(sticky.candidateIndex)) {
      const candidate = candidates[sticky.candidateIndex];
      const distance = Math.abs(sticky.target - candidate);
      const releaseDistance = snapDocumentDistance(snapReleaseScreenPixels(sticky.kind), renderScale);
      const switchAdvantage = snapDocumentDistance(SNAP_SWITCH_ADVANTAGE_SCREEN_PX, renderScale);
      const sameTarget = best.sticky
        && best.sticky.candidateIndex === sticky.candidateIndex
        && Math.abs(best.target - sticky.target) < .01;
      const betterFreshTarget = best.target !== null && !sameTarget && best.distance + switchAdvantage < distance;
      if (Number.isFinite(candidate) && distance <= releaseDistance && !betterFreshTarget) {
        return {
          delta:sticky.target - candidate,
          target:sticky.target,
          distance,
          priority:sticky.priority ?? 0,
          label:sticky.label || '',
          kind:sticky.kind || 'structure',
          sticky,
        };
      }
    }
    return best;
  }

  function applyStructuralEdits() {
    if (!frameDocument) return;
    $$('[data-ui-studio-insertion]', frameDocument).reverse().forEach((element) => element.remove());
    for (const insertion of structuralEdits.insertions || []) {
      if (frameDocument.querySelector(`[data-ui-id="${CSS.escape(insertion.id)}"]`)) continue;
      const source = frameDocument.querySelector(`[data-ui-id="${CSS.escape(insertion.sourceId)}"]`);
      if (!source) continue;
      const parent = insertion.parentId
        ? frameDocument.querySelector(`[data-ui-id="${CSS.escape(insertion.parentId)}"]`)
        : source.parentElement;
      if (!parent) continue;
      const duplicate = source.cloneNode(true);
      [duplicate, ...$$('[data-ui-id]', duplicate)].forEach((element) => {
        const nextId = insertion.idMap?.[element.dataset.uiId];
        if (!nextId) return;
        element.dataset.uiId = nextId;
        if (element !== duplicate && element.dataset.uiName) element.dataset.uiName = `${element.dataset.uiName} 副本`;
      });
      duplicate.dataset.uiStudioInsertion = insertion.id;
      duplicate.dataset.uiName = insertion.name || `${labelFor(insertion.sourceId)} 副本`;
      const after = insertion.afterId
        ? frameDocument.querySelector(`[data-ui-id="${CSS.escape(insertion.afterId)}"]`)
        : null;
      if (after?.parentElement === parent) after.after(duplicate);
      else parent.append(duplicate);
    }
  }

  function applyLayerMetadata() {
    if (!frameDocument) return;
    for (const element of $$('[data-ui-id]', frameDocument)) {
      const id = element.dataset.uiId;
      if (!baseNames.has(id)) continue;
      const originalName = baseNames.get(id);
      if (originalName) element.dataset.uiName = originalName;
      else delete element.dataset.uiName;
    }
    for (const [id, metadata] of Object.entries(layerMetadata)) {
      const element = frameDocument.querySelector(`[data-ui-id="${CSS.escape(id)}"]`);
      if (element && metadata?.name) element.dataset.uiName = metadata.name;
    }
  }

  function generatedIds() {
    return new Set([
      ...$$('[data-ui-id]', frameDocument).map((element) => element.dataset.uiId),
      ...(structuralEdits.insertions || []).flatMap((insertion) => Object.values(insertion.idMap || {})),
    ]);
  }

  function uniqueCopyId(sourceId, used, start = 1) {
    let index = Math.max(1, start);
    let candidate = `${sourceId}.copy${index}`;
    while (used.has(candidate)) { index += 1; candidate = `${sourceId}.copy${index}`; }
    used.add(candidate);
    return { id:candidate, index };
  }

  function createInsertionRecord(sourceId, used) {
    const source = frameDocument.querySelector(`[data-ui-id="${CSS.escape(sourceId)}"]`);
    if (!source) return null;
    const rootCopy = uniqueCopyId(sourceId, used);
    const idMap = { [sourceId]:rootCopy.id };
    for (const element of $$('[data-ui-id]', source)) {
      const childId = element.dataset.uiId;
      idMap[childId] = uniqueCopyId(childId, used, rootCopy.index).id;
    }
    const parent = source.parentElement?.closest('[data-ui-id]');
    return {
      id:rootCopy.id,
      sourceId,
      parentId:parent?.dataset.uiId || null,
      afterId:sourceId,
      idMap,
      name:`${labelFor(sourceId)} 副本`,
    };
  }

  function duplicateSelection(options = {}) {
    const shouldCommit = options.commit !== false;
    const shouldNotify = options.notify !== false;
    const sourceIds = selectableClipboardIds().filter((id) => id !== 'app.shell' && !isEffectivelyLocked(id));
    if (!sourceIds.length) {
      showToast(activeSelectionIds().includes('app.shell') ? '页面根节点不能复制' : '没有可复制的未锁定图层');
      return false;
    }
    const used = generatedIds();
    const records = sourceIds.map((id) => createInsertionRecord(id, used)).filter(Boolean);
    if (!records.length) return false;
    for (const record of records) {
      structuralEdits.insertions.push(record);
      for (const [sourceId, generatedId] of Object.entries(record.idMap)) {
        if (overrides[sourceId]) overrides[generatedId] = clone(overrides[sourceId]);
        if (iconReplacements[sourceId]) iconReplacements[generatedId] = clone(iconReplacements[sourceId]);
      }
    }
    applyStructuralEdits();
    buildLayers();
    applyAll();
    selectedIds = new Set(records.map((record) => record.id));
    selectedId = records.at(-1).id;
    if (shouldCommit) commit({
      label:`复制 ${records.length > 1 ? `${records.length} 个对象` : labelFor(records[0].sourceId)}`,
      type:'layer.duplicate',
      targetIds:records.map((record) => record.id),
      detail:{ sourceIds, insertionIds:records.map((record) => record.id) },
    });
    renderLayers($('#layer-search').value);
    updateContextInspector();
    drawSelection();
    if (shouldNotify) showToast(`已创建 ${records.length} 个真实图层副本 · Ctrl+Z 可撤销`);
    return records;
  }

  function buildLayers() {
    const language = frameLanguage();
    nodes = $$('[data-ui-id]', frameDocument).map((element) => {
      const parent = element.parentElement?.closest('[data-ui-id]');
      const rect = element.getBoundingClientRect();
      const id = element.dataset.uiId;
      if (!baseSizes.has(id)) baseSizes.set(id, { width: rect.width, height: rect.height });
      if (isTextElement(element) && !baseTexts.has(id)) baseTexts.set(id, element.textContent);
      captureBaseStyles(element, id);
      if (!baseNames.has(element.dataset.uiId)) baseNames.set(element.dataset.uiId, element.dataset.uiName || '');
      let depth = 0;
      let cursor = parent;
      while (cursor) { depth += 1; cursor = cursor.parentElement?.closest('[data-ui-id]'); }
      const directText = directLayerText(element);
      const display = describeLayer(element, directText, language);
      return {
        id:element.dataset.uiId,
        tag:element.tagName.toLowerCase(),
        name:element.dataset.uiName || '',
        text:directText,
        displayName:display.label,
        displayNameGeneric:display.generic,
        displayKind:display.kind || genericLayerKey(element.dataset.uiName || element.dataset.uiId, element),
        parentId:parent?.dataset.uiId || null,
        depth,
      };
    });
    const genericCounts = new Map();
    nodes.filter((node) => node.displayNameGeneric).forEach((node) => genericCounts.set(node.displayName, (genericCounts.get(node.displayName) || 0) + 1));
    const genericIndexes = new Map();
    nodes.forEach((node) => {
      if (!node.displayNameGeneric || genericCounts.get(node.displayName) < 2) return;
      const index = (genericIndexes.get(node.displayName) || 0) + 1;
      genericIndexes.set(node.displayName, index);
      node.displayName = `${node.displayName} ${index}`;
    });
    const liveIds = new Set(nodes.map((node) => node.id));
    selectedIds = new Set([...selectedIds].filter((id) => liveIds.has(id)));
    if (selectedId && !liveIds.has(selectedId)) selectedId = null;
    renderLayers();
    renderFeatureObjectLists();
    updateFeatureCount();
    renderStatusBar();
    syncActivePageLayerCount(discoveredPageEntries());
  }

  function structureViewNodes() {
    const nodeById = new Map(nodes.map((node) => [node.id, node]));
    const dynamicPageEntries = discoveredPageEntries();
    const dynamicRouteById = new Map(dynamicPageEntries.map((entry) => [entry.id, entry]));
    const dynamicContentOwner = new Map(dynamicPageEntries.filter((entry) => entry.containerId).map((entry) => [entry.containerId, entry.id]));
    const children = new Map();
    nodes.forEach((node) => {
      if (!children.has(node.parentId)) children.set(node.parentId, []);
      children.get(node.parentId).push(node);
    });
    const result = [];
    const used = new Set();
    const pushNode = (node, viewParentId, viewDepth, extra = {}) => {
      if (!node || used.has(node.id)) return;
      used.add(node.id);
      result.push({ ...node, viewParentId, viewDepth, ...extra });
    };
    const appendSubtree = (rootId, viewParentId, viewDepth) => {
      const root = nodeById.get(rootId);
      if (!root || used.has(root.id)) return;
      pushNode(root, viewParentId, viewDepth);
      (children.get(root.id) || []).forEach((child) => appendSubtree(child.id, root.id, viewDepth + 1));
    };
    const appendGenericSubtree = (node, viewParentId = null, viewDepth = 0, fromRoute = false) => {
      if (!node || used.has(node.id)) return;
      if (!fromRoute && dynamicContentOwner.has(node.id)) return;
      const route = dynamicRouteById.get(node.id);
      pushNode(node, viewParentId, viewDepth, {
        viewLabel:route?.label || node.displayName || node.text || labelFor(node.id),
        viewRole:route ? '页面' : viewDepth === 0 && node.displayKind === 'page' ? localizedLayerKind('page') : null,
        route,
        routeStatus:route ? (route.active ? '当前页面' : route.bound ? '可进入' : '未绑定') : null,
      });
      (children.get(node.id) || []).forEach((child) => appendGenericSubtree(child, node.id, viewDepth + 1));
      if (route?.containerId && route.containerId !== node.id) {
        appendGenericSubtree(nodeById.get(route.containerId), node.id, viewDepth + 1, true);
      }
    };

    const knownRouteCount = PAGE_ROUTES.filter((route) => nodeById.has(route.id)).length;
    const hasKnownPageContract = nodeById.has('app.shell')
      && nodeById.has('sidebar.navigation')
      && knownRouteCount > 0;

    // Imported projects are not required to use the bundled demo's route IDs.
    // When the preview belongs to another generated UI, render its real DOM
    // hierarchy instead of filtering every valid layer out through PAGE_ROUTES.
    if (!hasKnownPageContract) {
      nodes
        .filter((node) => !node.parentId || !nodeById.has(node.parentId))
        .forEach((node) => appendGenericSubtree(node));
      // Corrupt or partially generated parent links must not make a layer vanish.
      nodes.filter((node) => !used.has(node.id)).forEach((node) => appendGenericSubtree(node));
      return result;
    }

    const app = nodeById.get('app.shell');
    pushNode(app, null, 0, { viewLabel:'共享框架', viewRole:'公共', shared:true });
    appendSubtree('sidebar.brand', 'app.shell', 1);
    appendSubtree('sidebar.account', 'app.shell', 1);

    const navigation = nodeById.get('sidebar.navigation');
    pushNode(navigation, null, 0, { viewLabel:'页面导航', viewRole:'路由', navigationRoot:true });
    PAGE_ROUTES.forEach((route) => {
      const routeNode = nodeById.get(route.id);
      if (!routeNode) return;
      pushNode(routeNode, 'sidebar.navigation', 1, {
        viewLabel:route.label,
        viewRole:'页面',
        route,
        routeStatus:route.bound ? '当前页面' : '未绑定',
      });
      (children.get(route.id) || []).forEach((child) => appendSubtree(child.id, route.id, 2));
      (route.content || []).forEach((contentId) => appendSubtree(contentId, route.id, 2));
    });
    // A partially matching imported page may share app/sidebar IDs with the
    // bundled example. Preserve every remaining identity instead of silently
    // hiding it behind the optional route adapter.
    nodes.filter((node) => !used.has(node.id)).forEach((node) => appendGenericSubtree(node));
    return result;
  }

  function currentPageContext() {
    if (!frameDocument) return { label:'正在载入', mode:'loading' };
    const discovered = activePageEntry();
    if (discovered) return { label:discovered.label, mode:'bound-route', key:discovered.key };
    const nodeIds = new Set(nodes.map((node) => node.id));
    const currentRoute = PAGE_ROUTES.find((route) => route.bound && nodeIds.has(route.id));
    if (currentRoute) return { label:currentRoute.label, mode:'bound-route' };
    const explicit = frameDocument.documentElement?.dataset.uiPageName
      || frameDocument.body?.dataset.uiPageName
      || frameDocument.querySelector('[data-ui-page-name]')?.dataset.uiPageName;
    const title = String(explicit || frameDocument.title || '').trim();
    return {
      label:title.replace(/\s*[·|｜-]\s*UI Studio.*$/i, '').slice(0, 36) || '导入页面',
      mode:nodes.length ? 'generated-page' : 'identity-missing',
    };
  }

  function viewAncestorIds(viewNodes, id) {
    const byId = new Map(viewNodes.map((node) => [node.id, node]));
    const result = [];
    let cursor = byId.get(id)?.viewParentId;
    while (cursor) { result.push(cursor); cursor = byId.get(cursor)?.viewParentId; }
    return result;
  }

  function viewDescendantIds(viewNodes, parentId) {
    const result = new Set();
    let changed = true;
    while (changed) {
      changed = false;
      viewNodes.forEach((node) => {
        if (!result.has(node.id) && (node.viewParentId === parentId || result.has(node.viewParentId))) { result.add(node.id); changed = true; }
      });
    }
    return result;
  }

  function layerActionIcon(name) {
    const paths = {
      visible:'<path d="M2.5 12s3.5-5 9.5-5 9.5 5 9.5 5-3.5 5-9.5 5-9.5-5-9.5-5Z"/><circle cx="12" cy="12" r="2.5"/>',
      hidden:'<path d="m3 3 18 18"/><path d="M10.6 7.1A10.8 10.8 0 0 1 12 7c6 0 9.5 5 9.5 5a15 15 0 0 1-2.2 2.6M6.2 6.2C3.8 7.7 2.5 12 2.5 12s3.5 5 9.5 5c1.2 0 2.3-.2 3.3-.5"/><path d="M10.2 10.2a2.5 2.5 0 0 0 3.6 3.6"/>',
      unlocked:'<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7.5a4 4 0 0 1 7.5-2"/>',
      locked:'<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
      inherited:'<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><path d="M12 13v4"/>',
    };
    return `<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${paths[name] || ''}</svg>`;
  }

  function renderLayers(filter = '') {
    const container = $('#layers');
    const contextLabel = $('#layer-tree-context');
    const status = $('#layer-selection-status');
    const pageEntries = discoveredPageEntries();
    if (renderPageDirectory(pageEntries)) {
      container.hidden = true;
      container.replaceChildren();
      if (contextLabel) {
        contextLabel.textContent = '项目菜单';
        contextLabel.dataset.mode = 'page-directory';
        contextLabel.title = '单击切换真实 UI；双击菜单或点击右侧层数，原位展开真实图层';
      }
      if (activeFeature === 'layers') $('#layer-count').textContent = `${pageEntries.length} 菜单`;
      if (status) {
        status.textContent = `${pageEntries.length} 个菜单 · 单击切换 · 双击展开图层`;
        status.title = '页面切换不会移动中间画布';
      }
      return;
    }
    container.hidden = false;
    const fragment = document.createDocumentFragment();
    const selection = new Set(activeSelectionIds());
    const selectedDescendants = new Set();
    selection.forEach((id) => descendantIds(id).forEach((descendantId) => {
      if (!selection.has(descendantId)) selectedDescendants.add(descendantId);
    }));
    const query = filter.trim().toLowerCase();
    const allViewNodes = structureViewNodes();
    let viewNodes = allViewNodes;
    const activeEntry = activePageEntry(pageEntries);
    if (activeEntry && allViewNodes.some((node) => node.id === activeEntry.id)) {
      const keep = new Set([activeEntry.id, ...viewDescendantIds(allViewNodes, activeEntry.id)]);
      const depthBase = allViewNodes.find((node) => node.id === activeEntry.id)?.viewDepth || 0;
      viewNodes = allViewNodes
        .filter((node) => keep.has(node.id))
        .map((node) => ({
          ...node,
          viewDepth:Math.max(0, node.viewDepth - depthBase),
          viewParentId:keep.has(node.viewParentId) ? node.viewParentId : null,
        }));
    }
    const queryMatches = new Set(viewNodes.filter((node) => `${node.id} ${node.viewLabel || labelFor(node.id)}`.toLowerCase().includes(query)).map((node) => node.id));
    if (query) [...queryMatches].forEach((id) => viewAncestorIds(viewNodes, id).forEach((ancestorId) => queryMatches.add(ancestorId)));
    const typeMatches = new Set(viewNodes.filter((node) => nodeMatchesFilter(node, layerFilter)).map((node) => node.id));
    if (layerFilter !== 'all') [...typeMatches].forEach((id) => viewAncestorIds(viewNodes, id).forEach((ancestorId) => typeMatches.add(ancestorId)));
    const visibleNodes = viewNodes.filter((node) => {
      const matchesQuery = !query || queryMatches.has(node.id);
      const matchesType = nodeMatchesFilter(node, layerFilter);
      const visibleByType = layerFilter === 'all' || matchesType || typeMatches.has(node.id);
      const visibleInTree = query || layerFilter !== 'all' || !viewAncestorIds(viewNodes, node.id).some((id) => collapsedNodes.has(id));
      return matchesQuery && visibleByType && visibleInTree;
    });
    if (activeFeature === 'layers') $('#layer-count').textContent = layerFilter === 'all' && !query ? nodes.length : `${visibleNodes.length}/${viewNodes.length}`;
    const pageContext = currentPageContext();
    if (contextLabel) {
      contextLabel.textContent = pageContext.mode === 'identity-missing'
        ? '当前页面 · 缺少可编辑身份'
        : `项目菜单 · ${pageContext.label} 图层`;
      contextLabel.dataset.mode = pageContext.mode;
      contextLabel.title = pageContext.mode === 'identity-missing'
        ? '当前预览没有 data-ui-id，需重新运行 Studio 导入器'
        : `正在编辑 ${pageContext.label} 的真实 DOM 图层`;
    }
    visibleNodes.forEach((node) => {
      const row = document.createElement('div');
      row.className = `layer-row${node.id === selectedId ? ' selected' : selection.has(node.id) ? ' multi-selected' : selectedDescendants.has(node.id) ? ' group-selected' : ''}${node.route ? ' route-row' : ''}${node.route?.active ? ' bound' : node.route?.bound ? ' available' : node.route ? ' unbound' : ''}${node.shared ? ' shared-row' : ''}`;
      row.dataset.id = node.id;
      row.style.paddingLeft = `${5 + Math.min(node.viewDepth, 7) * 11}px`;
      row.setAttribute('role', 'treeitem');
      const textTag = ['span','strong','small','b','h1','h2','label'].includes(node.tag);
      const kind = node.route ? '▦' : node.tag === 'svg' ? '◆' : textTag ? 'T' : node.tag === 'button' ? '▣' : node.tag === 'aside' || node.tag === 'nav' ? '▤' : '◇';
      const childCount = viewDescendantIds(viewNodes, node.id).size;
      const disclosure = childCount ? `<button class="tree-disclosure" type="button" title="展开/收起图层组" aria-label="${collapsedNodes.has(node.id) ? '展开' : '收起'} ${node.viewLabel || labelFor(node.id)}">${collapsedNodes.has(node.id) ? '▸' : '▾'}</button>` : `<span class="kind" aria-hidden="true">${kind}</span>`;
      const inheritedLock = isEffectivelyLocked(node.id) && !locks.has(node.id);
      const routeStatus = node.routeStatus ? `<small class="route-status">${node.routeStatus}</small>` : '';
      const role = !node.routeStatus && node.viewRole ? `<small class="node-role">${node.viewRole}</small>` : '';
      const isHidden = overrides[node.id]?.display === 'none';
      const isOwnLocked = locks.has(node.id);
      const layerLabel = node.viewLabel || labelFor(node.id);
      const visibilityAction = `<button class="mini visibility${isHidden ? ' active' : ''}" type="button" data-state="${isHidden ? 'hidden' : 'visible'}" title="${isHidden ? `显示 ${layerLabel}` : `隐藏 ${layerLabel}`}" aria-label="${isHidden ? '显示' : '隐藏'} ${layerLabel}" aria-pressed="${isHidden}">${layerActionIcon(isHidden ? 'hidden' : 'visible')}</button>`;
      const lockAction = `<button class="mini lock${isEffectivelyLocked(node.id) ? ' active' : ''}" type="button" data-state="${inheritedLock ? 'inherited' : isOwnLocked ? 'locked' : 'unlocked'}" title="${inheritedLock ? '由父级图层锁定' : isOwnLocked ? `解锁 ${layerLabel}` : `锁定 ${layerLabel}`}" aria-label="${inheritedLock ? '由父级锁定' : isOwnLocked ? '解锁' : '锁定'} ${layerLabel}" aria-pressed="${isEffectivelyLocked(node.id)}" ${inheritedLock ? 'disabled' : ''}>${layerActionIcon(inheritedLock ? 'inherited' : isOwnLocked ? 'locked' : 'unlocked')}</button>`;
      row.innerHTML = `${disclosure}<span class="name">${layerLabel}${childCount ? `<small class="child-count">${childCount}</small>` : ''}${role}${routeStatus}</span><span class="layer-row-actions" role="group" aria-label="${layerLabel} 图层操作">${visibilityAction}${lockAction}</span>`;
      row.addEventListener('click', (event) => {
        if (event.target.closest('.tree-disclosure')) { toggleTreeGroup(node.id, event.altKey); return; }
        if (event.target.closest('.visibility')) { toggleVisibility(node.id); return; }
        if (event.target.closest('.lock')) { toggleLock(node.id); return; }
        if (node.route) {
          structureViewNodes().filter((item) => item.route).forEach((item) => collapsedNodes.add(item.id));
          const currentViewNodes = structureViewNodes();
          viewDescendantIds(currentViewNodes, node.id).forEach((targetId) => {
            if (viewDescendantIds(currentViewNodes, targetId).size) collapsedNodes.add(targetId);
          });
          collapsedNodes.delete(node.id);
          collapsedNodes.delete('sidebar.navigation');
          localStorage.setItem(TREE_STATE_KEY, JSON.stringify([...collapsedNodes]));
        }
        select(node.id, { toggle:event.shiftKey });
        if (node.route) {
          if (!node.route.bound) showToast(`${node.viewLabel}尚未绑定页面；可先编辑菜单本身，或为它补充目标页面`);
          else if (!node.route.active) showToast(`已展开 ${node.viewLabel} · 双击可进入该页面`);
        }
      });
      row.addEventListener('dblclick', (event) => {
        if (event.target.closest('button')) return;
        if (node.route) { event.preventDefault(); activatePageRoute(node.route); return; }
        if (childCount) toggleTreeGroup(node.id, event.altKey);
      });
      fragment.append(row);
    });
    container.replaceChildren(fragment);
    if (status) {
      const selectionIds = activeSelectionIds();
      status.textContent = selectionIds.length > 1 ? `${selectionIds.length} 个对象已选择 · Shift 继续选择` : selectedId ? `${labelFor(selectedId)} · 已选择` : `${visibleNodes.length} 个可见图层`;
      status.title = selectionIds.join(', ');
    }
    if (selectedId) requestAnimationFrame(() => container.querySelector(`.layer-row[data-id="${CSS.escape(selectedId)}"]`)?.scrollIntoView({ block:'nearest' }));
  }

  function featureNodes(feature) {
    if (!frameDocument) return [];
    if (feature === 'menus') return nodes.filter((node) => node.id === 'sidebar.navigation' || /^sidebar\.nav\.[^.]+$/.test(node.id));
    if (feature === 'icons') return nodes.filter((node) => node.tag === 'svg');
    if (feature === 'text') return nodes.filter((node) => isTextElement(frameDocument.querySelector(`[data-ui-id="${CSS.escape(node.id)}"]`)));
    if (feature === 'frames') return nodes.filter((node) => {
      const element = frameDocument.querySelector(`[data-ui-id="${CSS.escape(node.id)}"]`);
      if (!element || isTextElement(element) || node.tag === 'svg' || node.id === 'app.shell') return false;
      return ['aside','nav','main','section','article','form','button','input','textarea','select'].includes(node.tag) || descendantIds(node.id).size > 1;
    });
    return [];
  }

  function cloneIconForPreview(element) {
    const cloneSvg = element.cloneNode(true);
    cloneSvg.removeAttribute('style');
    cloneSvg.removeAttribute('data-ui-id');
    cloneSvg.querySelectorAll('use').forEach((use) => {
      const href = use.getAttribute('href') || use.getAttribute('xlink:href') || '';
      const source = href.startsWith('#') ? frameDocument.querySelector(href) : null;
      if (!source) return;
      const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      [...source.children].forEach((child) => group.append(child.cloneNode(true)));
      use.replaceWith(group);
      if (!cloneSvg.getAttribute('viewBox')) cloneSvg.setAttribute('viewBox', source.getAttribute('viewBox') || '0 0 24 24');
      cloneSvg.dataset.expandedSprite = 'true';
    });
    if (!cloneSvg.getAttribute('viewBox')) cloneSvg.setAttribute('viewBox', '0 0 24 24');
    return cloneSvg;
  }

  function featureGlyph(feature, element) {
    if (feature === 'icons' && element?.tagName.toLowerCase() === 'svg') return cloneIconForPreview(element);
    const glyph = document.createElement('span');
    glyph.textContent = feature === 'menus' ? '☷' : feature === 'text' ? 'T' : '□';
    return glyph;
  }

  function saveFeatureState() {
    localStorage.setItem(FEATURE_STATE_KEY, JSON.stringify(featureState));
  }

  function featureHumanContext(feature, node, element) {
    if (feature === 'text') {
      const content = String(element?.textContent || '').replace(/\s+/g, ' ').trim();
      return content && content !== labelFor(node.id) ? `“${content.slice(0, 42)}${content.length > 42 ? '…' : ''}”` : '文字内容';
    }
    if (feature === 'icons') return node.parentId ? `位于 ${labelFor(node.parentId)}` : '独立图标';
    const typeLabel = { button:'按钮', input:'输入框', textarea:'文本域', select:'选择器', aside:'侧栏', nav:'导航', main:'主区域', section:'区块', article:'卡片', form:'表单' }[node.tag] || '容器';
    return node.parentId ? `${typeLabel} · ${labelFor(node.parentId)}` : typeLabel;
  }

  function clearFeatureCanvasHover() {
    if (featureHoverElement) featureHoverElement.removeAttribute('data-ui-studio-list-hover');
    featureHoverElement = null;
  }

  function showFeatureCanvasHover(id) {
    clearFeatureCanvasHover();
    const element = frameDocument?.querySelector(`[data-ui-id="${CSS.escape(id)}"]`);
    if (!element) return;
    featureHoverElement = element;
    element.dataset.uiStudioListHover = 'true';
    syncLayerHover(id);
  }

  function renderFeatureObjectList(feature, containerId) {
    const container = $(containerId);
    if (!container) return;
    const fragment = document.createDocumentFragment();
    const query = String($(`[data-feature-search="${feature}"]`)?.value || '').trim().toLowerCase();
    featureNodes(feature).filter((node) => {
      const element = frameDocument.querySelector(`[data-ui-id="${CSS.escape(node.id)}"]`);
      return !query || `${labelFor(node.id)} ${node.id} ${node.tag} ${element?.textContent || ''}`.toLowerCase().includes(query);
    }).forEach((node) => {
      const element = frameDocument.querySelector(`[data-ui-id="${CSS.escape(node.id)}"]`);
      const row = document.createElement('button');
      row.type = 'button';
      row.className = `feature-object-row${node.id === selectedId ? ' active' : selectedIds.has(node.id) ? ' multi-selected' : ''}`;
      row.dataset.featureObject = node.id;
      const icon = document.createElement('i');
      icon.append(featureGlyph(feature, element));
      const copy = document.createElement('span');
      const name = document.createElement('b');
      name.textContent = labelFor(node.id);
      const context = document.createElement('small');
      context.dataset.humanContext = '';
      context.textContent = featureHumanContext(feature, node, element);
      const id = document.createElement('code');
      id.textContent = node.id;
      copy.append(name, context, id);
      const tag = document.createElement('em');
      tag.textContent = node.tag;
      row.append(icon, copy, tag);
      row.title = `${labelFor(node.id)} · ${node.id}`;
      row.addEventListener('click', (event) => {
        select(node.id, { toggle:event.shiftKey });
        focusSelectedInCanvas();
      });
      row.addEventListener('pointerenter', () => showFeatureCanvasHover(node.id));
      row.addEventListener('pointerleave', () => { clearFeatureCanvasHover(); syncLayerHover(); });
      fragment.append(row);
    });
    container.replaceChildren(fragment);
  }

  function renderFeatureObjectLists() {
    renderFeatureObjectList('icons', '#feature-icon-list');
    renderFeatureObjectList('text', '#feature-text-list');
    renderFeatureObjectList('frames', '#feature-frame-list');
  }

  function syncFeatureObjectSelection() {
    $$('.feature-object-row').forEach((row) => {
      row.classList.toggle('active', row.dataset.featureObject === selectedId);
      row.classList.toggle('multi-selected', row.dataset.featureObject !== selectedId && selectedIds.has(row.dataset.featureObject));
    });
    const activeRow = $(`.feature-panel.active .feature-object-row[data-feature-object="${CSS.escape(selectedId || '')}"]`);
    if (activeRow) requestAnimationFrame(() => activeRow.scrollIntoView({ block:'nearest' }));
  }

  function updateFeatureCount() {
    const pageEntries = activeFeature === 'layers' ? discoveredPageEntries() : [];
    const activeEntry = activeFeature === 'layers' ? activePageEntry(pageEntries) : null;
    const count = activeFeature === 'layers'
      ? pageEntries.length
        ? expandedPageKey && activeEntry ? `${pageEntries.length} 菜单 · ${knownPageLayerCount(activeEntry) || nodes.length} 层` : `${pageEntries.length} 菜单`
        : nodes.length
      : featureNodes(activeFeature).length;
    $('#layer-count').textContent = ['recognize','compare','export'].includes(activeFeature) ? '工具' : count;
  }

  function featureDefaultNode(feature) {
    const candidates = featureNodes(feature);
    if (!candidates.length) return null;
    const remembered = featureState.selections?.[feature];
    if (remembered && candidates.some((node) => node.id === remembered)) return remembered;
    if (candidates.some((node) => node.id === selectedId)) return selectedId;
    const iconTarget = feature === 'icons' ? resolveSelectedSvgTarget() : null;
    if (iconTarget && candidates.some((node) => node.id === iconTarget.id)) return iconTarget.id;
    const selectedAncestors = selectedId ? [selectedId, ...ancestorIds(selectedId)] : [];
    const ancestor = selectedAncestors.find((id) => candidates.some((node) => node.id === id));
    if (ancestor) return ancestor;
    const selectedChildren = selectedId ? descendantIds(selectedId) : new Set();
    const child = candidates.find((node) => selectedChildren.has(node.id));
    if (child) return child.id;
    const preferred = feature === 'menus' ? 'sidebar.navigation' : feature === 'frames' ? 'controls.reference' : '';
    return candidates.find((node) => node.id === preferred)?.id || candidates[0].id;
  }

  function focusSelectedInCanvas(options = {}) {
    const rect = selectionUnionRect();
    if (!rect) return;
    const canvas = $('#canvas-viewport');
    const targetLeft = stage.offsetLeft + (rect.left + rect.width / 2) * zoom - canvas.clientWidth / 2;
    const targetTop = stage.offsetTop + (rect.top + rect.height / 2) * zoom - canvas.clientHeight / 2;
    animateCameraTo(targetLeft, targetTop, {
      animate: options.animate !== false,
      action: options.action || '定位图层',
    });
  }

  function applyReferenceViewState({ persist = true } = {}) {
    const { visible, layer, strength } = referenceViewState;
    const below = layer === 'below';
    overlayImage.classList.toggle('visible', visible);
    transform.classList.toggle('reference-below', below);
    overlayImage.style.opacity = visible ? (below ? '1' : String(strength / 100)) : '0';
    frame.style.opacity = visible && below ? String(Math.max(.1, 1 - strength / 100)) : '1';
    const visibility = $('#reference-visible');
    if (visibility) visibility.checked = visible;
    const layerFieldset = $('#reference-layer-fieldset');
    if (layerFieldset) layerFieldset.disabled = !visible;
    const strengthInput = $('#reference-opacity');
    if (strengthInput) {
      strengthInput.disabled = !visible;
      strengthInput.value = strength;
    }
    $('#reference-opacity-value').textContent = `${Math.round(strength)}%`;
    $('#reference-visibility-status').textContent = visible ? '已显示' : '已隐藏';
    $('#reference-layer-value').textContent = below ? 'UI 在原图上方' : '原图在 UI 上方';
    $('#reference-layer-help').textContent = below
      ? 'UI 覆盖在原图上方并自动降低画布不透明度，适合检查边缘和留白。'
      : '原图覆盖在 UI 上方，适合检查位置、尺寸和间距。';
    $$('[data-reference-layer]').forEach((button) => {
      const active = button.dataset.referenceLayer === layer;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    $('.compare-menu')?.classList.toggle('reference-visible', visible);
    $('.compare-menu > summary')?.setAttribute('aria-label', visible
      ? `参考图已显示，${below ? 'UI 在上' : '原图在上'}，可见度 ${Math.round(strength)}%`
      : '参考图已隐藏');
    if (persist) localStorage.setItem(REFERENCE_VIEW_KEY, JSON.stringify(referenceViewState));
    refreshReferenceContext();
  }

  function setReferenceVisible(visible) {
    referenceViewState.visible = Boolean(visible);
    applyReferenceViewState();
  }

  function setReferenceLayer(layer) {
    referenceViewState.layer = layer === 'below' ? 'below' : 'above';
    applyReferenceViewState();
  }

  function setReferenceStrength(strength) {
    referenceViewState.strength = Math.max(10, Math.min(90, number(strength, 45)));
    applyReferenceViewState();
  }

  function refreshReferenceContext() {
    const visible = referenceViewState.visible;
    const opacity = Math.round(referenceViewState.strength);
    const summary = $('#feature-reference-summary');
    if (summary) summary.textContent = `${visible ? '已显示' : '已隐藏'} · ${referenceViewState.layer === 'below' ? 'UI 在原图上方' : '原图在 UI 上方'} · ${opacity}%`;
  }

  function openReferenceControl() {
    const menu = $('.compare-menu');
    if (!menu) return;
    $$('[data-toolbar-menu]').forEach((other) => { if (other !== menu) other.open = false; });
    menu.open = true;
    requestAnimationFrame(() => $('#reference-visible')?.focus({ preventScroll:true }));
  }

  function selectionTypeFor(element = selectedElement()) {
    if (!element) return 'none';
    const tag = element.tagName.toLowerCase();
    if (tag === 'svg') return 'icon';
    if (isTextElement(element)) return 'text';
    if (['button','input','textarea','select'].includes(tag)) return 'control';
    return 'frame';
  }

  function humanSelectionKind(type = selectionTypeFor()) {
    return { icon:'图标', text:'文字', control:'控件', frame:'容器', none:'未选择' }[type] || '对象';
  }

  function selectionBreadcrumb(id = selectedId) {
    if (!id) return '—';
    return [...ancestorIds(id)].reverse().slice(-2).map(labelFor).concat(labelFor(id)).join(' / ');
  }

  function configureInspectorForSelection() {
    const inspector = $('#inspector');
    const element = selectedElement();
    if (!inspector || !element) return;
    const type = selectionTypeFor(element);
    const typeChanged = inspector.dataset.selectionType !== type;
    inspector.dataset.selectionType = type;
    $('#selection-kind').textContent = humanSelectionKind(type);
    $('#selection-tag').textContent = element.tagName.toLowerCase();
    $('#selection-path').textContent = selectionBreadcrumb();
    $('#prop-color-label').textContent = type === 'text' ? '文字颜色' : type === 'icon' ? '图标颜色' : '前景颜色';
    $('#inspector-locate-selection').hidden = false;
    if (!typeChanged) return;
    $('#geometry-section').open = type === 'frame' || type === 'control';
    $('#appearance-section').open = true;
    $('#effects-section').open = false;
    $('#quick-section').open = false;
    $('#layout-section').open = type === 'frame' || type === 'control';
    $('#developer-section').open = false;
    if (type === 'text') $('#text-system').open = true;
  }

  function updateMultiInspector() {
    const ids = activeSelectionIds();
    const list = $('#multi-selection-list');
    if (!list || ids.length < 2) return;
    $('#multi-selection-title').textContent = `已选择 ${ids.length} 个对象`;
    list.replaceChildren(...ids.map((id) => {
      const element = frameDocument?.querySelector(`[data-ui-id="${CSS.escape(id)}"]`);
      const row = document.createElement('button');
      row.type = 'button';
      row.className = `multi-selection-item${id === selectedId ? ' primary' : ''}`;
      row.dataset.multiSelectionId = id;
      const kind = humanSelectionKind(selectionTypeFor(element));
      row.innerHTML = `<i>${kind === '文字' ? 'T' : kind === '图标' ? '◆' : kind === '控件' ? '▣' : '◇'}</i><span><b></b><small>${kind}${isEffectivelyLocked(id) ? ' · 已锁定' : ''}</small></span><em>移除</em>`;
      $('b', row).textContent = labelFor(id);
      row.addEventListener('click', () => select(id, { toggle:true }));
      return row;
    }));
    const canDistribute = ids.filter((id) => !isEffectivelyLocked(id)).length >= 3;
    $$('[data-multi-action^="distribute-"]', $('#multi-inspector')).forEach((button) => {
      button.disabled = !canDistribute;
      button.title = canDistribute ? '' : '至少需要 3 个未锁定对象';
    });
  }

  function updateContextInspector() {
    const dedicated = activeFeature === 'recognize' || activeFeature === 'compare' || activeFeature === 'export';
    const hasSelection = Boolean(selectedId && frameDocument);
    const multiSelection = hasSelection && hasMultiSelection();
    $('#inspector-heading').textContent = FEATURE_META[activeFeature]?.inspector || '属性';
    $('#feature-inspector').hidden = !dedicated;
    $$('[data-feature-inspector]').forEach((panel) => { panel.hidden = panel.dataset.featureInspector !== activeFeature; });
    $('#empty-inspector').hidden = dedicated || hasSelection;
    $('#multi-inspector').hidden = dedicated || !multiSelection;
    $('#inspector').hidden = dedicated || !hasSelection || multiSelection;
    $('#inspector').classList.toggle('feature-text', activeFeature === 'text');

    const target = activeFeature === 'icons' ? resolveSelectedSvgTarget() : null;
    $('#icon-context-actions').hidden = !target;
    if (target) {
      const preview = $('#selected-icon-preview');
      const cloneSvg = cloneIconForPreview(target.element);
      cloneSvg.setAttribute('aria-hidden', 'true');
      preview.replaceChildren(cloneSvg);
      $('#selected-icon-name').textContent = target.name;
      $('#selected-icon-context').textContent = `位于 ${selectionBreadcrumb(target.id).split(' / ').slice(0, -1).join(' / ') || '当前页面'}`;
      $('#feature-restore-icon').disabled = !iconReplacements[target.id];
    }
    $('#inspector-locate-selection').hidden = dedicated || !hasSelection;
    if (dedicated) $('#selection-kind').textContent = '工具';
    else if (!hasSelection) $('#selection-kind').textContent = '未选择';
    else if (multiSelection) {
      $('#inspector-heading').textContent = '批量排列';
      $('#selection-kind').textContent = `${activeSelectionIds().length} 个对象`;
      updateMultiInspector();
    }
    else configureInspectorForSelection();
    if (activeFeature === 'compare') refreshReferenceContext();
  }

  function featureScrollContainer(feature) {
    const panel = $(`[data-feature-panel="${feature}"]`);
    return panel?.querySelector('.feature-object-list, .analysis-candidate-list, .fidelity-mismatch-list, .layers') || panel;
  }

  function activateFeature(feature, autoSelect = true, options = {}) {
    if (!FEATURE_META[feature]) return;
    const previousFeature = activeFeature;
    const camera = options.cameraSnapshot || (!isDedicatedFeature(previousFeature) ? captureCanvasCamera() : parkedFeatureCamera);
    canvasAutoFitSuspended += 1;
    const previousScroller = featureScrollContainer(previousFeature);
    featureState.scroll ||= {};
    if (previousScroller) featureState.scroll[previousFeature] = previousScroller.scrollTop;
    clearFeatureCanvasHover();
    activeFeature = feature;
    $$('[data-feature]').forEach((button) => button.classList.toggle('active', button.dataset.feature === feature));
    $$('[data-feature-panel]').forEach((panel) => {
      const active = panel.dataset.featurePanel === feature;
      panel.hidden = !active;
      panel.classList.toggle('active', active);
    });
    $('#feature-title').textContent = FEATURE_META[feature].title;
    $('#feature-subtitle').textContent = FEATURE_META[feature].subtitle;
    $('.feature-workspace').classList.toggle('show-feature-dev', Boolean(featureState.showDeveloper));
    $$('[data-feature-dev-toggle]').forEach((button) => button.setAttribute('aria-pressed', String(Boolean(featureState.showDeveloper))));
    if (autoSelect && !['layers','recognize','compare','export'].includes(feature)) {
      const target = featureDefaultNode(feature);
      if (target) select(target);
    }
    updateFeatureCount();
    syncFeatureObjectSelection();
    updateContextInspector();
    renderStatusBar();
    const dedicatedWorkspace = isDedicatedFeature(feature);
    if (selectionBox) selectionBox.hidden = dedicatedWorkspace || !selectedId;
    if (!dedicatedWorkspace && selectedId) requestAnimationFrame(drawSelection);
    requestAnimationFrame(() => {
      const nextScroller = featureScrollContainer(feature);
      if (nextScroller) nextScroller.scrollTop = Number(featureState.scroll?.[feature] || 0);
    });
    saveFeatureState();
    window.dispatchEvent(new CustomEvent('ui-studio-featurechange', { detail:{ feature } }));
    preserveCameraAfterFeatureSwitch(camera, feature);
  }

  function syncLayerHover(id = null) {
    $$('.layer-row.hover-linked').forEach((row) => row.classList.remove('hover-linked'));
    if (!id) return;
    $('#layers').querySelector(`.layer-row[data-id="${CSS.escape(id)}"]`)?.classList.add('hover-linked');
  }

  function syncCanvasHover(element = null) {
    if (canvasHoverElement && canvasHoverElement !== element) canvasHoverElement.removeAttribute('data-ui-studio-canvas-hover');
    canvasHoverElement = element || null;
    if (canvasHoverElement) canvasHoverElement.dataset.uiStudioCanvasHover = 'true';
  }

  function descendantIds(parentId) {
    const result = new Set();
    let changed = true;
    while (changed) {
      changed = false;
      nodes.forEach((node) => {
        if (!result.has(node.id) && (node.parentId === parentId || result.has(node.parentId))) { result.add(node.id); changed = true; }
      });
    }
    return result;
  }

  function ancestorIds(id) {
    const result = [];
    let cursor = nodes.find((node) => node.id === id)?.parentId;
    while (cursor) { result.push(cursor); cursor = nodes.find((node) => node.id === cursor)?.parentId; }
    return result;
  }

  function isEffectivelyLocked(id) {
    return locks.has(id) || ancestorIds(id).some((ancestorId) => locks.has(ancestorId));
  }

  function toggleTreeGroup(id, recursive = false) {
    const collapse = !collapsedNodes.has(id);
    const viewNodes = structureViewNodes();
    const targets = recursive
      ? [id, ...viewDescendantIds(viewNodes, id)].filter((targetId) => viewDescendantIds(viewNodes, targetId).size)
      : [id];
    targets.forEach((targetId) => collapse ? collapsedNodes.add(targetId) : collapsedNodes.delete(targetId));
    localStorage.setItem(TREE_STATE_KEY, JSON.stringify([...collapsedNodes]));
    renderLayers($('#layer-search').value);
  }

  function select(id, options = {}) {
    if (!nodes.some((node) => node.id === id)) return;
    syncCanvasHover();
    viewAncestorIds(structureViewNodes(), id).forEach((ancestorId) => collapsedNodes.delete(ancestorId));
    localStorage.setItem(TREE_STATE_KEY, JSON.stringify([...collapsedNodes]));
    if (options.toggle) {
      if (selectedIds.has(id)) {
        selectedIds.delete(id);
        if (!selectedIds.size) { clearSelection(); return; }
        selectedId = [...selectedIds].at(-1);
      } else {
        const relatedIds = new Set([id, ...ancestorIds(id), ...descendantIds(id)]);
        [...selectedIds].forEach((currentId) => {
          if (relatedIds.has(currentId)) selectedIds.delete(currentId);
        });
        selectedIds.add(id);
        selectedId = id;
      }
    } else {
      selectedIds = new Set([id]);
      selectedId = id;
    }
    featureState.selections ||= {};
    featureState.selections[activeFeature] = selectedId;
    saveFeatureState();
    renderLayers($('#layer-search').value);
    $('#empty-inspector').hidden = true;
    const childCount = descendantIds(selectedId).size;
    $('#selection-name').textContent = labelFor(selectedId);
    $('#selection-id').textContent = selectedId;
    $('#selection-path').textContent = `${selectionBreadcrumb(selectedId)}${childCount ? ` · 整组 ${childCount + 1} 层` : ''}`;
    if (!hasMultiSelection()) updateInspector();
    drawSelection();
    syncFeatureObjectSelection();
    updateContextInspector();
    if ($('#icon-tool-dialog')?.open) updateIconToolTarget();
    renderStatusBar();
  }

  function clearSelection() {
    syncCanvasHover();
    selectedId = null;
    selectedIds.clear();
    syncCanvasSelectionMarkers();
    if (selectionBox) selectionBox.hidden = true;
    $('#inspector').hidden = true;
    $('#multi-inspector').hidden = true;
    $('#empty-inspector').hidden = false;
    $('#selection-kind').textContent = '未选择';
    $('#inspector-locate-selection').hidden = true;
    renderLayers($('#layer-search').value);
    syncFeatureObjectSelection();
    updateContextInspector();
    hideSnapFeedback();
    if ($('#icon-tool-dialog')?.open) updateIconToolTarget();
    renderStatusBar();
  }

  function beginMarqueeSelection(event) {
    if (event.button !== 0 || !frameDocument) return false;
    const startX = event.clientX;
    const startY = event.clientY;
    const marquee = frameDocument.createElement('div');
    marquee.className = 'ui-studio-marquee';
    frameDocument.body.append(marquee);
    let active = false;
    const update = (moveEvent) => {
      if (moveEvent.pointerId !== event.pointerId) return;
      const left = Math.min(startX, moveEvent.clientX);
      const top = Math.min(startY, moveEvent.clientY);
      const width = Math.abs(moveEvent.clientX - startX);
      const height = Math.abs(moveEvent.clientY - startY);
      if (!active && Math.hypot(width, height) < 4) return;
      active = true;
      marquee.style.display = 'block';
      Object.assign(marquee.style, { left:`${left}px`, top:`${top}px`, width:`${width}px`, height:`${height}px` });
    };
    const finish = (endEvent) => {
      if (endEvent.pointerId !== event.pointerId) return;
      frameDocument.removeEventListener('pointermove', update, true);
      frameDocument.removeEventListener('pointerup', finish, true);
      frameDocument.removeEventListener('pointercancel', cancel, true);
      marquee.remove();
      if (!active) return;
      suppressCanvasClick = true;
      const selectionRect = {
        left:Math.min(startX, endEvent.clientX), top:Math.min(startY, endEvent.clientY),
        right:Math.max(startX, endEvent.clientX), bottom:Math.max(startY, endEvent.clientY),
      };
      let ids = nodes.filter((node) => node.id !== 'app.shell' && overrides[node.id]?.display !== 'none').filter((node) => {
        const element = frameDocument.querySelector(`[data-ui-id="${CSS.escape(node.id)}"]`);
        if (!element) return false;
        const rect = element.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && rect.right >= selectionRect.left && rect.left <= selectionRect.right && rect.bottom >= selectionRect.top && rect.top <= selectionRect.bottom;
      }).map((node) => node.id);
      if (selectionScope === 'whole') ids = ['app.shell'];
      else if (selectionScope === 'section') ids = [...new Set(ids.map((id) => scopedElement(frameDocument.querySelector(`[data-ui-id="${CSS.escape(id)}"]`))?.dataset.uiId).filter(Boolean))];
      else {
        const candidateSet = new Set(ids);
        ids = ids.filter((id) => !ids.some((otherId) => otherId !== id && ancestorIds(otherId).includes(id) && candidateSet.has(otherId)));
      }
      if (!ids.length) { clearSelection(); showToast('框选区域内没有可编辑图层'); return; }
      selectedIds = new Set(ids);
      selectedId = ids.at(-1);
      ids.flatMap(ancestorIds).forEach((id) => collapsedNodes.delete(id));
      renderLayers($('#layer-search').value);
      updateContextInspector();
      syncFeatureObjectSelection();
      drawSelection();
      renderStatusBar();
      showToast(`已框选 ${ids.length} 个图层 · Shift+拖动可重新框选`);
    };
    const cancel = (cancelEvent) => {
      frameDocument.removeEventListener('pointermove', update, true);
      frameDocument.removeEventListener('pointerup', finish, true);
      frameDocument.removeEventListener('pointercancel', cancel, true);
      marquee.remove();
    };
    frameDocument.addEventListener('pointermove', update, true);
    frameDocument.addEventListener('pointerup', finish, true);
    frameDocument.addEventListener('pointercancel', cancel, true);
    return true;
  }

  function canvasRenderScale(frameRect = frame?.getBoundingClientRect()) {
    const frameWidth = Math.max(1, frame?.clientWidth || viewport.width || 1);
    const frameHeight = Math.max(1, frame?.clientHeight || viewport.height || 1);
    return {
      x: frameRect?.width ? frameRect.width / frameWidth : zoom,
      y: frameRect?.height ? frameRect.height / frameHeight : zoom,
    };
  }

  function manipulationAutoPanVelocity(position, min, max) {
    const edge = MANIPULATION_AUTO_PAN_EDGE;
    let strength = 0;
    let direction = 0;
    if (position < min + edge) {
      strength = Math.min(1, (min + edge - position) / edge);
      direction = -1;
    } else if (position > max - edge) {
      strength = Math.min(1, (position - (max - edge)) / edge);
      direction = 1;
    }
    if (!direction) return 0;
    return direction * Math.max(1, MANIPULATION_AUTO_PAN_MAX_SPEED * strength * strength);
  }

  let selectionMotionFrame = 0;
  let selectionRenderState = { x:NaN, y:NaN, width:NaN, height:NaN };
  function syncCanvasSelectionMarkers() {
    if (!frameDocument) return;
    const signature = [...selectedIds].sort().join('|');
    if (signature === selectionMarkerSignature) return;
    frameDocument.querySelectorAll('[data-ui-studio-selected="true"]').forEach((element) => element.removeAttribute('data-ui-studio-selected'));
    selectedIds.forEach((id) => frameDocument.querySelector(`[data-ui-id="${CSS.escape(id)}"]`)?.setAttribute('data-ui-studio-selected', 'true'));
    selectionMarkerSignature = signature;
  }
  function scheduleSelectionSync() {
    if (document.body.classList.contains('object-manipulating')) return;
    if (selectionMotionFrame) return;
    selectionMotionFrame = requestAnimationFrame(() => {
      selectionMotionFrame = 0;
      drawSelection();
    });
  }

  function offsetRectSnapshot(rect, dx = 0, dy = 0) {
    if (!rect) return null;
    return {
      left:rect.left + dx,
      top:rect.top + dy,
      right:rect.right + dx,
      bottom:rect.bottom + dy,
      width:rect.width,
      height:rect.height,
      entries:rect.entries,
    };
  }

  function selectionRenderContext() {
    const frameRect = frame.getBoundingClientRect();
    const canvasAreaRect = $('.canvas-area').getBoundingClientRect();
    return {
      frameRect:{ left:frameRect.left, top:frameRect.top, right:frameRect.right, bottom:frameRect.bottom, width:frameRect.width, height:frameRect.height },
      canvasAreaRect:{ left:canvasAreaRect.left, top:canvasAreaRect.top },
      renderScale:canvasRenderScale(frameRect),
    };
  }

  function positionSelectionOverlay(x, y, width, height) {
    if (!Number.isFinite(selectionRenderState.x) || !Number.isFinite(selectionRenderState.y)
      || Math.abs(x - selectionRenderState.x) > .01 || Math.abs(y - selectionRenderState.y) > .01) {
      selectionBox.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      selectionRenderState.x = x;
      selectionRenderState.y = y;
    }
    if (!Number.isFinite(selectionRenderState.width) || Math.abs(width - selectionRenderState.width) > .01) {
      selectionBox.style.width = `${width}px`;
      selectionRenderState.width = width;
    }
    if (!Number.isFinite(selectionRenderState.height) || Math.abs(height - selectionRenderState.height) > .01) {
      selectionBox.style.height = `${height}px`;
      selectionRenderState.height = height;
    }
  }

  function drawSelection(rectSnapshot = null, renderContext = null) {
    if (!selectionBox) return;
    if (isDedicatedFeature()) {
      selectionBox.hidden = true;
      syncCanvasSelectionMarkers();
      return;
    }
    syncCanvasSelectionMarkers();
    const finiteRect = rectSnapshot
      && ['left','top','right','bottom','width','height'].every((key) => Number.isFinite(Number(rectSnapshot[key])))
      && Number(rectSnapshot.width) >= 0 && Number(rectSnapshot.height) >= 0
      && Number(rectSnapshot.width) <= 1_000_000 && Number(rectSnapshot.height) <= 1_000_000;
    const rect = finiteRect ? rectSnapshot : selectionUnionRect();
    if (!rect) { selectionBox.hidden = true; return; }
    const context = renderContext || selectionRenderContext();
    const { frameRect, canvasAreaRect, renderScale } = context;
    selectionBox.hidden = false;
    const multiSelection = hasMultiSelection();
    selectionBox.dataset.multi = String(multiSelection);
    const childCount = multiSelection ? 0 : descendantIds(selectedId).size;
    selectionBox.dataset.label = multiSelection ? `${activeSelectionIds().length} 个对象` : `${labelFor(selectedId)}${childCount ? ` · 整组 ${childCount + 1} 层` : ''}${isEffectivelyLocked(selectedId) ? ' · 已锁定' : ''}`;
    selectionBox.dataset.size = `${Math.round(rect.width)} × ${Math.round(rect.height)}`;
    $('.ui-studio-move-grip', selectionBox).textContent = selectionBox.dataset.label;
    const top = frameRect.top - canvasAreaRect.top + rect.top * renderScale.y;
    const gestureActive = Boolean(selectionBox.dataset.gestureState);
    if (!gestureActive) {
      selectionBox.dataset.chrome = top < 44 ? 'inside' : 'outside';
      selectionBox.dataset.compact = String(rect.width * renderScale.x < 96 || rect.height * renderScale.y < 56);
    }
    positionSelectionOverlay(
      frameRect.left - canvasAreaRect.left + rect.left * renderScale.x,
      frameRect.top - canvasAreaRect.top + rect.top * renderScale.y,
      rect.width * renderScale.x,
      rect.height * renderScale.y,
    );
    if ($('#status-geometry')) $('#status-geometry').textContent = `X ${Math.round(rect.left)} · Y ${Math.round(rect.top)} · ${Math.round(rect.width)} × ${Math.round(rect.height)}`;
  }

  function applyOverride(id) {
    const element = frameDocument.querySelector(`[data-ui-id="${CSS.escape(id)}"]`);
    if (!element) return;
    const setStyle = (key, value) => element.style.setProperty(cssProperty(key), String(value), 'important');
    restoreBaseStyles(element, id);
    const value = overrides[id] || {};
    if (baseTexts.has(id)) element.textContent = value.textContent ?? baseTexts.get(id);
    const hasGeometryOverride = ['x','y','width','height','scale'].some((key) => value[key] !== undefined && value[key] !== '');
    if (hasGeometryOverride && getComputedStyle(element).display === 'inline') setStyle('display', 'inline-block');
    if (value.x || value.y) setStyle('translate', `${number(value.x)}px ${number(value.y)}px`);
    if (value.scale !== undefined && value.scale !== '') {
      setStyle('scale', number(value.scale, 1));
      setStyle('transformOrigin', 'top left');
    }
    if (value.rotation !== undefined && value.rotation !== '') setStyle('rotate', `${number(value.rotation)}deg`);
    ['width','height','fontSize','lineHeight','letterSpacing','borderRadius','borderWidth','padding'].forEach((key) => {
      if (value[key] !== undefined && value[key] !== '') setStyle(key, `${number(value[key])}px`);
    });
    ['backgroundColor','color','fontFamily','fontWeight','textAlign','borderColor','borderStyle','opacity','display','zIndex','position'].forEach((key) => {
      if (value[key] !== undefined && value[key] !== '') setStyle(key, value[key]);
    });
    if (['shadowX','shadowY','shadowBlur','shadowSpread','shadowColor'].some((key) => value[key] !== undefined && value[key] !== '')) {
      setStyle('boxShadow', `${number(value.shadowX)}px ${number(value.shadowY)}px ${Math.max(0,number(value.shadowBlur))}px ${number(value.shadowSpread)}px ${value.shadowColor || '#00000033'}`);
    }
  }

  function cssProperty(key) {
    return key.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
  }

  function captureBaseStyles(element, id) {
    if (!element || !id || baseStyles.has(id)) return;
    const styles = {};
    STYLE_KEYS.forEach((key) => {
      const property = cssProperty(key);
      styles[property] = {
        value: element.style.getPropertyValue(property),
        priority: element.style.getPropertyPriority(property),
      };
    });
    baseStyles.set(id, styles);
  }

  function restoreBaseStyles(element, id) {
    const styles = baseStyles.get(id) || {};
    STYLE_KEYS.forEach((key) => {
      const property = cssProperty(key);
      const baseline = styles[property];
      if (baseline?.value) element.style.setProperty(property, baseline.value, baseline.priority || '');
      else element.style.removeProperty(property);
    });
  }

  function applyLivePosition(id, x, y) {
    const element = frameDocument?.querySelector(`[data-ui-id="${CSS.escape(id)}"]`);
    if (!element) return;
    const nextX = Math.round(number(x) * 100) / 100;
    const nextY = Math.round(number(y) * 100) / 100;
    overrides[id] ||= {};
    if (nextX) overrides[id].x = nextX; else delete overrides[id].x;
    if (nextY) overrides[id].y = nextY; else delete overrides[id].y;
    if (!Object.keys(overrides[id]).length) delete overrides[id];
    if (nextX || nextY) element.style.setProperty('translate', `${nextX}px ${nextY}px`, 'important');
    else element.style.removeProperty('translate');
  }

  function liveGeometryValue(value) {
    return Math.round(number(value) * 100) / 100;
  }

  function predictedResizeRect(startRect, direction, width, height, centerResize = false) {
    const nextWidth = Math.max(1, number(width, startRect.width));
    const nextHeight = Math.max(1, number(height, startRect.height));
    const centerX = startRect.left + startRect.width / 2;
    const centerY = startRect.top + startRect.height / 2;
    const left = centerResize
      ? centerX - nextWidth / 2
      : direction.includes('w') ? startRect.right - nextWidth : startRect.left;
    const top = centerResize
      ? centerY - nextHeight / 2
      : direction.includes('n') ? startRect.bottom - nextHeight : startRect.top;
    return {
      left,
      top,
      right:left + nextWidth,
      bottom:top + nextHeight,
      width:nextWidth,
      height:nextHeight,
    };
  }

  function applyLiveResizeGeometry(id) {
    const element = frameDocument?.querySelector(`[data-ui-id="${CSS.escape(id)}"]`);
    if (!element) return;
    const value = overrides[id] || {};
    const nextX = number(value.x);
    const nextY = number(value.y);
    if (nextX || nextY) element.style.setProperty('translate', `${nextX}px ${nextY}px`, 'important');
    else element.style.removeProperty('translate');
    if (value.scale !== undefined && value.scale !== '') {
      element.style.setProperty('scale', String(number(value.scale, 1)), 'important');
      element.style.setProperty('transform-origin', 'top left', 'important');
    }
    if (value.width !== undefined && value.width !== '') element.style.setProperty('width', `${number(value.width)}px`, 'important');
    if (value.height !== undefined && value.height !== '') element.style.setProperty('height', `${number(value.height)}px`, 'important');
  }

  function stabilizeResizeAnchor(id, direction, startRect, centerResize = false) {
    const element = frameDocument?.querySelector(`[data-ui-id="${CSS.escape(id)}"]`);
    if (!element || !startRect) return null;
    const rect = element.getBoundingClientRect();
    let correctionX = 0;
    let correctionY = 0;
    if (direction.includes('e') || direction.includes('w')) {
      correctionX = centerResize
        ? startRect.left + startRect.width / 2 - (rect.left + rect.width / 2)
        : direction.includes('w') ? startRect.right - rect.right : startRect.left - rect.left;
    }
    if (direction.includes('s') || direction.includes('n')) {
      correctionY = centerResize
        ? startRect.top + startRect.height / 2 - (rect.top + rect.height / 2)
        : direction.includes('n') ? startRect.bottom - rect.bottom : startRect.top - rect.top;
    }
    if (Math.abs(correctionX) > .01) setValueForId(id, 'x', Math.round((number(overrides[id]?.x) + correctionX) * 100) / 100);
    if (Math.abs(correctionY) > .01) setValueForId(id, 'y', Math.round((number(overrides[id]?.y) + correctionY) * 100) / 100);
    if (Math.abs(correctionX) > .01 || Math.abs(correctionY) > .01) applyLiveResizeGeometry(id);
    return offsetRectSnapshot(rect, correctionX, correctionY);
  }

  function applyAll() {
    if (!frameDocument) return;
    nodes.forEach((node) => applyOverride(node.id));
    applyAllIconReplacements();
    updateInspector();
    requestAnimationFrame(drawSelection);
  }

  function setValueForId(id, key, value, live = false) {
    if (!id) return;
    overrides[id] ||= {};
    if (value === '' || value === null || value === undefined) delete overrides[id][key];
    else {
      const normalized = normalizedGeometryValue(key, value);
      if (normalized === null) {
        if (!Object.keys(overrides[id]).length) delete overrides[id];
        return false;
      }
      overrides[id][key] = normalized;
    }
    if (!Object.keys(overrides[id]).length) delete overrides[id];
    if (live) applyOverride(id);
    markStudioDirty();
    return true;
  }

  function setValue(key, value, live = true) {
    if (!selectedId) return;
    setValueForId(selectedId, key, value, live);
    if (live) { updateInspector(false); requestAnimationFrame(drawSelection); }
  }

  function offsetNode(id, dx, dy) {
    if (!id || isEffectivelyLocked(id)) return false;
    if (Math.abs(dx) > .001) setValueForId(id, 'x', Math.round(number(overrides[id]?.x) + dx));
    if (Math.abs(dy) > .001) setValueForId(id, 'y', Math.round(number(overrides[id]?.y) + dy));
    if (Math.abs(dx) <= .001 && Math.abs(dy) <= .001) return false;
    applyOverride(id);
    return true;
  }

  function applyMultiAction(action) {
    const union = selectionUnionRect();
    if (!union || union.entries.length < 2) return;
    const entries = union.entries.filter((entry) => !isEffectivelyLocked(entry.id));
    const lockedCount = union.entries.length - entries.length;
    if (!entries.length) { showToast('所选对象均已锁定，无法排列'); return; }
    const offsets = new Map(entries.map((entry) => [entry.id, { dx:0, dy:0 }]));
    const horizontalTarget = {
      'align-left':union.left,
      'align-center-x':union.left + union.width / 2,
      'align-right':union.right,
    }[action];
    const verticalTarget = {
      'align-top':union.top,
      'align-center-y':union.top + union.height / 2,
      'align-bottom':union.bottom,
    }[action];
    if (horizontalTarget !== undefined) entries.forEach((entry) => {
      offsets.get(entry.id).dx = horizontalTarget - (action === 'align-left' ? entry.rect.left : action === 'align-right' ? entry.rect.right : entry.rect.left + entry.rect.width / 2);
    });
    else if (verticalTarget !== undefined) entries.forEach((entry) => {
      offsets.get(entry.id).dy = verticalTarget - (action === 'align-top' ? entry.rect.top : action === 'align-bottom' ? entry.rect.bottom : entry.rect.top + entry.rect.height / 2);
    });
    else if (action === 'distribute-x' || action === 'distribute-y') {
      if (entries.length < 3) { showToast('等间距分布至少需要 3 个未锁定对象'); return; }
      const horizontal = action === 'distribute-x';
      const sorted = [...entries].sort((a, b) => horizontal ? a.rect.left - b.rect.left : a.rect.top - b.rect.top);
      const first = sorted[0].rect;
      const last = sorted.at(-1).rect;
      const extent = horizontal ? last.right - first.left : last.bottom - first.top;
      const totalSize = sorted.reduce((sum, entry) => sum + (horizontal ? entry.rect.width : entry.rect.height), 0);
      const gap = (extent - totalSize) / (sorted.length - 1);
      let cursor = horizontal ? first.right : first.bottom;
      sorted.slice(1, -1).forEach((entry) => {
        const desired = cursor + gap;
        if (horizontal) offsets.get(entry.id).dx = desired - entry.rect.left;
        else offsets.get(entry.id).dy = desired - entry.rect.top;
        cursor = desired + (horizontal ? entry.rect.width : entry.rect.height);
      });
    } else return;
    const label = {
      'align-left':'左对齐', 'align-center-x':'水平居中', 'align-right':'右对齐',
      'align-top':'顶对齐', 'align-center-y':'垂直居中', 'align-bottom':'底对齐',
      'distribute-x':'水平等间距', 'distribute-y':'垂直等间距'
    }[action] || '批量排列';
    offsets.forEach(({ dx, dy }, id) => offsetNode(id, dx, dy));
    commit({ label, type:'layout.arrange', targetIds:entries.map((entry) => entry.id), detail:{ action } });
    renderLayers($('#layer-search').value);
    syncFeatureObjectSelection();
    updateMultiInspector();
    drawSelection();
    showToast(`${label}已应用${lockedCount ? ` · 跳过 ${lockedCount} 个锁定对象` : ''}`);
  }

  function arrangeSelectionStack(action) {
    const ids = activeSelectionIds().filter((id) => !isEffectivelyLocked(id));
    if (!ids.length) { showToast('没有可调整层级的未锁定图层'); return false; }
    ids.forEach((id) => {
      const element = frameDocument?.querySelector(`[data-ui-id="${CSS.escape(id)}"]`);
      if (!element) return;
      const siblings = [...element.parentElement.children].filter((item) => item.matches?.('[data-ui-id]'));
      const siblingLevels = siblings.map((item) => {
        const itemId = item.dataset.uiId;
        const computed = getComputedStyle(item).zIndex;
        return number(overrides[itemId]?.zIndex, computed === 'auto' ? 0 : computed);
      });
      const ownComputed = getComputedStyle(element);
      const current = number(overrides[id]?.zIndex, ownComputed.zIndex === 'auto' ? 0 : ownComputed.zIndex);
      const next = action === 'front' ? Math.max(0, ...siblingLevels) + 1
        : action === 'back' ? Math.min(0, ...siblingLevels) - 1
        : action === 'forward' ? current + 1
        : current - 1;
      setValueForId(id, 'zIndex', next, false);
      if (ownComputed.position === 'static') setValueForId(id, 'position', 'relative', false);
      applyOverride(id);
    });
    const label = { forward:'前移一层', backward:'后移一层', front:'移到最前', back:'移到最后' }[action];
    commit({ label, type:'layer.stack', targetIds:ids, detail:{ action } });
    updateInspector(false);
    drawSelection();
    showToast(`${label} · Ctrl+Z 可撤销`);
    return true;
  }

  function computedValues() {
    const element = selectedElement();
    if (!element) return null;
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    const own = overrides[selectedId] || {};
    const resolvedScale = number(own.scale, style.scale === 'none' ? 1 : style.scale || 1);
    return {
      x: number(own.x), y: number(own.y), width: number(own.width, element.offsetWidth || rect.width / resolvedScale), height: number(own.height, element.offsetHeight || rect.height / resolvedScale),
      scale: resolvedScale, rotation: number(own.rotation, style.rotate === 'none' ? 0 : style.rotate),
      backgroundColor: rgbToHex(own.backgroundColor || style.backgroundColor, '#ffffff'), color: rgbToHex(own.color || style.color, '#08152c'),
      fontSize: number(own.fontSize, style.fontSize), fontFamily: own.fontFamily || style.fontFamily, fontWeight: number(own.fontWeight, style.fontWeight || 400),
      lineHeight: number(own.lineHeight, style.lineHeight === 'normal' ? number(style.fontSize) * 1.4 : style.lineHeight), letterSpacing: number(own.letterSpacing, style.letterSpacing === 'normal' ? 0 : style.letterSpacing), textAlign: own.textAlign || style.textAlign || 'left',
      borderRadius: number(own.borderRadius, style.borderTopLeftRadius), borderWidth: number(own.borderWidth, style.borderTopWidth), borderColor: rgbToHex(own.borderColor || style.borderTopColor, '#d7deea'), borderStyle: own.borderStyle || style.borderTopStyle || 'solid',
      shadowX: number(own.shadowX), shadowY: number(own.shadowY), shadowBlur: number(own.shadowBlur), shadowSpread: number(own.shadowSpread), shadowColor: rgbToHex(own.shadowColor, '#000000'),
      opacity: Math.round(number(own.opacity, style.opacity) * 100), padding: number(own.padding, style.paddingTop)
    };
  }

  function fontFamilyKey(value = '') {
    const family = value.toLowerCase();
    if (family.includes('noto sans')) return 'noto-sans';
    if (family.includes('noto serif')) return 'noto-serif';
    if (family.includes('lxgw')) return 'lxgw';
    if (family.includes('jetbrains')) return 'jetbrains';
    return 'system';
  }

  function updateInspector(updateAll = true) {
    if (!selectedId || !frameDocument) return;
    const values = computedValues();
    if (!values) return;
    configureInspectorForSelection();
    const ids = ['x','y','width','height','scale','rotation','font-size','line-height','letter-spacing','radius','border-width','shadow-x','shadow-y','shadow-blur','shadow-spread','opacity','padding'];
    const props = [values.x,values.y,values.width,values.height,values.scale * 100,values.rotation,values.fontSize,values.lineHeight,values.letterSpacing,values.borderRadius,values.borderWidth,values.shadowX,values.shadowY,values.shadowBlur,values.shadowSpread,values.opacity,values.padding];
    if (updateAll) ids.forEach((id, index) => { $(`#prop-${id}`).value = Math.round(props[index]); });
    $('#prop-bg').value = values.backgroundColor;
    $('#prop-color').value = values.color;
    $('#prop-border-color').value = values.borderColor;
    $('#prop-border-style').value = ['solid','dashed','dotted','none'].includes(values.borderStyle) ? values.borderStyle : 'solid';
    $('#prop-shadow-color').value = values.shadowColor;
    const textElement = isTextElement(selectedElement());
    $('#text-system').hidden = !textElement;
    if (textElement) {
      if (updateAll) $('#prop-text-content').value = selectedElement().textContent;
      $('#prop-font-family').value = fontFamilyKey(values.fontFamily);
      $('#prop-font-weight').value = String([300,400,500,600,700,800].reduce((best, weight) => Math.abs(weight-values.fontWeight) < Math.abs(best-values.fontWeight) ? weight : best, 400));
      $('#prop-text-align').value = ['left','center','right','justify'].includes(values.textAlign) ? values.textAlign : 'left';
    }
    const display = getComputedStyle(selectedElement()).display;
    $('#layout-hint').textContent = display.includes('grid') ? '当前元素使用 Grid。宽高调整会保留网格结构，位移使用独立 translate。' : display.includes('flex') ? '当前元素使用 Flex。建议优先调整尺寸与内边距；位移使用独立 translate，不改写子项排列。' : '当前元素使用正常文档流。拖动以非破坏性的 translate 偏移，导出时保留原响应式结构。';
  }

  function rgbToHex(value, fallback) {
    if (!value || value === 'transparent' || value === 'rgba(0, 0, 0, 0)') return fallback;
    if (value.startsWith('#')) return value.length === 4 ? `#${value[1]}${value[1]}${value[2]}${value[2]}${value[3]}${value[3]}` : value.slice(0,7);
    const values = value.match(/[\d.]+/g);
    if (!values || values.length < 3) return fallback;
    return `#${values.slice(0,3).map((part) => Math.round(Number(part)).toString(16).padStart(2,'0')).join('')}`;
  }

  function forgivingSelectionEdgeDirection(event, control) {
    if (!selectionBox || selectionBox.hidden || !selectionBox.contains(event.target)) return '';
    if (control?.classList.contains('ui-studio-move-grip')) return '';
    if (control?.dataset.dir) return control.dataset.dir;
    const rect = selectionBox.getBoundingClientRect();
    const tolerance = 18;
    const distances = [
      ['n', Math.abs(event.clientY - rect.top)],
      ['s', Math.abs(event.clientY - rect.bottom)],
      ['w', Math.abs(event.clientX - rect.left)],
      ['e', Math.abs(event.clientX - rect.right)],
    ].filter(([, distance]) => distance <= tolerance).sort((a, b) => a[1] - b[1]);
    return distances[0]?.[0] || '';
  }

  function beginManipulation(event) {
    if (!selectedId || event.button !== 0) return;
    const control = event.target.closest('.ui-studio-handle, .ui-studio-edge, .ui-studio-move-grip, .ui-studio-move-surface');
    const overlayGesture = selectionBox.contains(event.target);
    const direction = control?.dataset.dir || (overlayGesture ? forgivingSelectionEdgeDirection(event, control) : '') || 'move';
    const pointerCaptureTarget = control || (overlayGesture ? selectionBox : event.target);
    const snapshotBeforeGesture = snapshotState();
    const selectedIdsBeforeGesture = activeSelectionIds();
    const selectedIdBeforeGesture = selectedId;
    const duplicateDrag = direction === 'move' && event.altKey;
    const duplicateRecords = duplicateDrag ? duplicateSelection({ commit:false, notify:false }) : [];
    if (duplicateDrag && !duplicateRecords.length) return;
    const multiSelection = hasMultiSelection();
    const movableIds = activeSelectionIds().filter((id) => !isEffectivelyLocked(id));
    if (!movableIds.length || (!multiSelection && isEffectivelyLocked(selectedId))) {
      if (duplicateDrag) restore(snapshotBeforeGesture, { markDirty:false });
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    pointerCaptureTarget.setPointerCapture?.(event.pointerId);
    if (multiSelection && direction !== 'move') return;
    const gestureMetadata = {
      label:duplicateDrag ? `复制并移动${multiSelection ? ` ${movableIds.length} 个对象` : ` ${labelFor(selectedId)}`}` : direction === 'move' ? `移动${multiSelection ? ` ${movableIds.length} 个对象` : ` ${labelFor(selectedId)}`}` : `调整 ${labelFor(selectedId)} 尺寸`,
      type:duplicateDrag ? 'layer.duplicate-drag' : direction === 'move' ? 'geometry.move' : 'geometry.resize',
      targetIds:movableIds,
      detail:{ direction, duplicate:duplicateDrag, sourceIds:duplicateRecords.map((record) => record.sourceId), insertionIds:duplicateRecords.map((record) => record.id) },
      mergeKey:duplicateDrag ? '' : `gesture:${direction}:${movableIds.join(',')}`,
    };
    const eventRoot = overlayGesture ? document : frameDocument;
    const canvas = $('#canvas-viewport');
    const renderScale = canvasRenderScale();
    const gestureRenderContext = selectionRenderContext();
    const pointerScaleX = overlayGesture ? Math.max(.05, renderScale.x) : 1;
    const pointerScaleY = overlayGesture ? Math.max(.05, renderScale.y) : 1;
    const values = computedValues();
    const start = { ...values, pointerX: event.clientX, pointerY: event.clientY };
    const startRect = multiSelection ? selectionUnionRect() : selectedElement().getBoundingClientRect();
    const targets = collectSnapTargets(selectedElement(), new Set(activeSelectionIds()));
    const ratio = Math.max(.01, values.width / values.height);
    const before = clone(overrides);
    const multiStart = multiSelection ? movableIds.map((id) => ({ id, x:number(overrides[id]?.x), y:number(overrides[id]?.y) })) : [];
    let stickyX = null;
    let stickyY = null;
    let axisLock = null;
    let latestMoveEvent = null;
    let lastPointerSample = {
      pointerId:event.pointerId,
      clientX:event.clientX,
      clientY:event.clientY,
      altKey:event.altKey,
      shiftKey:event.shiftKey,
      ctrlKey:event.ctrlKey,
      metaKey:event.metaKey,
    };
    let moveFrame = 0;
    let autoPanFrame = 0;
    let cameraDragX = 0;
    let cameraDragY = 0;
    let cameraAutoPanned = false;
    let gestureMoved = false;
    let gestureFinished = false;
    const liveElements = movableIds.map((id) => frameDocument.querySelector(`[data-ui-id="${CSS.escape(id)}"]`)).filter(Boolean);
    liveElements.forEach((element) => {
      if (getComputedStyle(element).display === 'inline') element.style.display = 'inline-block';
      element.style.willChange = direction === 'move' ? 'translate' : 'translate, width, height, scale';
    });
    document.body.classList.add('object-manipulating');
    document.body.dataset.manipulation = direction;
    selectionBox.dataset.activeDirection = direction;
    selectionBox.dataset.gestureState = 'pressed';
    if (control) control.dataset.gestureOwner = 'true';

    function updateLiveGeometryInputs() {
      if (multiSelection) return;
      const own = overrides[selectedId] || {};
      $('#prop-x').value = Math.round(number(own.x, start.x));
      $('#prop-y').value = Math.round(number(own.y, start.y));
      $('#prop-width').value = Math.round(number(own.width, start.width));
      $('#prop-height').value = Math.round(number(own.height, start.height));
      $('#prop-scale').value = Math.round(number(own.scale, start.scale) * 100);
    }

    function applyMove(moveEvent) {
      let dx = (moveEvent.clientX - start.pointerX + cameraDragX) / pointerScaleX;
      let dy = (moveEvent.clientY - start.pointerY + cameraDragY) / pointerScaleY;
      const gestureDistance = Math.hypot(moveEvent.clientX - start.pointerX, moveEvent.clientY - start.pointerY);
      if (!gestureMoved && direction === 'move' && gestureDistance < 2) return;
      if (!gestureMoved && direction !== 'move' && gestureDistance < .25) return;
      gestureMoved = true;
      selectionBox.dataset.gestureState = 'dragging';
      const centerResize = direction !== 'move' && moveEvent.altKey;
      if (direction === 'move' && moveEvent.shiftKey) {
        axisLock ||= Math.abs(dx) >= Math.abs(dy) ? 'x' : 'y';
        if (axisLock === 'x') dy = 0; else dx = 0;
      } else if (direction === 'move') axisLock = null;
      let snappedX = null;
      let snappedY = null;
      let snappedXLabel = '';
      let snappedYLabel = '';
      if (multiSelection) {
        if (!(moveEvent.ctrlKey || moveEvent.metaKey || (!duplicateDrag && moveEvent.altKey))) {
          const xSnap = snapAxis([startRect.left + dx, startRect.left + startRect.width / 2 + dx, startRect.right + dx], targets.x, stickyX, renderScale.x);
          const ySnap = snapAxis([startRect.top + dy, startRect.top + startRect.height / 2 + dy, startRect.bottom + dy], targets.y, stickyY, renderScale.y);
          dx += xSnap.delta; dy += ySnap.delta;
          stickyX = xSnap.sticky || null; stickyY = ySnap.sticky || null;
          snappedX = xSnap.target; snappedY = ySnap.target; snappedXLabel = xSnap.label; snappedYLabel = ySnap.label;
        }
        multiStart.forEach((item) => {
          applyLivePosition(item.id, item.x + dx, item.y + dy);
        });
        showSnapFeedback(snappedX, snappedY, snappedXLabel, snappedYLabel);
        drawSelection(offsetRectSnapshot(startRect, dx, dy), gestureRenderContext);
        return;
      }
      let width = start.width;
      let height = start.height;
      if (direction === 'move') {
        if (!(moveEvent.ctrlKey || moveEvent.metaKey || (!duplicateDrag && moveEvent.altKey))) {
          const xSnap = snapAxis([startRect.left + dx, startRect.left + startRect.width / 2 + dx, startRect.right + dx], targets.x, stickyX, renderScale.x);
          const ySnap = snapAxis([startRect.top + dy, startRect.top + startRect.height / 2 + dy, startRect.bottom + dy], targets.y, stickyY, renderScale.y);
          dx += xSnap.delta; dy += ySnap.delta;
          stickyX = xSnap.sticky || null; stickyY = ySnap.sticky || null;
          snappedX = xSnap.target; snappedY = ySnap.target; snappedXLabel = xSnap.label; snappedYLabel = ySnap.label;
        }
        applyLivePosition(selectedId, start.x + dx, start.y + dy);
        $('#prop-x').value = Math.round(start.x + dx);
        $('#prop-y').value = Math.round(start.y + dy);
        showSnapFeedback(snappedX, snappedY, snappedXLabel, snappedYLabel);
        drawSelection(offsetRectSnapshot(startRect, dx, dy), gestureRenderContext);
        if ($('#status-geometry')) $('#status-geometry').textContent = `X ${Math.round(startRect.left + dx)} · Y ${Math.round(startRect.top + dy)} · ${Math.round(startRect.width)} × ${Math.round(startRect.height)}`;
        return;
      } else {
        if (!moveEvent.altKey) {
          if (direction.includes('e') || direction.includes('w')) {
            const movingX = direction.includes('e') ? startRect.right + dx : startRect.left + dx;
            const xSnap = snapAxis([movingX], targets.x, stickyX, renderScale.x);
            stickyX = xSnap.sticky || null;
            dx += xSnap.delta; snappedX = xSnap.target; snappedXLabel = xSnap.label;
          }
          if (direction.includes('s') || direction.includes('n')) {
            const movingY = direction.includes('s') ? startRect.bottom + dy : startRect.top + dy;
            const ySnap = snapAxis([movingY], targets.y, stickyY, renderScale.y);
            stickyY = ySnap.sticky || null;
            dy += ySnap.delta; snappedY = ySnap.target; snappedYLabel = ySnap.label;
          }
        }
        const localDx = dx / Math.max(.05, start.scale) * (centerResize ? 2 : 1);
        const localDy = dy / Math.max(.05, start.scale) * (centerResize ? 2 : 1);
        width = start.width + (direction.includes('e') ? localDx : direction.includes('w') ? -localDx : 0);
        height = start.height + (direction.includes('s') ? localDy : direction.includes('n') ? -localDy : 0);
        width = Math.max(18, width); height = Math.max(18, height);
        const cornerHandle = direction.length === 2;
        const baseAspectLock = $('#aspect-lock').checked || cornerHandle;
        const aspectLocked = moveEvent.shiftKey ? !baseAspectLock : baseAspectLock;
        if (cornerHandle && aspectLocked) {
          const renderedWidth = Math.max(18, startRect.width + (direction.includes('e') ? dx : -dx) * (centerResize ? 2 : 1));
          const renderedHeight = Math.max(18, startRect.height + (direction.includes('s') ? dy : -dy) * (centerResize ? 2 : 1));
          const factor = Math.abs(dx) >= Math.abs(dy) ? renderedWidth / Math.max(1,startRect.width) : renderedHeight / Math.max(1,startRect.height);
          const nextScale = Math.max(.05, Math.min(10, start.scale * factor));
          const nextWidth = startRect.width * (nextScale / Math.max(.05,start.scale));
          const nextHeight = startRect.height * (nextScale / Math.max(.05,start.scale));
          setValue('scale', Number(nextScale.toFixed(4)), false);
          if (centerResize) {
            setValue('x', liveGeometryValue(start.x + (startRect.width - nextWidth) / 2), false);
            setValue('y', liveGeometryValue(start.y + (startRect.height - nextHeight) / 2), false);
          } else {
            if (direction.includes('w')) setValue('x', liveGeometryValue(start.x + startRect.width - nextWidth), false);
            if (direction.includes('n')) setValue('y', liveGeometryValue(start.y + startRect.height - nextHeight), false);
          }
          showSnapFeedback(snappedX, snappedY, snappedXLabel, snappedYLabel);
          applyLiveResizeGeometry(selectedId);
          const resizeRect = predictedResizeRect(startRect, direction, nextWidth, nextHeight, centerResize);
          updateLiveGeometryInputs();
          drawSelection(resizeRect, gestureRenderContext);
          return;
        }
        if (aspectLocked) {
          if (Math.abs(dx) >= Math.abs(dy)) height = width / ratio;
          else width = height * ratio;
        }
        setValue('width', liveGeometryValue(width), false);
        setValue('height', liveGeometryValue(height), false);
        if (centerResize && (direction.includes('e') || direction.includes('w'))) setValue('x', liveGeometryValue(start.x + (start.width - width) / 2), false);
        else if (direction.includes('w')) setValue('x', liveGeometryValue(start.x + start.width - width), false);
        if (centerResize && (direction.includes('s') || direction.includes('n'))) setValue('y', liveGeometryValue(start.y + (start.height - height) / 2), false);
        else if (direction.includes('n')) setValue('y', liveGeometryValue(start.y + start.height - height), false);
      }
      showSnapFeedback(snappedX, snappedY, snappedXLabel, snappedYLabel);
      applyLiveResizeGeometry(selectedId);
      const renderedWidth = startRect.width * (width / Math.max(1, start.width));
      const renderedHeight = startRect.height * (height / Math.max(1, start.height));
      const resizeRect = predictedResizeRect(startRect, direction, renderedWidth, renderedHeight, centerResize);
      updateLiveGeometryInputs();
      drawSelection(resizeRect, gestureRenderContext);
    }

    function flushMove() {
      moveFrame = 0;
      if (!latestMoveEvent) return;
      const nextEvent = latestMoveEvent;
      latestMoveEvent = null;
      applyMove(nextEvent);
    }

    function stopManipulationAutoPan() {
      if (autoPanFrame) cancelAnimationFrame(autoPanFrame);
      autoPanFrame = 0;
      document.body.classList.remove('object-auto-panning');
    }

    function manipulationAutoPanStep() {
      autoPanFrame = 0;
      if (!overlayGesture || !lastPointerSample) return;
      const canvasRect = canvas.getBoundingClientRect();
      const speedX = manipulationAutoPanVelocity(lastPointerSample.clientX, canvasRect.left, canvasRect.right);
      const speedY = manipulationAutoPanVelocity(lastPointerSample.clientY, canvasRect.top, canvasRect.bottom);
      if (!speedX && !speedY) { stopManipulationAutoPan(); return; }
      const beforeLeft = canvas.scrollLeft;
      const beforeTop = canvas.scrollTop;
      canvas.scrollLeft = Math.max(0, Math.min(canvas.scrollWidth - canvas.clientWidth, beforeLeft + speedX));
      canvas.scrollTop = Math.max(0, Math.min(canvas.scrollHeight - canvas.clientHeight, beforeTop + speedY));
      const scrolledX = canvas.scrollLeft - beforeLeft;
      const scrolledY = canvas.scrollTop - beforeTop;
      if (!scrolledX && !scrolledY) { stopManipulationAutoPan(); return; }
      cameraDragX += scrolledX;
      cameraDragY += scrolledY;
      gestureRenderContext.frameRect.left -= scrolledX;
      gestureRenderContext.frameRect.right -= scrolledX;
      gestureRenderContext.frameRect.top -= scrolledY;
      gestureRenderContext.frameRect.bottom -= scrolledY;
      cameraAutoPanned = true;
      document.body.classList.add('object-auto-panning');
      latestMoveEvent = null;
      applyMove(lastPointerSample);
      autoPanFrame = requestAnimationFrame(manipulationAutoPanStep);
    }

    function scheduleManipulationAutoPan(pointerSample) {
      if (!overlayGesture) return;
      lastPointerSample = pointerSample;
      const canvasRect = canvas.getBoundingClientRect();
      const speedX = manipulationAutoPanVelocity(pointerSample.clientX, canvasRect.left, canvasRect.right);
      const speedY = manipulationAutoPanVelocity(pointerSample.clientY, canvasRect.top, canvasRect.bottom);
      if (!speedX && !speedY) { stopManipulationAutoPan(); return; }
      if (!autoPanFrame) autoPanFrame = requestAnimationFrame(manipulationAutoPanStep);
    }

    function move(moveEvent) {
      if (moveEvent.pointerId !== event.pointerId) return;
      if (moveEvent.pointerType === 'mouse' && moveEvent.buttons === 0) {
        end(moveEvent, false);
        return;
      }
      const samples = moveEvent.getCoalescedEvents?.() || [];
      const sample = samples.at(-1) || moveEvent;
      lastPointerSample = {
        pointerId:sample.pointerId,
        clientX:sample.clientX,
        clientY:sample.clientY,
        altKey:sample.altKey,
        shiftKey:sample.shiftKey,
        ctrlKey:sample.ctrlKey,
        metaKey:sample.metaKey,
      };
      latestMoveEvent = lastPointerSample;
      scheduleManipulationAutoPan(lastPointerSample);
      if (!moveFrame) moveFrame = requestAnimationFrame(flushMove);
    }

    function end(endEvent, canceled = false) {
      if (endEvent?.pointerId !== undefined && endEvent.pointerId !== event.pointerId) return;
      if (gestureFinished) return;
      gestureFinished = true;
      if (moveFrame) cancelAnimationFrame(moveFrame);
      moveFrame = 0;
      stopManipulationAutoPan();
      if (!canceled && endEvent?.clientX !== undefined) latestMoveEvent = {
        pointerId:endEvent.pointerId,
        clientX:endEvent.clientX,
        clientY:endEvent.clientY,
        altKey:endEvent.altKey,
        shiftKey:endEvent.shiftKey,
        ctrlKey:endEvent.ctrlKey,
        metaKey:endEvent.metaKey,
      };
      if (!canceled) flushMove();
      if (!canceled && gestureMoved && direction !== 'move' && !multiSelection) {
        drawSelection(stabilizeResizeAnchor(selectedId, direction, startRect, Boolean(endEvent?.altKey)));
      }
      eventRoot.removeEventListener('pointermove', move, true);
      eventRoot.removeEventListener('pointerup', end, true);
      eventRoot.removeEventListener('pointercancel', cancel, true);
      window.removeEventListener('pointerup', end, true);
      window.removeEventListener('pointercancel', cancel, true);
      window.removeEventListener('mouseup', finishOnMouseUp, true);
      window.removeEventListener('blur', finishOnBlur, true);
      pointerCaptureTarget.removeEventListener?.('lostpointercapture', finishOnLostPointerCapture, true);
      document.removeEventListener('keydown', keydown, true);
      if (pointerCaptureTarget.hasPointerCapture?.(event.pointerId)) pointerCaptureTarget.releasePointerCapture(event.pointerId);
      document.body.classList.remove('object-manipulating');
      document.body.classList.remove('object-auto-panning');
      delete document.body.dataset.manipulation;
      delete selectionBox.dataset.activeDirection;
      delete selectionBox.dataset.gestureState;
      if (control) delete control.dataset.gestureOwner;
      if (gestureMoved && !overlayGesture) suppressCanvasClick = true;
      liveElements.forEach((element) => { element.style.willChange = ''; });
      hideSnapFeedback();
      if (canceled || (duplicateDrag && !gestureMoved)) {
        if (duplicateDrag) {
          restore(snapshotBeforeGesture, { markDirty:false });
          selectedIds = new Set(selectedIdsBeforeGesture);
          selectedId = selectedIdBeforeGesture;
          renderLayers($('#layer-search').value);
          updateContextInspector();
          if (!canceled) showToast('未移动，已取消创建副本');
        } else {
          overrides = clone(before);
          movableIds.forEach((id) => applyOverride(id));
          showToast('已取消本次拖动');
        }
      } else if (gestureMoved && (duplicateDrag || JSON.stringify(before) !== JSON.stringify(overrides))) {
        commit(gestureMetadata);
        if (duplicateDrag) showToast(`已复制并移动 ${movableIds.length} 个真实图层 · Ctrl+Z 可撤销`);
      }
      if (cameraAutoPanned) persistCanvasView(true);
      updateInspector();
      requestAnimationFrame(() => {
        if (!selectedId) return;
        drawSelection(selectionUnionRect());
      });
    }
    function cancel(cancelEvent) { end(cancelEvent, true); }
    function finishOnLostPointerCapture(captureEvent) {
      if (captureEvent.pointerId !== event.pointerId) return;
      end(null, false);
    }
    function finishOnMouseUp(mouseEvent) {
      if (mouseEvent.button !== 0) return;
      end(mouseEvent, false);
    }
    function finishOnBlur() { end(null, false); }
    function keydown(keyEvent) {
      if (keyEvent.key !== 'Escape') return;
      keyEvent.preventDefault();
      end(null, true);
    }
    eventRoot.addEventListener('pointermove', move, true);
    eventRoot.addEventListener('pointerup', end, true);
    eventRoot.addEventListener('pointercancel', cancel, true);
    window.addEventListener('pointerup', end, true);
    window.addEventListener('pointercancel', cancel, true);
    window.addEventListener('mouseup', finishOnMouseUp, true);
    window.addEventListener('blur', finishOnBlur, true);
    pointerCaptureTarget.addEventListener?.('lostpointercapture', finishOnLostPointerCapture, true);
    document.addEventListener('keydown', keydown, true);
  }

  function commit(metadata = {}) {
    const repairedGeometry = sanitizeOverrideGeometry(overrides);
    if (repairedGeometry) {
      applyAll();
      showToast(`已阻止 ${repairedGeometry} 个无效几何值`);
    }
    const snapshot = snapshotState();
    if (typeof metadata === 'string') metadata = { label:metadata };
    const targetIds = metadata.targetIds || activeSelectionIds();
    const committed = commandHistory.commit(snapshot, {
      label:metadata.label || '编辑 UI',
      type:metadata.type || 'property.change',
      targetIds,
      detail:metadata.detail || {},
      mergeKey:metadata.mergeKey || '',
    });
    if (!committed) return false;
    updateHistoryButtons();
    markStudioDirty();
    return true;
  }

  function restore(snapshot, options = {}) {
    if (snapshot && Object.prototype.hasOwnProperty.call(snapshot, 'overrides')) {
      overrides = clone(snapshot.overrides || {});
      iconReplacements = clone(snapshot.icons || {});
      locks = new Set(snapshot.locks || []);
      guides = clone(snapshot.guides || []);
      structuralEdits = clone(snapshot.structure || { insertions:[] });
      layerMetadata = clone(snapshot.layerMetadata || {});
    } else {
      overrides = clone(snapshot || {});
      iconReplacements = {};
      locks = new Set();
      guides = [];
      structuralEdits = { insertions:[] };
      layerMetadata = {};
    }
    sanitizeOverrideGeometry(overrides);
    localStorage.setItem(LOCKS_KEY, JSON.stringify([...locks]));
    localStorage.setItem(STRUCTURE_KEY, JSON.stringify(structuralEdits));
    localStorage.setItem(LAYER_META_KEY, JSON.stringify(layerMetadata));
    saveGuides();
    saveLocalDraft();
    applyStructuralEdits();
    applyLayerMetadata();
    buildLayers();
    applyAll();
    renderGuides();
    renderLayers($('#layer-search').value);
    if ($('#icon-tool-dialog')?.open) updateIconToolTarget();
    if (options.markDirty !== false) markStudioDirty();
  }

  function updateHistoryButtons() {
    const state = commandHistory.state();
    const undo = $('#undo');
    const redo = $('#redo');
    undo.disabled = !state.canUndo;
    redo.disabled = !state.canRedo;
    undo.title = state.canUndo ? `撤销“${state.undoLabel}” · Ctrl+Z` : '没有可撤销的操作';
    redo.title = state.canRedo ? `重做“${state.redoLabel}” · Ctrl+Shift+Z` : '没有可重做的操作';
    undo.setAttribute('aria-label', undo.title);
    redo.setAttribute('aria-label', redo.title);
    renderStatusBar();
  }

  function undoCommand() {
    const result = commandHistory.undo();
    if (!result) return;
    restore(result.snapshot);
    studioDirty = commandHistory.state().dirty;
    renderSyncStatus();
    updateHistoryButtons();
    showToast(`已撤销：${result.label}`);
  }

  function redoCommand() {
    const result = commandHistory.redo();
    if (!result) return;
    restore(result.snapshot);
    studioDirty = commandHistory.state().dirty;
    renderSyncStatus();
    updateHistoryButtons();
    showToast(`已重做：${result.label}`);
  }

  function toggleVisibility(id) {
    overrides[id] ||= {};
    overrides[id].display = overrides[id].display === 'none' ? '' : 'none';
    if (!overrides[id].display) delete overrides[id].display;
    if (!Object.keys(overrides[id]).length) delete overrides[id];
    applyOverride(id);
    commit({ label:overrides[id]?.display === 'none' ? `隐藏 ${labelFor(id)}` : `显示 ${labelFor(id)}`, type:'layer.visibility', targetIds:[id] });
    renderLayers($('#layer-search').value); drawSelection();
  }

  function editingTarget(target) {
    return Boolean(target?.closest?.('input, textarea, select, [contenteditable="true"], [contenteditable="plaintext-only"]'));
  }

  function selectableClipboardIds() {
    const selection = new Set(activeSelectionIds());
    return [...selection].filter((id) => !ancestorIds(id).some((ancestorId) => selection.has(ancestorId)));
  }

  function captureLayerClipboard() {
    const ids = selectableClipboardIds();
    if (!ids.length) { showToast('请先选择要复制的图层'); return false; }
    const entries = ids.map((id) => {
      const element = frameDocument?.querySelector(`[data-ui-id="${CSS.escape(id)}"]`);
      const override = clone(overrides[id] || {});
      delete override.display;
      if (isTextElement(element)) override.textContent = element.textContent || '';
      return {
        sourceId:id,
        label:labelFor(id),
        kind:selectionTypeFor(element),
        override,
        icon:iconReplacements[id] ? clone(iconReplacements[id]) : null,
      };
    });
    layerClipboard = { version:1, copiedAt:new Date().toISOString(), entries };
    localStorage.setItem(CLIPBOARD_KEY, JSON.stringify(layerClipboard));
    navigator.clipboard?.writeText?.(`UISTUDIO_LAYER_V1:${JSON.stringify(layerClipboard)}`).catch(() => {});
    showToast(`已复制 ${entries.length} 个图层调整 · 选择目标后 Ctrl+V`);
    return true;
  }

  function pasteLayerClipboard({ appearanceOnly = false } = {}) {
    const entries = layerClipboard?.entries || [];
    const targetIds = selectableClipboardIds().filter((id) => !isEffectivelyLocked(id));
    if (!entries.length) { showToast('图层剪贴板为空，请先按 Ctrl+C'); return false; }
    if (!targetIds.length) { showToast('请选择接收调整的目标图层'); return false; }
    if (entries.length > 1 && entries.length !== targetIds.length) {
      showToast(`复制了 ${entries.length} 层，请选择相同数量的目标图层`);
      return false;
    }
    const visualKeys = new Set(['backgroundColor','color','fontSize','fontFamily','fontWeight','lineHeight','letterSpacing','textAlign','borderRadius','borderWidth','borderColor','borderStyle','opacity','padding','shadowX','shadowY','shadowBlur','shadowSpread','shadowColor']);
    targetIds.forEach((targetId, index) => {
      const entry = entries.length === 1 ? entries[0] : entries[index];
      const next = {};
      Object.entries(entry.override || {}).forEach(([key, value]) => {
        if (!appearanceOnly || visualKeys.has(key)) next[key] = clone(value);
      });
      overrides[targetId] = { ...(overrides[targetId] || {}), ...next };
      if (!appearanceOnly && entry.icon) iconReplacements[targetId] = clone(entry.icon);
      applyOverride(targetId);
    });
    if (!appearanceOnly) applyAllIconReplacements();
    commit({
      label:`${appearanceOnly ? '粘贴外观到' : '粘贴图层调整到'} ${targetIds.length > 1 ? `${targetIds.length} 个对象` : labelFor(targetIds[0])}`,
      type:appearanceOnly ? 'clipboard.paste-appearance' : 'clipboard.paste',
      targetIds,
      detail:{ sourceIds:entries.map((entry) => entry.sourceId), appearanceOnly },
    });
    updateInspector();
    drawSelection();
    showToast(`${appearanceOnly ? '外观' : '图层调整'}已粘贴 · Ctrl+Z 可撤销`);
    return true;
  }

  function deleteSelection({ cut = false } = {}) {
    const ids = selectableClipboardIds().filter((id) => id !== 'app.shell' && !isEffectivelyLocked(id));
    if (!ids.length) {
      showToast(activeSelectionIds().includes('app.shell') ? '页面根节点不能删除' : '没有可删除的未锁定图层');
      return false;
    }
    ids.forEach((id) => {
      overrides[id] ||= {};
      overrides[id].display = 'none';
      applyOverride(id);
    });
    commit({ label:`${cut ? '剪切' : '删除'} ${ids.length > 1 ? `${ids.length} 个对象` : labelFor(ids[0])}`, type:cut ? 'clipboard.cut' : 'layer.delete', targetIds:ids, detail:{ softDelete:true } });
    clearSelection();
    showToast(`已${cut ? '剪切' : '删除'} ${ids.length} 个图层 · Ctrl+Z 可恢复`);
    return true;
  }

  function cutSelection() {
    if (!captureLayerClipboard()) return false;
    return deleteSelection({ cut:true });
  }

  function selectAllInContext() {
    const current = nodes.find((node) => node.id === selectedId);
    const parentId = current?.parentId ?? 'app.shell';
    const ids = nodes
      .filter((node) => node.parentId === parentId && overrides[node.id]?.display !== 'none')
      .map((node) => node.id);
    if (!ids.length) { showToast('当前层级没有可选择对象'); return; }
    selectedIds = new Set(ids);
    selectedId = ids.at(-1);
    renderLayers($('#layer-search').value);
    updateContextInspector();
    drawSelection();
    renderStatusBar();
    showToast(`已选择当前层级 ${ids.length} 个对象`);
  }

  function cycleSelection(backward = false) {
    const visible = nodes.filter((node) => overrides[node.id]?.display !== 'none');
    if (!visible.length) return;
    const index = Math.max(0, visible.findIndex((node) => node.id === selectedId));
    const next = visible[(index + (backward ? -1 : 1) + visible.length) % visible.length];
    select(next.id);
  }

  function toggleLock(id) {
    locks.has(id) ? locks.delete(id) : locks.add(id);
    localStorage.setItem(LOCKS_KEY, JSON.stringify([...locks]));
    commit({ label:locks.has(id) ? `锁定 ${labelFor(id)}` : `解锁 ${labelFor(id)}`, type:'layer.lock', targetIds:[id] });
    renderLayers($('#layer-search').value); drawSelection();
  }

  function toggleSelectionVisibility() {
    const ids = selectableClipboardIds().filter((id) => id !== 'app.shell');
    if (!ids.length) { showToast('请先选择要显示或隐藏的图层'); return false; }
    const shouldHide = ids.some((id) => overrides[id]?.display !== 'none');
    ids.forEach((id) => {
      overrides[id] ||= {};
      if (shouldHide) overrides[id].display = 'none';
      else delete overrides[id].display;
      if (!Object.keys(overrides[id]).length) delete overrides[id];
      applyOverride(id);
    });
    commit({ label:`${shouldHide ? '隐藏' : '显示'} ${ids.length > 1 ? `${ids.length} 个对象` : labelFor(ids[0])}`, type:'layer.visibility', targetIds:ids });
    if (shouldHide) clearSelection();
    else { renderLayers($('#layer-search').value); drawSelection(); }
    showToast(`${shouldHide ? '已隐藏' : '已显示'} ${ids.length} 个图层 · Ctrl+Z 可撤销`);
    return true;
  }

  function toggleSelectionLock() {
    const ids = selectableClipboardIds().filter((id) => id !== 'app.shell');
    if (!ids.length) { showToast('请先选择要锁定或解锁的图层'); return false; }
    const shouldLock = ids.some((id) => !locks.has(id));
    ids.forEach((id) => shouldLock ? locks.add(id) : locks.delete(id));
    localStorage.setItem(LOCKS_KEY, JSON.stringify([...locks]));
    commit({ label:`${shouldLock ? '锁定' : '解锁'} ${ids.length > 1 ? `${ids.length} 个对象` : labelFor(ids[0])}`, type:'layer.lock', targetIds:ids });
    renderLayers($('#layer-search').value);
    drawSelection();
    showToast(`${shouldLock ? '已锁定' : '已解锁'} ${ids.length} 个图层`);
    return true;
  }

  function setViewport(width, height) {
    viewport = { width, height };
    frame.style.width = `${width}px`; frame.style.height = `${height}px`;
    overlayImage.style.width = `${width}px`; overlayImage.style.height = `${height}px`;
    if ($('#canvas-size')) $('#canvas-size').textContent = `${width} × ${height}`;
    buildRulers();
    renderGuides();
    autoFitCanvas ? requestAnimationFrame(() => applyCanvasFitMode(canvasFitMode, false)) : updateCanvasScale();
    requestAnimationFrame(drawSelection);
    renderStatusBar();
  }

  function finalizeZoomRendering() {
    clearTimeout(zoomSettleTimer);
    zoomSettleTimer = 0;
    buildRulers();
    drawSelection();
    renderStatusBar();
  }

  function updateCanvasScale(options = {}) {
    transform.style.transform = `scale(${zoom})`;
    stage.style.width = `${viewport.width * zoom}px`;
    stage.style.height = `${viewport.height * zoom}px`;
    stage.style.left = `${Math.round((CANVAS_WORLD_SIZE - viewport.width * zoom) / 2)}px`;
    stage.style.top = `${Math.round((CANVAS_WORLD_SIZE - viewport.height * zoom) / 2)}px`;
    world.dataset.cameraScale = String(zoom);
    $('#zoom-label').textContent = `${Math.round(zoom * 100)}%`;
    scheduleRulerSync();
    if (options.deferHeavy) {
      clearTimeout(zoomSettleTimer);
      zoomSettleTimer = setTimeout(finalizeZoomRendering, 72);
    } else finalizeZoomRendering();
  }

  const FIT_MODE_LABELS = { contain:'自适应', cover:'铺满', width:'适宽', height:'适高', actual:'100%', manual:'手动' };

  function availableCanvasSize() {
    const canvas = $('#canvas-viewport');
    return {
      canvas,
      width: Math.max(1, canvas.clientWidth - 96),
      height: Math.max(1, canvas.clientHeight - 96)
    };
  }

  function captureCanvasCamera() {
    const canvas = $('#canvas-viewport');
    if (!canvas || canvas.clientWidth < 2 || canvas.clientHeight < 2) return null;
    const rect = canvas.getBoundingClientRect();
    const frameRect = frame.getBoundingClientRect();
    return {
      zoom,
      scrollLeft:canvas.scrollLeft,
      scrollTop:canvas.scrollTop,
      viewportLeft:rect.left,
      viewportTop:rect.top,
      frameLeft:frameRect.left,
      frameTop:frameRect.top,
      fitMode:canvasFitMode,
      autoFit:autoFitCanvas,
    };
  }

  function restoreCanvasCamera(camera, { compensateViewportShift = true } = {}) {
    const canvas = $('#canvas-viewport');
    if (!camera || !canvas || canvas.clientWidth < 2 || canvas.clientHeight < 2) return false;
    cancelCameraMotion();
    zoom = Math.max(.05, Math.min(3, number(camera.zoom, zoom)));
    canvasFitMode = camera.fitMode || canvasFitMode;
    autoFitCanvas = Boolean(camera.autoFit);
    updateCanvasScale();
    const rect = canvas.getBoundingClientRect();
    const frameRect = frame.getBoundingClientRect();
    const shiftX = compensateViewportShift
      ? frameRect.left - number(camera.frameLeft, frameRect.left)
      : 0;
    const shiftY = compensateViewportShift
      ? frameRect.top - number(camera.frameTop, frameRect.top)
      : 0;
    canvas.scrollLeft = Math.max(0, canvas.scrollLeft + shiftX);
    canvas.scrollTop = Math.max(0, canvas.scrollTop + shiftY);
    refreshFitModeUI();
    scheduleSelectionSync();
    persistCanvasView(true);
    return true;
  }

  function preserveCameraAfterFeatureSwitch(camera, feature) {
    if (isDedicatedFeature(feature)) {
      parkedFeatureCamera = camera || parkedFeatureCamera;
      requestAnimationFrame(() => { canvasAutoFitSuspended = Math.max(0, canvasAutoFitSuspended - 1); });
      return;
    }
    const targetCamera = parkedFeatureCamera || camera;
    parkedFeatureCamera = null;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      restoreCanvasCamera(targetCamera);
      canvasAutoFitSuspended = Math.max(0, canvasAutoFitSuspended - 1);
    }));
  }

  function persistCanvasView(immediate = false) {
    const write = () => {
      cameraSaveTimer = 0;
      const canvas = $('#canvas-viewport');
      canvasViewState = { zoom, scrollLeft:canvas.scrollLeft, scrollTop:canvas.scrollTop };
      localStorage.setItem(CANVAS_VIEW_KEY, JSON.stringify(canvasViewState));
    };
    if (immediate) { clearTimeout(cameraSaveTimer); write(); return; }
    clearTimeout(cameraSaveTimer);
    cameraSaveTimer = setTimeout(write, 120);
  }

  function restoreCanvasView() {
    const canvas = $('#canvas-viewport');
    const hasCamera = canvasViewState.scrollLeft != null && canvasViewState.scrollTop != null
      && Number.isFinite(Number(canvasViewState.scrollLeft)) && Number.isFinite(Number(canvasViewState.scrollTop));
    if (hasCamera) {
      canvas.scrollLeft = Math.max(0, Number(canvasViewState.scrollLeft));
      canvas.scrollTop = Math.max(0, Number(canvasViewState.scrollTop));
    } else centerCanvas();
    scheduleSelectionSync();
  }

  function centerCanvas() {
    const canvas = $('#canvas-viewport');
    cancelCameraMotion();
    const stageCenterX = stage.offsetLeft + stage.offsetWidth / 2;
    const stageCenterY = stage.offsetTop + stage.offsetHeight / 2;
    canvas.scrollLeft = Math.max(0, stageCenterX - canvas.clientWidth / 2);
    canvas.scrollTop = Math.max(0, stageCenterY - canvas.clientHeight / 2);
    persistCanvasView();
  }

  function canvasCameraOffset() {
    const canvas = $('#canvas-viewport');
    const frameCenterX = stage.offsetLeft + stage.offsetWidth / 2 - canvas.scrollLeft;
    const frameCenterY = stage.offsetTop + stage.offsetHeight / 2 - canvas.scrollTop;
    return {
      x: Math.round(frameCenterX - canvas.clientWidth / 2),
      y: Math.round(frameCenterY - canvas.clientHeight / 2),
    };
  }

  function showCameraHUD(action = '手型平移', options = {}) {
    const hud = $('#canvas-camera-hud');
    if (!hud) return;
    clearTimeout(cameraHudTimer);
    const offset = canvasCameraOffset();
    $('#canvas-camera-action').textContent = action;
    $('#canvas-camera-zoom').textContent = `${Math.round(zoom * 100)}%`;
    $('#canvas-camera-offset').textContent = Math.abs(offset.x) < 2 && Math.abs(offset.y) < 2
      ? '画板居中'
      : `画板 X ${offset.x >= 0 ? '+' : ''}${offset.x} · Y ${offset.y >= 0 ? '+' : ''}${offset.y}`;
    hud.hidden = false;
    requestAnimationFrame(() => { hud.dataset.visible = 'true'; });
    if (!options.hold) hideCameraHUD(options.delay ?? 620);
  }

  function hideCameraHUD(delay = 420) {
    const hud = $('#canvas-camera-hud');
    if (!hud) return;
    clearTimeout(cameraHudTimer);
    cameraHudTimer = setTimeout(() => {
      hud.dataset.visible = 'false';
      cameraHudTimer = setTimeout(() => { hud.hidden = true; }, 190);
    }, delay);
  }

  function cancelCameraMotion() {
    if (cameraMotionFrame) cancelAnimationFrame(cameraMotionFrame);
    cameraMotionFrame = 0;
  }

  function animateCameraTo(left, top, options = {}) {
    const canvas = $('#canvas-viewport');
    const maxLeft = Math.max(0, canvas.scrollWidth - canvas.clientWidth);
    const maxTop = Math.max(0, canvas.scrollHeight - canvas.clientHeight);
    const targetLeft = Math.max(0, Math.min(maxLeft, left));
    const targetTop = Math.max(0, Math.min(maxTop, top));
    const shouldAnimate = options.animate !== false && !matchMedia('(prefers-reduced-motion: reduce)').matches;
    cancelCameraMotion();
    if (!shouldAnimate) {
      canvas.scrollLeft = targetLeft;
      canvas.scrollTop = targetTop;
      scheduleSelectionSync();
      persistCanvasView();
      return;
    }
    const startLeft = canvas.scrollLeft;
    const startTop = canvas.scrollTop;
    const startedAt = performance.now();
    const duration = 180;
    showCameraHUD(options.action || '定位图层', { hold:true });
    const step = (time) => {
      const progress = Math.min(1, (time - startedAt) / duration);
      const eased = 1 - Math.pow(1 - progress, 4);
      canvas.scrollLeft = startLeft + (targetLeft - startLeft) * eased;
      canvas.scrollTop = startTop + (targetTop - startTop) * eased;
      scheduleSelectionSync();
      showCameraHUD(options.action || '定位图层', { hold:true });
      if (progress < 1) cameraMotionFrame = requestAnimationFrame(step);
      else {
        cameraMotionFrame = 0;
        persistCanvasView(true);
        hideCameraHUD();
      }
    };
    cameraMotionFrame = requestAnimationFrame(step);
  }

  function refreshFitModeUI() {
    if ($('#canvas-fit-select')) $('#canvas-fit-select').value = canvasFitMode;
    if ($('#canvas-fit-status')) $('#canvas-fit-status').textContent = `${FIT_MODE_LABELS[canvasFitMode] || '手动'} · ${Math.round(zoom * 100)}%`;
    $('#canvas-viewport').dataset.fitMode = canvasFitMode;
  }

  function setManualZoom(nextZoom, options = {}) {
    cancelCameraMotion();
    canvasFitMode = 'manual';
    autoFitCanvas = false;
    zoom = Math.max(.05, Math.min(3, nextZoom));
    localStorage.setItem(CANVAS_MODE_KEY, canvasFitMode);
    updateCanvasScale(options);
    refreshFitModeUI();
    persistCanvasView();
  }

  function zoomAtPoint(clientX, clientY, nextZoom, options = {}) {
    const canvas = $('#canvas-viewport');
    const canvasRect = canvas.getBoundingClientRect();
    const cursorX = clientX - canvasRect.left;
    const cursorY = clientY - canvasRect.top;
    const documentX = (canvas.scrollLeft + cursorX - stage.offsetLeft) / zoom;
    const documentY = (canvas.scrollTop + cursorY - stage.offsetTop) / zoom;
    setManualZoom(nextZoom, options);
    canvas.scrollLeft = Math.max(0, stage.offsetLeft + documentX * zoom - cursorX);
    canvas.scrollTop = Math.max(0, stage.offsetTop + documentY * zoom - cursorY);
    scheduleSelectionSync();
    persistCanvasView();
    showCameraHUD('缩放画布');
  }

  function zoomAtCanvasCenter(nextZoom) {
    const canvasRect = $('#canvas-viewport').getBoundingClientRect();
    zoomAtPoint(canvasRect.left + canvasRect.width / 2, canvasRect.top + canvasRect.height / 2, nextZoom);
  }

  function handleCanvasTrackpadPan(event) {
    const canvas = $('#canvas-viewport');
    cancelCameraMotion();
    if (panInertiaFrame) cancelAnimationFrame(panInertiaFrame);
    panInertiaFrame = 0;
    canvasFitMode = 'manual';
    autoFitCanvas = false;
    localStorage.setItem(CANVAS_MODE_KEY, canvasFitMode);
    const lineScale = event.deltaMode === 1 ? 18 : 1;
    const horizontal = event.shiftKey ? event.deltaY : event.deltaX;
    const vertical = event.shiftKey ? 0 : event.deltaY;
    canvas.scrollLeft += horizontal * lineScale;
    canvas.scrollTop += vertical * lineScale;
    refreshFitModeUI();
    scheduleSelectionSync();
    persistCanvasView();
    showCameraHUD(event.shiftKey ? '横向平移' : '触控板平移');
  }

  function handleCanvasWheel(event, clientX = event.clientX, clientY = event.clientY) {
    if (event.ctrlKey || event.metaKey) return;
    event.preventDefault();
    if (canvasPanActive) return;
    if (!event.altKey) {
      handleCanvasTrackpadPan(event);
      return;
    }
    cancelCameraMotion();
    const delta = event.deltaMode === 1 ? event.deltaY * 18 : event.deltaY;
    wheelZoomDelta += delta;
    wheelZoomPoint = { x:clientX, y:clientY };
    if (wheelZoomFrame) return;
    wheelZoomFrame = requestAnimationFrame(() => {
      wheelZoomFrame = 0;
      const factor = Math.max(.84, Math.min(1.19, Math.exp(-wheelZoomDelta * .00105)));
      wheelZoomDelta = 0;
      const point = wheelZoomPoint;
      wheelZoomPoint = null;
      zoomAtPoint(point.x, point.y, zoom * factor, { deferHeavy:true });
    });
  }

  function refreshPanTool() {
    document.body.classList.toggle('pan-ready', handToolEnabled || spacePanPressed);
    const handToggle = $('#toggle-hand');
    handToggle.classList.toggle('active', handToolEnabled);
    handToggle.setAttribute('aria-pressed', String(handToolEnabled));
    renderStatusBar();
  }

  function canvasPanPoint(event, frameCoordinates = false) {
    if (!frameCoordinates) return { x:event.clientX, y:event.clientY, time:event.timeStamp || performance.now() };
    const frameRect = frame.getBoundingClientRect();
    const scaleX = frame.clientWidth ? frameRect.width / frame.clientWidth : zoom;
    const scaleY = frame.clientHeight ? frameRect.height / frame.clientHeight : zoom;
    return {
      x:frameRect.left + event.clientX * scaleX,
      y:frameRect.top + event.clientY * scaleY,
      time:event.timeStamp || performance.now()
    };
  }

  function beginCanvasPan(event, moveTarget = window, clearOnClick = false) {
    if (![0,1].includes(event.button)) return;
    const canvas = $('#canvas-viewport');
    const frameCoordinates = moveTarget === frameDocument;
    const startPoint = canvasPanPoint(event, frameCoordinates);
    const captureTarget = typeof event.target?.setPointerCapture === 'function' ? event.target : canvas;
    cancelCameraMotion();
    if (panInertiaFrame) cancelAnimationFrame(panInertiaFrame);
    panInertiaFrame = 0;
    canvas.scrollTo({ left:canvas.scrollLeft, top:canvas.scrollTop, behavior:'instant' });
    const startX = startPoint.x;
    const startY = startPoint.y;
    const startLeft = canvas.scrollLeft;
    const startTop = canvas.scrollTop;
    let moved = false;
    let latestPanEvent = null;
    let panFrame = 0;
    let lastSample = { x:startX, y:startY, time:startPoint.time };
    let velocityX = 0;
    let velocityY = 0;
    let panDistance = 0;
    const allowMomentum = event.pointerType === 'touch' && !event.altKey;
    canvasPanActive = true;
    document.body.classList.add('canvas-panning');
    showCameraHUD('手型平移', { hold:true });
    try { captureTarget.setPointerCapture(event.pointerId); } catch {}
    event.preventDefault();

    const flushPan = () => {
      panFrame = 0;
      if (!latestPanEvent) return;
      const moveEvent = latestPanEvent;
      latestPanEvent = null;
      const distance = Math.hypot(moveEvent.x - startX, moveEvent.y - startY);
      panDistance = Math.max(panDistance, distance);
      if (distance > 4 && !moved) {
        moved = true;
        canvasFitMode = 'manual';
        autoFitCanvas = false;
        localStorage.setItem(CANVAS_MODE_KEY, canvasFitMode);
        refreshFitModeUI();
      }
      const sampleTime = moveEvent.time;
      const elapsed = Math.max(1, sampleTime - lastSample.time);
      velocityX = velocityX * .62 + (lastSample.x - moveEvent.x) / elapsed * .38;
      velocityY = velocityY * .62 + (lastSample.y - moveEvent.y) / elapsed * .38;
      velocityX = Math.max(-.55, Math.min(.55, velocityX));
      velocityY = Math.max(-.55, Math.min(.55, velocityY));
      lastSample = { x:moveEvent.x, y:moveEvent.y, time:sampleTime };
      canvas.scrollLeft = startLeft - (moveEvent.x - startX);
      canvas.scrollTop = startTop - (moveEvent.y - startY);
      scheduleSelectionSync();
      showCameraHUD('手型平移', { hold:true });
    };
    const move = (moveEvent) => {
      const samples = moveEvent.getCoalescedEvents?.() || [];
      latestPanEvent = canvasPanPoint(samples.at(-1) || moveEvent, frameCoordinates);
      if (!panFrame) panFrame = requestAnimationFrame(flushPan);
    };
    const end = () => {
      if (panFrame) cancelAnimationFrame(panFrame);
      flushPan();
      document.body.classList.remove('canvas-panning');
      canvasPanActive = false;
      try { captureTarget.releasePointerCapture(event.pointerId); } catch {}
      moveTarget.removeEventListener('pointermove', move, true);
      moveTarget.removeEventListener('pointerup', end, true);
      moveTarget.removeEventListener('pointercancel', end, true);
      if (clearOnClick && !moved) clearSelection();
      if (allowMomentum && moved && panDistance > 24 && !matchMedia('(prefers-reduced-motion: reduce)').matches && Math.hypot(velocityX, velocityY) > .12) {
        let previousTime = performance.now();
        const coast = (time) => {
          const elapsed = Math.min(32, time - previousTime);
          previousTime = time;
          canvas.scrollLeft += velocityX * elapsed;
          canvas.scrollTop += velocityY * elapsed;
          const friction = Math.pow(.78, elapsed / 16.67);
          velocityX *= friction;
          velocityY *= friction;
          scheduleSelectionSync();
          if (Math.hypot(velocityX, velocityY) > .022) panInertiaFrame = requestAnimationFrame(coast);
          else { panInertiaFrame = 0; persistCanvasView(true); hideCameraHUD(); }
        };
        panInertiaFrame = requestAnimationFrame(coast);
      } else { persistCanvasView(true); hideCameraHUD(); }
    };
    moveTarget.addEventListener('pointermove', move, true);
    moveTarget.addEventListener('pointerup', end, true);
    moveTarget.addEventListener('pointercancel', end, true);
  }

  function applyCanvasFitMode(mode = 'contain', notify = true) {
    const safeMode = ['contain','cover','width','height','actual'].includes(mode) ? mode : 'contain';
    canvasFitMode = safeMode;
    autoFitCanvas = true;
    localStorage.setItem(CANVAS_MODE_KEY, safeMode);
    const available = availableCanvasSize();
    const widthRatio = available.width / viewport.width;
    const heightRatio = available.height / viewport.height;
    if (safeMode === 'cover') zoom = Math.max(widthRatio, heightRatio);
    else if (safeMode === 'width') zoom = widthRatio;
    else if (safeMode === 'height') zoom = heightRatio;
    else if (safeMode === 'actual') zoom = 1;
    else zoom = Math.min(widthRatio, heightRatio);
    zoom = Math.max(.05, Math.min(3, zoom));
    updateCanvasScale();
    refreshFitModeUI();
    requestAnimationFrame(centerCanvas);
    if (notify) showToast(`${FIT_MODE_LABELS[safeMode]}模式 · ${Math.round(zoom * 100)}%`);
  }

  function fitCanvas(notify = true) {
    applyCanvasFitMode('contain', notify);
  }

  function returnCanvasToView(notify = true) {
    fitCanvas(false);
    requestAnimationFrame(() => {
      showCameraHUD('回到画面');
      if (notify) showToast('画面已适应并居中 · Ctrl+0');
    });
  }

  function save() { return saveProject(); }

  function download(filename, type, content) {
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([content], { type }));
    link.download = filename;
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  }

  function buildOverrideCSS() {
    const blocks = Object.entries(overrides).filter(([,value]) => Object.keys(value).length).map(([id, value]) => {
      const declarations = [];
      if (value.x || value.y) declarations.push(`  translate: ${number(value.x)}px ${number(value.y)}px;`);
      if (value.scale !== undefined && value.scale !== '') {
        declarations.push(`  scale: ${value.scale};`);
        declarations.push('  transform-origin: top left;');
      }
      if (value.rotation !== undefined && value.rotation !== '') declarations.push(`  rotate: ${value.rotation}deg;`);
      const names = { width:'width',height:'height',backgroundColor:'background-color',color:'color',fontSize:'font-size',fontFamily:'font-family',fontWeight:'font-weight',lineHeight:'line-height',letterSpacing:'letter-spacing',textAlign:'text-align',borderRadius:'border-radius',borderWidth:'border-width',borderColor:'border-color',borderStyle:'border-style',opacity:'opacity',padding:'padding',display:'display',zIndex:'z-index',position:'position' };
      Object.entries(names).forEach(([key, cssName]) => {
        if (value[key] === undefined || value[key] === '') return;
        const suffix = ['width','height','fontSize','lineHeight','letterSpacing','borderRadius','borderWidth','padding'].includes(key) ? 'px' : '';
        declarations.push(`  ${cssName}: ${value[key]}${suffix};`);
      });
      if (['shadowX','shadowY','shadowBlur','shadowSpread','shadowColor'].some((key) => value[key] !== undefined && value[key] !== '')) {
        declarations.push(`  box-shadow: ${number(value.shadowX)}px ${number(value.shadowY)}px ${Math.max(0,number(value.shadowBlur))}px ${number(value.shadowSpread)}px ${value.shadowColor || '#00000033'};`);
      }
      return `[data-ui-id="${id}"] {\n${declarations.join('\n')}\n}`;
    });
    return `/* UI Studio export · ${new Date().toISOString()} */\n\n${blocks.join('\n\n')}\n`;
  }

  function exportCSS() {
    download('ui-overrides.css', 'text/css;charset=utf-8', buildOverrideCSS());
    showToast('CSS 已导出');
  }

  function injectIconReplacementsIntoHTML(source) {
    const documentHtml = new DOMParser().parseFromString(source, 'text/html');
    for (const insertion of structuralEdits.insertions || []) {
      if (documentHtml.querySelector(`[data-ui-id="${CSS.escape(insertion.id)}"]`)) continue;
      const sourceElement = documentHtml.querySelector(`[data-ui-id="${CSS.escape(insertion.sourceId)}"]`);
      if (!sourceElement) continue;
      const parent = insertion.parentId
        ? documentHtml.querySelector(`[data-ui-id="${CSS.escape(insertion.parentId)}"]`)
        : sourceElement.parentElement;
      if (!parent) continue;
      const duplicate = sourceElement.cloneNode(true);
      [duplicate, ...duplicate.querySelectorAll('[data-ui-id]')].forEach((element) => {
        const nextId = insertion.idMap?.[element.dataset.uiId];
        if (nextId) element.dataset.uiId = nextId;
      });
      duplicate.dataset.uiName = insertion.name || `${labelFor(insertion.sourceId)} 副本`;
      const after = insertion.afterId
        ? documentHtml.querySelector(`[data-ui-id="${CSS.escape(insertion.afterId)}"]`)
        : null;
      if (after?.parentElement === parent) after.after(duplicate);
      else parent.append(duplicate);
    }
    Object.entries(iconReplacements).forEach(([id, replacement]) => {
      const svg = documentHtml.querySelector(`svg[data-ui-id="${CSS.escape(id)}"]`);
      if (!svg) return;
      svg.innerHTML = replacement.body;
      svg.setAttribute('viewBox', replacement.viewBox);
      svg.setAttribute('data-ui-icon-source', replacement.name || 'custom');
    });
    Object.entries(overrides).forEach(([id, value]) => {
      if (value.textContent === undefined) return;
      const element = documentHtml.querySelector(`[data-ui-id="${CSS.escape(id)}"]`);
      if (element && !element.children.length) element.textContent = value.textContent;
    });
    return `<!doctype html>\n${documentHtml.documentElement.outerHTML}`;
  }

  async function exportHTML() {
    try {
      const [html, css, app] = await Promise.all([
        fetch('index.html').then((response) => response.text()),
        fetch('styles.css').then((response) => response.text()),
        fetch('app.js').then((response) => response.text())
      ]);
      const overrideCSS = buildOverrideCSS();
      const safeApp = app.replace(/<\/script/gi, '<\\/script');
      const standalone = injectIconReplacementsIntoHTML(html)
        .replace(/<link\s+rel="stylesheet"\s+href="styles\.css"\s*\/?>/i, () => `<style>\n${css}\n\n${overrideCSS}\n</style>`)
        .replace(/<script\s+src="ui-studio-structure\.js"><\/script>/i, '')
        .replace(/<script\s+src="app\.js"><\/script>/i, () => `<script>\n${safeApp}\n<\/script>`);
      download('ui-adjusted.html', 'text/html;charset=utf-8', standalone);
      showToast('已导出可直接打开的 UI 源码');
    } catch (error) {
      console.error(error);
      showToast('导出失败，请通过本地服务打开 Studio');
    }
  }

  function exportJSON() {
    download('ui-overrides.json', 'application/json;charset=utf-8', JSON.stringify({ version:3, canvas:viewport, overrides, iconReplacements, structuralEdits, layerMetadata }, null, 2));
    showToast('JSON 已导出');
  }

  const PROPERTY_LABELS = {
    x:'水平位置', y:'垂直位置', width:'宽度', height:'高度', scale:'缩放', backgroundColor:'背景', color:'颜色', textContent:'文字内容',
    fontFamily:'字体', fontWeight:'字重', fontSize:'字号', lineHeight:'行高', letterSpacing:'字距', textAlign:'文字对齐', rotation:'旋转',
    borderRadius:'圆角', borderWidth:'描边', borderColor:'描边颜色', borderStyle:'描边样式', shadowX:'投影 X', shadowY:'投影 Y',
    shadowBlur:'投影模糊', shadowSpread:'投影扩展', shadowColor:'投影颜色', opacity:'透明度', padding:'内边距'
  };

  function showPropertyFeedback(key) {
    if (!selectedId) return;
    selectionBox?.classList.add('property-feedback');
    clearTimeout(showPropertyFeedback.timer);
    showPropertyFeedback.timer = setTimeout(() => selectionBox?.classList.remove('property-feedback'), 260);
    showToast(`${PROPERTY_LABELS[key] || '属性'}已更新 · Ctrl+Z 撤销`);
  }

  const inputBindings = {
    '#prop-x': ['x', (value) => number(value)], '#prop-y': ['y', (value) => number(value)], '#prop-width': ['width', (value) => Math.max(1,number(value))],
    '#prop-height': ['height', (value) => Math.max(1,number(value))], '#prop-scale': ['scale', (value) => Math.min(10,Math.max(.05,number(value)/100))],
    '#prop-bg': ['backgroundColor', String], '#prop-color': ['color', String], '#prop-text-content': ['textContent', String],
    '#prop-font-family': ['fontFamily', (value) => FONT_FAMILIES[value] || FONT_FAMILIES.system], '#prop-font-weight': ['fontWeight', (value) => Math.max(100,number(value))],
    '#prop-font-size': ['fontSize', (value) => Math.max(8,number(value))], '#prop-line-height': ['lineHeight', (value) => Math.max(8,number(value))],
    '#prop-letter-spacing': ['letterSpacing', (value) => Math.max(-10,Math.min(40,number(value)))], '#prop-text-align': ['textAlign', String],
    '#prop-rotation': ['rotation', (value) => Math.max(-360,Math.min(360,number(value)))], '#prop-radius': ['borderRadius', (value) => Math.max(0,number(value))],
    '#prop-border-width': ['borderWidth', (value) => Math.max(0,number(value))], '#prop-border-color': ['borderColor', String], '#prop-border-style': ['borderStyle', String],
    '#prop-shadow-x': ['shadowX', (value) => number(value)], '#prop-shadow-y': ['shadowY', (value) => number(value)], '#prop-shadow-blur': ['shadowBlur', (value) => Math.max(0,number(value))],
    '#prop-shadow-spread': ['shadowSpread', (value) => number(value)], '#prop-shadow-color': ['shadowColor', String],
    '#prop-opacity': ['opacity', (value) => Math.min(1,Math.max(0,number(value)/100))], '#prop-padding': ['padding', (value) => Math.max(0,number(value))]
  };
  Object.entries(inputBindings).forEach(([selector, [key, transformValue]]) => {
    const input = $(selector);
    input.addEventListener('input', () => {
      const next = transformValue(input.value);
      const before = computedValues();
      if ($('#aspect-lock').checked && before && (key === 'width' || key === 'height')) {
        const ratio = Math.max(.01, before.width / before.height);
        setValue(key, next, false);
        setValue(key === 'width' ? 'height' : 'width', key === 'width' ? next / ratio : next * ratio, false);
        applyOverride(selectedId);
        updateInspector();
        requestAnimationFrame(drawSelection);
      } else if (key === 'borderWidth') {
        setValue(key, next, false);
        if (next > 0 && getComputedStyle(selectedElement()).borderTopStyle === 'none') setValue('borderStyle', 'solid', false);
        applyOverride(selectedId);
        updateInspector();
        requestAnimationFrame(drawSelection);
      } else {
        setValue(key, next);
      }
      clearTimeout(input.commitTimer);
      input.commitTimer = setTimeout(() => commit({
        label:PROPERTY_HISTORY_LABELS[key] || '编辑属性',
        type:key === 'textContent' ? 'content.change' : 'property.change',
        targetIds:selectedId ? [selectedId] : [],
        detail:{ property:key },
        mergeKey:`property:${selectedId || 'none'}:${key}`,
      }), 180);
    });
    input.addEventListener('change', () => {
      clearTimeout(input.commitTimer);
      commit({
        label:PROPERTY_HISTORY_LABELS[key] || '编辑属性',
        type:key === 'textContent' ? 'content.change' : 'property.change',
        targetIds:selectedId ? [selectedId] : [],
        detail:{ property:key },
        mergeKey:`property:${selectedId || 'none'}:${key}`,
      });
      showPropertyFeedback(key);
    });
  });

  function fitSelectedProportion() {
    const element = selectedElement();
    if (!element || !selectedId) return;
    const base = baseSizes.get(selectedId);
    if (!base?.width || !base?.height) { showToast('当前图层没有可用的原始尺寸'); return; }
    overrides[selectedId] ||= {};
    ['x','y','width','height','scale'].forEach((key) => delete overrides[selectedId][key]);
    if (!Object.keys(overrides[selectedId]).length) delete overrides[selectedId];
    applyOverride(selectedId);

    const naturalRect = element.getBoundingClientRect();
    const parentElement = element.parentElement;
    const parentRect = parentElement.getBoundingClientRect();
    const parentStyle = getComputedStyle(parentElement);
    const contentRight = parentRect.right - number(parentStyle.paddingRight);
    const contentBottom = parentRect.bottom - number(parentStyle.paddingBottom);
    const availableWidth = Math.max(1, contentRight - naturalRect.left);
    const availableHeight = Math.max(1, contentBottom - naturalRect.top);
    const nextScale = Math.max(.05, Math.min(10, availableWidth / base.width, availableHeight / base.height));
    if (Math.abs(nextScale - 1) > .001) setValue('scale', Number(nextScale.toFixed(4)), false);
    applyOverride(selectedId);
    updateInspector();
    drawSelection();
    commit({ label:`等比放大 ${labelFor(selectedId)}`, type:'geometry.fit', targetIds:[selectedId], detail:{ mode:'proportional' } });
    if (selectedId === 'app.shell') fitCanvas(false);
    showToast(`${labelFor(selectedId)}已连同子内容等比最大化 · ${Math.round(nextScale * 100)}%`);
  }

  function snapSelectedToIntersection() {
    const element = selectedElement();
    if (!element || !selectedId) return;
    const rect = element.getBoundingClientRect();
    const verticals = guides.filter((guide) => guide.axis === 'vertical').map((guide) => guide.position);
    const horizontals = guides.filter((guide) => guide.axis === 'horizontal').map((guide) => guide.position);
    if (!verticals.length) verticals.push(viewport.width / 2);
    if (!horizontals.length) horizontals.push(viewport.height / 2);
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const targetX = verticals.reduce((best, value) => Math.abs(value - centerX) < Math.abs(best - centerX) ? value : best);
    const targetY = horizontals.reduce((best, value) => Math.abs(value - centerY) < Math.abs(best - centerY) ? value : best);
    setValue('x', Math.round(number(overrides[selectedId]?.x) + targetX - centerX), false);
    setValue('y', Math.round(number(overrides[selectedId]?.y) + targetY - centerY), false);
    applyOverride(selectedId); updateInspector(); drawSelection();
    commit({ label:`吸附 ${labelFor(selectedId)} 到交点`, type:'geometry.snap', targetIds:[selectedId], detail:{ x:Math.round(targetX), y:Math.round(targetY) } });
    showSnapFeedback(targetX, targetY);
    clearTimeout(snapSelectedToIntersection.timer);
    snapSelectedToIntersection.timer = setTimeout(hideSnapFeedback, 5000);
    showToast(`已吸附到参考线交点 · ${Math.round(targetX)}, ${Math.round(targetY)}`);
  }

  $('.quick-actions').addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button || !selectedId) return;
    const element = selectedElement();
    const parent = element.parentElement.getBoundingClientRect();
    const rect = element.getBoundingClientRect();
    if (button.dataset.action === 'center-x') setValue('x', Math.round(number(overrides[selectedId]?.x) + parent.left + parent.width/2 - (rect.left + rect.width/2)));
    if (button.dataset.action === 'center-y') setValue('y', Math.round(number(overrides[selectedId]?.y) + parent.top + parent.height/2 - (rect.top + rect.height/2)));
    if (button.dataset.action === 'fit-width') { setValue('width', Math.max(18,Math.round(parent.width))); setValue('x', Math.round(number(overrides[selectedId]?.x) + parent.left - rect.left)); }
    if (button.dataset.action === 'fit-height') { setValue('height', Math.max(18,Math.round(parent.height))); setValue('y', Math.round(number(overrides[selectedId]?.y) + parent.top - rect.top)); }
    if (button.dataset.action === 'fill-parent') {
      setValue('width', Math.max(18,Math.round(parent.width)), false);
      setValue('height', Math.max(18,Math.round(parent.height)), false);
      setValue('x', Math.round(number(overrides[selectedId]?.x) + parent.left - rect.left), false);
      setValue('y', Math.round(number(overrides[selectedId]?.y) + parent.top - rect.top), false);
      applyOverride(selectedId); updateInspector(); drawSelection();
    }
    if (button.dataset.action === 'fit-proportion') { fitSelectedProportion(); return; }
    if (button.dataset.action === 'snap-intersection') { snapSelectedToIntersection(); return; }
    if (button.dataset.action === 'select-parent') {
      const parentNode = nodes.find((node) => node.id === selectedId)?.parentId;
      if (parentNode) select(parentNode);
      return;
    }
    if (button.dataset.action === 'clear') { delete overrides[selectedId]; applyOverride(selectedId); updateInspector(); drawSelection(); }
    const quickLabels = { 'center-x':'水平居中', 'center-y':'垂直居中', 'fit-width':'宽度适配', 'fit-height':'高度适配', 'fill-parent':'铺满父级', clear:'清除调整' };
    commit({ label:`${quickLabels[button.dataset.action] || '快速调整'} ${labelFor(selectedId)}`, type:'layout.quick-adjust', targetIds:[selectedId], detail:{ action:button.dataset.action } });
  });

  $('#layer-search').addEventListener('input', (event) => renderLayers(event.target.value));
  $$('[data-feature]').forEach((button) => button.addEventListener('click', () => {
    const camera = captureCanvasCamera() || parkedFeatureCamera;
    if (document.body.classList.contains('layers-collapsed')) togglePanel('layers-collapsed');
    activateFeature(button.dataset.feature, true, { cameraSnapshot:camera });
  }));
  $$('[data-feature-search]').forEach((input) => input.addEventListener('input', () => {
    const feature = input.dataset.featureSearch;
    const container = { icons:'#feature-icon-list', text:'#feature-text-list', frames:'#feature-frame-list' }[feature];
    if (container) renderFeatureObjectList(feature, container);
  }));
  $$('[data-feature-dev-toggle]').forEach((button) => button.addEventListener('click', () => {
    featureState.showDeveloper = !featureState.showDeveloper;
    $('.feature-workspace').classList.toggle('show-feature-dev', featureState.showDeveloper);
    $$('[data-feature-dev-toggle]').forEach((item) => item.setAttribute('aria-pressed', String(featureState.showDeveloper)));
    saveFeatureState();
    showToast(featureState.showDeveloper ? '已显示开发信息' : '已隐藏开发信息');
  }));
  $('#selection-locate').addEventListener('click', focusSelectedInCanvas);
  $('#inspector-locate-selection').addEventListener('click', focusSelectedInCanvas);
  $('#multi-selection-locate').addEventListener('click', focusSelectedInCanvas);
  $('#multi-inspector').addEventListener('click', (event) => {
    const button = event.target.closest('[data-multi-action]');
    if (button && !button.disabled) applyMultiAction(button.dataset.multiAction);
  });
  $('#open-page-directory').addEventListener('click', focusProjectMenu);
  $('#collapse-empty-inspector').addEventListener('click', () => togglePanel('inspector-collapsed'));
  $('#feature-open-icon-site').addEventListener('click', () => window.open('https://icones.js.org/', '_blank', 'noopener'));
  $('#feature-open-icon-importer').addEventListener('click', () => $('#open-icon-tool').click());
  $('#feature-open-font-library').addEventListener('click', () => $('#open-font-library').click());
  $('#feature-replace-icon').addEventListener('click', openIconTool);
  $('#feature-restore-icon').addEventListener('click', () => {
    const target = resolveSelectedSvgTarget();
    if (!target || !iconReplacements[target.id]) { showToast('当前图标没有替换记录'); return; }
    delete iconReplacements[target.id];
    restoreOriginalIcon(target.id);
    commit({ label:`恢复 ${target.name} 原图标`, type:'replace.asset', targetIds:[target.id], detail:{ restore:true } });
    drawSelection();
    updateContextInspector();
    showToast(`已恢复 ${target.name} 的原图标`);
  });

  function runDeliveryAction(action) {
    if (action === 'compare') { activateFeature('compare'); return; }
    if (action === 'handoff') { handoffToCodex(); return; }
    const target = { preview:'#open-preview', save:'#save', html:'#export-html', css:'#export-css', json:'#export-json' }[action];
    if (target) $(target).click();
  }
  $$('[data-feature-action]').forEach((button) => button.addEventListener('click', () => runDeliveryAction(button.dataset.featureAction)));
  $$('[data-context-action]').forEach((button) => button.addEventListener('click', () => runDeliveryAction(button.dataset.contextAction)));
  $('#delivery-save-project')?.addEventListener('click', saveProject);
  $('#delivery-handoff-codex')?.addEventListener('click', handoffToCodex);
  $('#delivery-exact-preview')?.addEventListener('click', openProjectPreview);
  $('#delivery-open-compare')?.addEventListener('click', () => activateFeature('compare'));
  window.addEventListener('ui-fidelity-updated', (event) => {
    if (!syncStatus) return;
    syncStatus = { ...syncStatus, qualityGate:event.detail?.qualityGate || null };
    renderSyncStatus();
  });
  $('#open-reference-control')?.addEventListener('click', openReferenceControl);
  $$('[data-selection-scope]').forEach((button) => button.addEventListener('click', () => {
    applySelectionScope(button.dataset.selectionScope);
  }));
  $('#selection-scope-select')?.addEventListener('change', (event) => applySelectionScope(event.target.value));
  $$('[data-layer-filter]').forEach((button) => button.addEventListener('click', () => {
    layerFilter = button.dataset.layerFilter;
    $$('[data-layer-filter]').forEach((item) => item.classList.toggle('active', item === button));
    renderLayers($('#layer-search').value);
  }));
  $('#layer-filter-select')?.addEventListener('change', (event) => {
    layerFilter = event.target.value;
    renderLayers($('#layer-search').value);
  });
  $('#expand-layer-tree')?.addEventListener('click', () => {
    collapsedNodes.clear();
    localStorage.setItem(TREE_STATE_KEY, JSON.stringify([]));
    renderLayers($('#layer-search').value);
    showToast('已展开全部图层');
  });
  $('#collapse-layer-tree')?.addEventListener('click', () => {
    const viewNodes = structureViewNodes();
    collapsedNodes = new Set(viewNodes.filter((node) => viewDescendantIds(viewNodes, node.id).size).map((node) => node.id));
    localStorage.setItem(TREE_STATE_KEY, JSON.stringify([...collapsedNodes]));
    renderLayers($('#layer-search').value);
    showToast('已折叠全部图层组');
  });
  $('#zoom-out').addEventListener('click', () => zoomAtCanvasCenter(zoom-.05));
  $('#zoom-in').addEventListener('click', () => zoomAtCanvasCenter(zoom+.05));
  $('#canvas-fit-select').addEventListener('change', (event) => applyCanvasFitMode(event.target.value));
  $('#return-to-canvas').addEventListener('click', () => returnCanvasToView());
  $('#focus-fit').addEventListener('click', () => returnCanvasToView());
  $('#focus-cover').addEventListener('click', () => applyCanvasFitMode('cover'));
  $('#toggle-hand').addEventListener('click', () => {
    handToolEnabled = !handToolEnabled;
    refreshPanTool();
    showToast(handToolEnabled ? '手型工具已开启；拖动任意位置平移画布' : '已返回选择工具');
  });
  $('#toggle-snap').addEventListener('click', (event) => {
    snapEnabled = !snapEnabled;
    event.currentTarget.classList.toggle('active', snapEnabled);
    lastSnapStatus = '';
    renderStatusBar();
    showToast(snapEnabled ? '精细吸附已开启：参考线 3px、结构 4px；按 Alt 临时绕过' : '自动吸附已关闭');
  });
  $('#toggle-grid').addEventListener('click', (event) => {
    gridEnabled = !gridEnabled;
    document.body.classList.toggle('grid-enabled', gridEnabled);
    event.currentTarget.classList.toggle('active', gridEnabled);
    showToast(gridEnabled ? '8px 网格和网格吸附已开启' : '网格吸附已关闭');
  });
  $('#toggle-guides').addEventListener('click', (event) => {
    guidesVisible = !guidesVisible;
    refreshGuideVisibilityControl({ persist:true });
    showToast(guidesVisible ? '标尺与辅助线已显示' : '标尺与辅助线已隐藏');
  });
  $('#add-v-guide').addEventListener('click', () => addGuide('vertical'));
  $('#add-h-guide').addEventListener('click', () => addGuide('horizontal'));
  $('#clear-guides').addEventListener('click', () => {
    if (!guides.length) { showToast('当前没有参考线'); return; }
    const count = guides.length;
    guides = []; saveGuides(); renderGuides();
    commit({ label:`清除 ${count} 条参考线`, type:'guide.clear', targetIds:[], detail:{ count } });
    showToast('参考线已全部清除');
  });
  $$('.viewport').forEach((button) => button.addEventListener('click', () => {
    $$('.viewport').forEach((item) => item.classList.remove('active')); button.classList.add('active');
    if ($('#viewport-select')) $('#viewport-select').value = `${button.dataset.width}x${button.dataset.height}`;
    setViewport(Number(button.dataset.width), Number(button.dataset.height));
  }));
  $('#viewport-select').addEventListener('change', (event) => {
    const [width, height] = event.target.value.split('x');
    const button = $(`.viewport[data-width="${width}"][data-height="${height}"]`);
    if (button) button.click();
  });
  $('#reference-visible').addEventListener('change', (event) => setReferenceVisible(event.target.checked));
  $$('[data-reference-layer]').forEach((button) => button.addEventListener('click', () => setReferenceLayer(button.dataset.referenceLayer)));
  $('#reference-opacity').addEventListener('input', (event) => setReferenceStrength(event.target.value));
  applyReferenceViewState({ persist:false });
  $('#undo').addEventListener('click', undoCommand);
  $('#redo').addEventListener('click', redoCommand);
  $('#reset').addEventListener('click', () => {
    overrides = {};
    iconReplacements = {};
    commit({ label:'重置全部 UI 调整', type:'document.reset', targetIds:nodes.map((node) => node.id) });
    applyAll();
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(ICONS_KEY);
    showToast('已恢复原始 UI，可撤销');
  });
  $('#save').addEventListener('click', save);
  $('#sync-handoff').addEventListener('click', handoffToCodex);
  $('#sync-pull').addEventListener('click', pullCodexLatest);
  $('#sync-diff').addEventListener('click', () => showSyncDiff());
  $('#sync-recover-draft')?.addEventListener('click', restoreIsolatedDraft);
  $('#sync-discard-recovery')?.addEventListener('click', discardIsolatedDraft);
  $('#studio-update-reload')?.addEventListener('click', () => {
    saveLocalDraft();
    location.reload();
  });
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) refreshProjectSync({ silent:true });
  });
  $('#sync-history-select').addEventListener('change', (event) => { $('#sync-restore').disabled = !event.target.value; });
  $('#sync-restore').addEventListener('click', restoreSyncHistory);
  $('#sync-menu').addEventListener('toggle', () => { if ($('#sync-menu').open) loadSyncHistory(); });
  $('#close-sync-dialog').addEventListener('click', () => $('#sync-dialog').close());
  $('#sync-dialog').addEventListener('pointerdown', (event) => { if (event.target === event.currentTarget) event.currentTarget.close(); });
  $('#sync-dialog-pull').addEventListener('click', async () => { if (await pullCodexLatest()) $('#sync-dialog').close(); });
  $('#sync-dialog-handoff').addEventListener('click', async () => { await handoffToCodex(); if (!studioDirty) $('#sync-dialog').close(); });
  $('#export-html').addEventListener('click', exportHTML);
  $('#export-css').addEventListener('click', exportCSS);
  $('#export-json').addEventListener('click', exportJSON);
  $('#open-preview').addEventListener('click', openProjectPreview);
  $('#close-project-preview').addEventListener('click', () => $('#project-preview-dialog').close());
  $('#reload-project-preview').addEventListener('click', reloadProjectPreview);
  $('#open-project-preview-window').addEventListener('click', openProjectPreviewWindow);
  $('#project-preview-dialog').addEventListener('pointerdown', (event) => { if (event.target === event.currentTarget) event.currentTarget.close(); });
  $('#open-live-preview').addEventListener('click', openLiveProjectPreview);
  $$('[data-toolbar-menu]').forEach((menu) => {
    menu.addEventListener('toggle', () => {
      if (!menu.open) return;
      $$('[data-toolbar-menu]').forEach((other) => { if (other !== menu) other.open = false; });
    });
  });
  $$('.toolbar-popover button:not([data-keep-menu-open])').forEach((button) => button.addEventListener('click', () => {
    requestAnimationFrame(() => { const menu = button.closest('[data-toolbar-menu]'); if (menu) menu.open = false; });
  }));
  document.addEventListener('pointerdown', (event) => {
    if (event.target.closest('[data-toolbar-menu]')) return;
    $$('[data-toolbar-menu][open]').forEach((menu) => { menu.open = false; });
  });
  $('#open-icon-tool').addEventListener('click', openIconTool);
  $('#open-font-library').addEventListener('click', () => {
    const checks = { 'noto-sans':'Noto Sans SC', 'noto-serif':'Noto Serif SC', lxgw:'LXGW WenKai', jetbrains:'JetBrains Mono' };
    $$('[data-font-card]').forEach((card) => {
      const available = Boolean(frameDocument?.fonts?.check(`12px "${checks[card.dataset.fontCard]}"`));
      const status = $('.font-availability', card);
      status.textContent = available ? '本机可用' : '需安装';
      status.classList.toggle('available', available);
    });
    $('#font-library-dialog').showModal();
  });
  $('#close-font-library').addEventListener('click', () => $('#font-library-dialog').close());
  $('#font-library-dialog').addEventListener('pointerdown', (event) => { if (event.target === event.currentTarget) event.currentTarget.close(); });
  $$('[data-apply-font]').forEach((button) => button.addEventListener('click', () => {
    if (!selectedId || !isTextElement(selectedElement())) { showToast('请先选择一个文字层'); return; }
    setValue('fontFamily', FONT_FAMILIES[button.dataset.applyFont]);
    commit({ label:`更换 ${labelFor(selectedId)} 字体`, type:'property.change', targetIds:[selectedId], detail:{ property:'fontFamily' } });
    $('#font-library-dialog').close();
    showToast('已应用开源字体栈');
  }));
  $('#close-icon-tool').addEventListener('click', () => $('#icon-tool-dialog').close());
  $('#icon-tool-dialog').addEventListener('pointerdown', (event) => {
    if (event.target === event.currentTarget) event.currentTarget.close();
  });
  $('#icon-tool-dialog').addEventListener('keydown', (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') { event.preventDefault(); applyImportedIcon(); }
    event.stopPropagation();
  });
  $('#icon-json-input').addEventListener('input', (event) => {
    clearTimeout(event.currentTarget.parseTimer);
    event.currentTarget.parseTimer = setTimeout(refreshIconImport, 160);
  });
  $('#icon-choice').addEventListener('change', (event) => renderIconCandidate(iconImportEntries[Number(event.target.value)]));
  $('#clear-icon-json').addEventListener('click', () => {
    $('#icon-json-input').value = '';
    refreshIconImport();
    $('#icon-json-input').focus();
  });
  $('#icon-example').addEventListener('click', () => {
    $('#icon-json-input').value = 'tdesign:abstract-filled';
    refreshIconImport();
    $('#icon-json-input').focus();
  });
  $('#paste-icon-json').addEventListener('click', async () => {
    try {
      $('#icon-json-input').value = await navigator.clipboard.readText();
      refreshIconImport();
    } catch {
      setIconImportStatus('浏览器未授权读取剪贴板，请在输入框内按 Ctrl+V', 'error');
      $('#icon-json-input').focus();
    }
  });
  $('#apply-icon-json').addEventListener('click', applyImportedIcon);
  $('#restore-original-icon').addEventListener('click', () => {
    const target = updateIconToolTarget();
    if (!target) { setIconImportStatus('请先选择一个图标层', 'error'); return; }
    if (!iconReplacements[target.id]) { setIconImportStatus('当前图标没有导入替换记录'); return; }
    delete iconReplacements[target.id];
    restoreOriginalIcon(target.id);
    commit({ label:`恢复 ${target.name} 原图标`, type:'replace.asset', targetIds:[target.id], detail:{ restore:true } });
    drawSelection();
    updateIconToolTarget();
    setIconImportStatus(`已恢复 ${target.name} 的原始图标，Ctrl+Z 可撤销`, 'success');
  });

  function refreshPanelButtons() {
    const layersOpen = !document.body.classList.contains('layers-collapsed');
    const inspectorOpen = !document.body.classList.contains('inspector-collapsed');
    $('#toggle-layers').classList.toggle('active', layersOpen);
    $('#toggle-inspector').classList.toggle('active', inspectorOpen);
    $('#toggle-focus').classList.toggle('active', document.body.classList.contains('focus-mode'));
    const layersEdge = $('#edge-toggle-layers');
    const inspectorEdge = $('#edge-toggle-inspector');
    const layersLabel = layersOpen ? '收起左侧内容栏' : '展开左侧内容栏';
    const inspectorLabel = inspectorOpen ? '收起属性面板' : '展开属性面板';
    layersEdge.dataset.panelState = layersOpen ? 'expanded' : 'collapsed';
    layersEdge.dataset.tooltip = layersLabel;
    layersEdge.setAttribute('aria-label', layersLabel);
    layersEdge.setAttribute('aria-expanded', String(layersOpen));
    inspectorEdge.dataset.panelState = inspectorOpen ? 'expanded' : 'collapsed';
    inspectorEdge.dataset.tooltip = inspectorLabel;
    inspectorEdge.setAttribute('aria-label', inspectorLabel);
    inspectorEdge.setAttribute('aria-expanded', String(inspectorOpen));
  }

  function togglePanel(className) {
    const camera = captureCanvasCamera();
    canvasAutoFitSuspended += 1;
    document.body.classList.toggle(className);
    panelState = {
      ...panelState,
      layersCollapsed: document.body.classList.contains('layers-collapsed'),
      inspectorCollapsed: document.body.classList.contains('inspector-collapsed')
    };
    localStorage.setItem(PANEL_STATE_KEY, JSON.stringify(panelState));
    refreshPanelButtons();
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (camera) restoreCanvasCamera(camera, { compensateViewportShift:true });
      setTimeout(() => {
        if (camera) restoreCanvasCamera(camera, { compensateViewportShift:true });
      }, 80);
      setTimeout(() => {
        if (camera) restoreCanvasCamera(camera, { compensateViewportShift:true });
        canvasAutoFitSuspended = Math.max(0, canvasAutoFitSuspended - 1);
      }, 180);
    }));
  }

  function layerWidthBounds() {
    if (window.innerWidth <= 980) return { min:220, max:260 };
    if (window.innerWidth <= 1280) return { min:236, max:310 };
    if (window.innerWidth <= 1600) return { min:260, max:370 };
    return { min:276, max:440 };
  }

  function applyStoredLayersWidth() {
    if (panelState.layersWidth == null || panelState.layersWidth === '' || !Number.isFinite(Number(panelState.layersWidth))) {
      document.documentElement.style.removeProperty('--layers-w');
      return;
    }
    const { min, max } = layerWidthBounds();
    document.documentElement.style.setProperty('--layers-w', `${Math.max(min, Math.min(max, Number(panelState.layersWidth)))}px`);
  }

  function commitLayersWidth(width) {
    const { min, max } = layerWidthBounds();
    panelState = { ...panelState, layersWidth:Math.round(Math.max(min, Math.min(max, width))) };
    localStorage.setItem(PANEL_STATE_KEY, JSON.stringify(panelState));
    applyStoredLayersWidth();
    if (autoFitCanvas) requestAnimationFrame(() => applyCanvasFitMode(canvasFitMode, false));
  }

  const layersResizeHandle = $('#layers-resize-handle');
  layersResizeHandle?.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    const startX = event.clientX;
    const startWidth = document.querySelector('.layers-panel').getBoundingClientRect().width;
    layersResizeHandle.setPointerCapture(event.pointerId);
    layersResizeHandle.classList.add('dragging');
    const move = (moveEvent) => {
      const { min, max } = layerWidthBounds();
      document.documentElement.style.setProperty('--layers-w', `${Math.max(min, Math.min(max, startWidth + moveEvent.clientX - startX))}px`);
    };
    const finish = () => {
      layersResizeHandle.classList.remove('dragging');
      layersResizeHandle.removeEventListener('pointermove', move);
      layersResizeHandle.removeEventListener('pointerup', finish);
      layersResizeHandle.removeEventListener('pointercancel', finish);
      commitLayersWidth(document.querySelector('.layers-panel').getBoundingClientRect().width);
    };
    layersResizeHandle.addEventListener('pointermove', move);
    layersResizeHandle.addEventListener('pointerup', finish);
    layersResizeHandle.addEventListener('pointercancel', finish);
  });
  layersResizeHandle?.addEventListener('dblclick', () => {
    panelState = { ...panelState, layersWidth:null };
    localStorage.setItem(PANEL_STATE_KEY, JSON.stringify(panelState));
    applyStoredLayersWidth();
    showToast('左侧面板已恢复自适应宽度');
  });
  layersResizeHandle?.addEventListener('keydown', (event) => {
    if (!['ArrowLeft','ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    const width = document.querySelector('.layers-panel').getBoundingClientRect().width + (event.key === 'ArrowRight' ? 8 : -8);
    commitLayersWidth(width);
  });

  function setFocusMode(enabled) {
    document.body.classList.toggle('focus-mode', enabled);
    refreshPanelButtons();
    if (autoFitCanvas) requestAnimationFrame(() => applyCanvasFitMode(canvasFitMode, false));
    showToast(enabled ? '已收起全部工具，进入专注画布' : '工具面板已恢复');
  }

  async function toggleFullscreen() {
    const hasIntent = document.body.classList.contains('fullscreen-intent');
    try {
      if (document.fullscreenElement || hasIntent) {
        document.body.classList.remove('fullscreen-intent');
        if (document.fullscreenElement) await document.exitFullscreen();
        setFocusMode(false);
      } else {
        document.body.classList.add('fullscreen-intent');
        setFocusMode(true);
        await document.body.requestFullscreen();
      }
    } catch (error) {
      console.warn('Fullscreen could not be changed.', error);
      showToast('已进入页面全屏；浏览器系统全屏被拦截时可使用 F11');
      updateFullscreenButtons();
    }
  }

  function updateFullscreenButtons() {
    const active = Boolean(document.fullscreenElement);
    const hasIntent = document.body.classList.contains('fullscreen-intent');
    $('#toggle-fullscreen').textContent = active || hasIntent ? '退出全屏' : '全屏';
    $('#toggle-fullscreen').classList.toggle('active', active || hasIntent);
    $('#focus-fullscreen').textContent = active || hasIntent ? '退出全屏' : '进入全屏';
    if (autoFitCanvas) requestAnimationFrame(() => applyCanvasFitMode(canvasFitMode, false));
  }

  $('#toggle-layers').addEventListener('click', () => togglePanel('layers-collapsed'));
  $('#toggle-inspector').addEventListener('click', () => togglePanel('inspector-collapsed'));
  $('#edge-toggle-layers').addEventListener('click', () => togglePanel('layers-collapsed'));
  $('#edge-toggle-inspector').addEventListener('click', () => togglePanel('inspector-collapsed'));
  $('#toggle-focus').addEventListener('click', () => setFocusMode(!document.body.classList.contains('focus-mode')));
  $('#focus-restore').addEventListener('click', async () => {
    document.body.classList.remove('fullscreen-intent');
    if (document.fullscreenElement) await document.exitFullscreen();
    setFocusMode(false);
    updateFullscreenButtons();
  });
  $('#toggle-fullscreen').addEventListener('click', toggleFullscreen);
  $('#focus-fullscreen').addEventListener('click', toggleFullscreen);
  function openRenameLayerDialog() {
    if (!selectedId) { showToast('请先选择要重命名的图层'); return; }
    const dialog = $('#rename-layer-dialog');
    const input = $('#rename-layer-input');
    input.dataset.targetId = selectedId;
    input.value = labelFor(selectedId);
    if (!dialog.open) dialog.showModal();
    requestAnimationFrame(() => { input.focus(); input.select(); });
  }
  function confirmRenameLayer() {
    const input = $('#rename-layer-input');
    const id = input.dataset.targetId;
    const name = input.value.trim();
    if (!id || !frameDocument?.querySelector(`[data-ui-id="${CSS.escape(id)}"]`)) { $('#rename-layer-dialog').close(); return; }
    if (!name) { showToast('图层名称不能为空'); input.focus(); return; }
    if (name === labelFor(id)) { $('#rename-layer-dialog').close(); return; }
    layerMetadata[id] = { name };
    applyLayerMetadata();
    buildLayers();
    select(id);
    commit({ label:`重命名为 ${name}`, type:'layer.rename', targetIds:[id], detail:{ name } });
    $('#rename-layer-dialog').close();
    showToast(`已重命名为“${name}” · F2 可再次修改`);
  }
  $('#rename-layer-confirm').addEventListener('click', confirmRenameLayer);
  ['#rename-layer-close','#rename-layer-cancel'].forEach((selector) => $(selector).addEventListener('click', () => $('#rename-layer-dialog').close()));
  $('#rename-layer-input').addEventListener('keydown', (event) => {
    if (event.key === 'Enter') { event.preventDefault(); confirmRenameLayer(); }
  });
  $('#open-shortcuts').addEventListener('click', () => {
    $('[data-toolbar-menu][open]')?.removeAttribute('open');
    if (!$('#shortcut-dialog').open) $('#shortcut-dialog').showModal();
  });
  ['#close-shortcuts','#shortcut-dialog-done'].forEach((selector) => $(selector).addEventListener('click', () => $('#shortcut-dialog').close()));
  document.addEventListener('fullscreenchange', updateFullscreenButtons);

  function handleStudioKeydown(event) {
    const typing = editingTarget(event.target);
    const command = event.ctrlKey || event.metaKey;
    const key = event.key.toLowerCase();
    if ($('dialog[open]') && !typing) return;
    if (typing) return;
    if (command && event.key.toLowerCase() === 'z') { event.preventDefault(); event.shiftKey ? redoCommand() : undoCommand(); return; }
    if (command && key === 'y') { event.preventDefault(); redoCommand(); return; }
    if (command && key === 'c' && selectedId) { event.preventDefault(); captureLayerClipboard(); return; }
    if (command && key === 'x' && selectedId) { event.preventDefault(); cutSelection(); return; }
    if (command && key === 'v' && !event.altKey) { event.preventDefault(); pasteLayerClipboard({ appearanceOnly:event.shiftKey }); return; }
    if (command && key === 'j' && selectedId) { event.preventDefault(); duplicateSelection(); return; }
    if (command && event.shiftKey && key === 'h' && selectedId) { event.preventDefault(); toggleSelectionVisibility(); return; }
    if (command && event.shiftKey && key === 'l' && selectedId) { event.preventDefault(); toggleSelectionLock(); return; }
    if (command && key === ']' && selectedId) { event.preventDefault(); arrangeSelectionStack(event.shiftKey ? 'front' : 'forward'); return; }
    if (command && key === '[' && selectedId) { event.preventDefault(); arrangeSelectionStack(event.shiftKey ? 'back' : 'backward'); return; }
    if (command && event.altKey && ['arrowleft','arrowright','arrowup','arrowdown'].includes(key)) {
      event.preventDefault();
      applyMultiAction({ arrowleft:'align-left', arrowright:'align-right', arrowup:'align-top', arrowdown:'align-bottom' }[key]);
      return;
    }
    if (command && event.altKey && key === 'h') { event.preventDefault(); applyMultiAction('distribute-x'); return; }
    if (command && event.altKey && key === 'v') { event.preventDefault(); applyMultiAction('distribute-y'); return; }
    if (command && key === 'a') { event.preventDefault(); selectAllInContext(); return; }
    if (command && key === '0') { event.preventDefault(); returnCanvasToView(); return; }
    if (command && key === '1') { event.preventDefault(); applyCanvasFitMode('actual'); return; }
    if (command && ['+','=','add'].includes(key)) { event.preventDefault(); zoomAtCanvasCenter(zoom + .1); return; }
    if (command && ['-','_','subtract'].includes(key)) { event.preventDefault(); zoomAtCanvasCenter(zoom - .1); return; }
    if ((event.key === 'Delete' || event.key === 'Backspace') && selectedId) { event.preventDefault(); deleteSelection(); return; }
    if (event.key === 'F2' && selectedId) { event.preventDefault(); openRenameLayerDialog(); return; }
    if (event.key === 'Tab') { event.preventDefault(); cycleSelection(event.shiftKey); return; }
    if (event.code === 'Space') {
      event.preventDefault();
      if (!spacePanPressed) { spacePanPressed = true; refreshPanTool(); }
      return;
    }
    if (key === 'h') {
      event.preventDefault(); handToolEnabled = !handToolEnabled; refreshPanTool(); return;
    }
    if (event.shiftKey && event.key === '1') { event.preventDefault(); returnCanvasToView(); return; }
    if (event.shiftKey && event.key === '2') { event.preventDefault(); applyCanvasFitMode('cover'); return; }
    if (event.shiftKey && event.key === '3') { event.preventDefault(); applyCanvasFitMode('width'); return; }
    if (event.shiftKey && event.key === '4') { event.preventDefault(); applyCanvasFitMode('height'); return; }
    if (event.key === 'Escape' && selectedId) { clearSelection(); return; }
    if (event.key === 'Escape' && document.body.classList.contains('focus-mode') && !document.fullscreenElement) { setFocusMode(false); return; }
    if (!selectedId || !['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)) return;
    event.preventDefault();
    const delta = event.shiftKey ? 10 : 1;
    const dx = event.key === 'ArrowLeft' ? -delta : event.key === 'ArrowRight' ? delta : 0;
    const dy = event.key === 'ArrowUp' ? -delta : event.key === 'ArrowDown' ? delta : 0;
    activeSelectionIds().forEach((id) => offsetNode(id, dx, dy));
    if (hasMultiSelection()) updateMultiInspector();
    else updateInspector(false);
    drawSelection();
    const nudgeIds = activeSelectionIds();
    commit({
      label:`${event.shiftKey ? '大步' : ''}轻移 ${nudgeIds.length > 1 ? `${nudgeIds.length} 个对象` : labelFor(selectedId)}`,
      type:'geometry.nudge',
      targetIds:nudgeIds,
      detail:{ dx, dy },
      mergeKey:`nudge:${nudgeIds.join(',')}`,
    });
  }
  window.addEventListener('keydown', handleStudioKeydown);

  function handleStudioKeyup(event) {
    if (event.code !== 'Space') return;
    spacePanPressed = false;
    refreshPanTool();
  }
  window.addEventListener('keyup', handleStudioKeyup);

  window.addEventListener('blur', () => {
    spacePanPressed = false;
    canvasPanActive = false;
    document.body.classList.remove('canvas-panning');
    refreshPanTool();
  });

  $('#canvas-viewport').addEventListener('wheel', (event) => handleCanvasWheel(event), { passive:false });
  $('#canvas-viewport').addEventListener('scroll', () => {
    scheduleSelectionSync();
    scheduleRulerSync();
  }, { passive:true });
  $('#ruler-horizontal').addEventListener('pointerdown', (event) => beginRulerGuideDrag(event, 'horizontal'));
  $('#ruler-vertical').addEventListener('pointerdown', (event) => beginRulerGuideDrag(event, 'vertical'));
  $('#canvas-viewport').addEventListener('pointerdown', (event) => {
    const blankWorkspace = !event.target.closest('#canvas-stage');
    if (event.button === 1 || (event.button === 0 && (handToolEnabled || spacePanPressed || blankWorkspace))) beginCanvasPan(event, window, event.button === 0 && blankWorkspace);
  });
  $('#canvas-viewport').addEventListener('auxclick', (event) => {
    if (event.button === 1) event.preventDefault();
  });
  $('#canvas-viewport').addEventListener('dblclick', (event) => {
    if (!event.target.closest('#canvas-stage')) {
      event.preventDefault();
      returnCanvasToView();
    }
  });

  frame.addEventListener('load', () => {
    stopPageLayerScan();
    frameDocument = frame.contentDocument;
    selectionMarkerSignature = '';
    baseSizes.clear();
    baseTexts.clear();
    baseStyles.clear();
    frameDocument.addEventListener('keydown', handleStudioKeydown);
    frameDocument.addEventListener('keyup', handleStudioKeyup);
    injectEditorStyles();
    buildSelectionBox();
    applyStructuralEdits();
    applyLayerMetadata();
    buildLayers();
    captureOriginalIcons();
    buildRulers();
    renderGuides();
    applyAll();
    function closestSelectedCanvasElement(target) {
      let element = target?.closest?.('[data-ui-id]') || null;
      while (element) {
        if (selectedIds.has(element.dataset.uiId)) return element;
        element = element.parentElement?.closest?.('[data-ui-id]') || null;
      }
      return null;
    }
    frameDocument.addEventListener('pointerdown', (event) => {
      if (event.button === 1) { beginCanvasPan(event, frameDocument); return; }
      const element = event.target.closest('[data-ui-id]');
      if (event.shiftKey && (!element || element.dataset.uiId === 'app.shell')) {
        event.preventDefault(); event.stopPropagation();
        beginMarqueeSelection(event);
        return;
      }
      if (!element || !closestSelectedCanvasElement(event.target)) return;
      beginManipulation(event);
    }, true);
    frameDocument.addEventListener('auxclick', (event) => {
      if (event.button === 1) event.preventDefault();
    }, true);
    frameDocument.addEventListener('click', (event) => {
      if (allowBoundPageAction) return;
      if (suppressCanvasClick) { suppressCanvasClick = false; event.preventDefault(); event.stopPropagation(); return; }
      const element = scopedElement(event.target.closest('[data-ui-id]'));
      if (!element || event.target.closest('.ui-studio-selection')) return;
      event.preventDefault(); event.stopPropagation();
      if (hasMultiSelection() && selectedIds.has(element.dataset.uiId) && !event.shiftKey) return;
      select(element.dataset.uiId, { toggle:event.shiftKey });
    }, true);
    frameDocument.addEventListener('pointerover', (event) => {
      const element = scopedElement(event.target.closest('[data-ui-id]'));
      syncCanvasHover(element);
      syncLayerHover(element?.dataset.uiId || null);
    }, true);
    frameDocument.addEventListener('pointerleave', () => { syncCanvasHover(); syncLayerHover(); }, true);
    frameDocument.addEventListener('dblclick', (event) => {
      const element = event.target.closest('[data-ui-id]');
      const pageTrigger = element?.closest?.('[data-view-target][data-ui-id], a[href][data-ui-id], nav button[data-action][data-ui-id], aside button[data-action][data-ui-id], [role="navigation"] button[data-action][data-ui-id]');
      const pageEntry = pageTrigger ? discoveredPageEntries().find((entry) => entry.triggerId === pageTrigger.dataset.uiId) : null;
      if (pageEntry) {
        event.preventDefault(); event.stopPropagation();
        activatePageRoute(pageEntry);
        return;
      }
      const node = nodes.find((item) => item.id === element?.dataset.uiId);
      if (!node?.parentId) return;
      event.preventDefault(); event.stopPropagation(); select(node.parentId);
    }, true);
    frame.contentWindow.addEventListener('resize', drawSelection);
    frameDocument.addEventListener('scroll', drawSelection, true);
    frameDocument.addEventListener('wheel', (event) => {
      const frameRect = frame.getBoundingClientRect();
      const renderScale = canvasRenderScale(frameRect);
      handleCanvasWheel(event, frameRect.left + event.clientX * renderScale.x, frameRect.top + event.clientY * renderScale.y);
    }, { passive:false });
    clearSelection();
    installPageContextObserver();
    activePageIdentity = '';
    syncActivePageContext(true);
    scheduleProjectPageLayerScan(discoveredPageEntries());
    activateFeature(activeFeature, false);
  });

  document.body.classList.toggle('layers-collapsed', Boolean(panelState.layersCollapsed));
  document.body.classList.toggle('inspector-collapsed', Boolean(panelState.inspectorCollapsed));
  applyStoredLayersWidth();
  window.addEventListener('resize', applyStoredLayersWidth);
  const canvasViewport = $('#canvas-viewport');
  new ResizeObserver(() => {
    if (canvasAutoFitSuspended || !autoFitCanvas || isDedicatedFeature() || canvasViewport.hidden || canvasViewport.clientWidth < 2 || canvasViewport.clientHeight < 2) return;
    applyCanvasFitMode(canvasFitMode, false);
  }).observe(canvasViewport);
  refreshGuideVisibilityControl();
  refreshPanelButtons();
  refreshPanTool();
  updateFullscreenButtons();
  refreshFitModeUI();
  renderSyncStatus();
  initializeProjectSync();
  requestAnimationFrame(() => {
    if (canvasFitMode === 'manual') { updateCanvasScale(); restoreCanvasView(); }
    else applyCanvasFitMode(canvasFitMode, false);
  });
  updateHistoryButtons();
})();
