import { analyzeImageData } from './ui-analysis-core.mjs';
import { auditCandidateGraph, diagnoseCandidateConflicts, fuseEvidenceCandidates, inferSemanticStructure, markCoveredPixelEdges, mergeCandidatePair, mergeOcrBlocks, normalizeDomSnapshot, normalizeOcrPayload, screenOcrContamination, splitCandidate } from './ui-semantic-core.mjs';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const clone = (value) => structuredClone(value);
const TYPE_LABELS = { page:'页面', section:'区域', frame:'容器', text:'文字', icon:'图标', image:'图片', control:'控件', divider:'分割线', unknown:'待判断' };
const REVIEW_LABELS = { accepted:'可采用', review:'待确认', excluded:'已排除' };
const REVIEW_COLORS = { accepted:'#5b8cff', review:'#ffad42', excluded:'#7c879b' };
const AUTO_ACCEPT_THRESHOLD = 0.92;
const AUTO_EXCLUDE_THRESHOLD = 0.45;
const MAX_HISTORY = 30;

const state = {
  blob:null,
  bitmap:null,
  fileName:'',
  sourceWidth:0,
  sourceHeight:0,
  analysisWidth:0,
  analysisHeight:0,
  result:null,
  selectedId:null,
  hoveredId:null,
  busy:false,
  semanticMetrics:{},
  analysisMode:'precise',
  reviewFilter:'all',
  overlayMode:'issues',
  showLabels:false,
  flowStep:1,
  history:[],
  reviewConfirmed:false,
  domAvailable:false,
  projectReference:false,
  intakeReport:null,
};

function setFeatureMode(feature) {
  const active = feature === 'recognize';
  document.body.classList.toggle('feature-recognize-active', active);
  $('#analysis-workspace').hidden = !active;
  if (active) {
    $('#layer-count').textContent = state.result?.nodes.length ? String(state.result.nodes.length) : '创建';
    requestAnimationFrame(drawAnalysis);
  }
}

window.addEventListener('ui-studio-featurechange', (event) => setFeatureMode(event.detail.feature));

function status(message, tone = '') {
  const element = $('#analysis-canvas-status');
  element.textContent = message;
  element.dataset.tone = tone;
}

function setFlowStep(step) {
  state.flowStep = Math.max(1, Math.min(6, Number(step) || 1));
  $$('[data-analysis-step]').forEach((item) => {
    const itemStep = Number(item.dataset.analysisStep);
    item.classList.toggle('active', itemStep === state.flowStep);
    item.classList.toggle('complete', itemStep < state.flowStep);
  });
}

function formatBytes(bytes) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))}KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
}

function currentEditorViewport() {
  const compact = $('#viewport-select')?.value?.split('x').map(Number);
  if (compact?.length === 2 && compact.every(Number.isFinite)) return { width:compact[0], height:compact[1] };
  const active = $('.viewport.active');
  return { width:Number(active?.dataset.width || 1920), height:Number(active?.dataset.height || 919) };
}

function screenshotSharpness(bitmap) {
  const width = Math.min(320, bitmap.width || bitmap.naturalWidth || 1);
  const sourceWidth = bitmap.width || bitmap.naturalWidth || width;
  const sourceHeight = bitmap.height || bitmap.naturalHeight || width;
  const height = Math.max(1, Math.round(width * sourceHeight / Math.max(1, sourceWidth)));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d', { willReadFrequently:true });
  context.drawImage(bitmap, 0, 0, width, height);
  const pixels = context.getImageData(0, 0, width, height).data;
  const luminance = (offset) => pixels[offset] * .2126 + pixels[offset + 1] * .7152 + pixels[offset + 2] * .0722;
  let energy = 0;
  let samples = 0;
  for (let y = 1; y < height; y += 2) {
    for (let x = 1; x < width; x += 2) {
      const offset = (y * width + x) * 4;
      energy += Math.abs(luminance(offset) - luminance(offset - 4));
      energy += Math.abs(luminance(offset) - luminance(offset - width * 4));
      samples += 2;
    }
  }
  return samples ? energy / samples : 0;
}

function inspectScreenshotIntake(blob, bitmap, options = {}) {
  const width = bitmap.width || bitmap.naturalWidth || 0;
  const height = bitmap.height || bitmap.naturalHeight || 0;
  const viewport = currentEditorViewport();
  const warnings = [];
  const megapixels = width * height / 1_000_000;
  const sharpness = screenshotSharpness(bitmap);
  const widthDelta = Math.abs(width - viewport.width) / Math.max(1, viewport.width);
  const heightDelta = Math.abs(height - viewport.height) / Math.max(1, viewport.height);
  const viewportMatches = widthDelta <= .02 && heightDelta <= .02;
  if (width < 640 || height < 360 || megapixels < .45) warnings.push('分辨率偏低，细小文字和图标可能无法可靠拆分');
  if (width / Math.max(1, height) > 3.2 || width / Math.max(1, height) < .35) warnings.push('画面比例异常，请确认没有过度裁切');
  if (!viewportMatches) warnings.push(`与当前画布 ${viewport.width}×${viewport.height} 不一致，源码校准将不可用`);
  if (sharpness < 1.35) warnings.push('画面细节偏少或可能模糊，请优先使用原始截图');
  if (blob.type === 'image/jpeg' && blob.size / Math.max(1, width * height) < .055) warnings.push('JPEG 压缩率较高，边缘和小字可能出现伪影');
  if (!options.projectReference && height > viewport.height * 1.06 && Math.abs(width - viewport.width) / Math.max(1, viewport.width) <= .02) warnings.push('高度明显超出目标视口，请检查是否包含浏览器栏或系统区域');
  return { warnings, metrics:{ width, height, megapixels:Number(megapixels.toFixed(2)), sharpness:Number(sharpness.toFixed(2)), viewport, viewportMatches } };
}

function renderIntakeReport(report) {
  const element = $('#analysis-intake-check');
  if (!element || !report) return;
  element.dataset.state = report.warnings.length ? 'warning' : 'ready';
  const metrics = report.metrics;
  const summary = report.warnings.length
    ? `${report.warnings.join('；')} · 清晰度 ${metrics.sharpness}`
    : `质量检查通过 · 视口一致 · 清晰度 ${metrics.sharpness}`;
  element.innerHTML = `<strong>${report.warnings.length ? `${report.warnings.length} 项需要留意` : '截图质量可用'}</strong><small>${escapeHTML(summary)}</small>`;
}

function escapeHTML(value) {
  return String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}

function stableIdentityToken(value) {
  let hash = 2166136261;
  for (const character of String(value || '')) {
    hash ^= character.codePointAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

function screenshotIdentityKey() {
  const origin = state.projectReference ? 'project' : 'upload';
  return `${origin}:${state.fileName.toLowerCase()}:${state.sourceWidth}x${state.sourceHeight}:${state.blob?.size || 0}`;
}

async function bitmapFromBlob(blob) {
  if ('createImageBitmap' in window) return createImageBitmap(blob);
  const image = new Image();
  const url = URL.createObjectURL(blob);
  try {
    await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = reject; image.src = url; });
    return image;
  } finally { URL.revokeObjectURL(url); }
}

async function matchesCanonicalProjectReference(blob) {
  try {
    const response = await fetch('reference.png', { cache:'no-store' });
    if (!response.ok) return false;
    const [candidate, canonical] = await Promise.all([bitmapFromBlob(blob), bitmapFromBlob(await response.blob())]);
    try {
      const candidateWidth = candidate.width || candidate.naturalWidth;
      const candidateHeight = candidate.height || candidate.naturalHeight;
      const canonicalWidth = canonical.width || canonical.naturalWidth;
      const canonicalHeight = canonical.height || canonical.naturalHeight;
      if (candidateWidth !== canonicalWidth || candidateHeight !== canonicalHeight) return false;
      const width = 64;
      const height = 32;
      const sample = (bitmap) => {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const context = canvas.getContext('2d', { willReadFrequently:true });
        context.drawImage(bitmap, 0, 0, width, height);
        return context.getImageData(0, 0, width, height).data;
      };
      const left = sample(candidate);
      const right = sample(canonical);
      let difference = 0;
      for (let index = 0; index < left.length; index += 4) {
        difference += Math.abs(left[index] - right[index]);
        difference += Math.abs(left[index + 1] - right[index + 1]);
        difference += Math.abs(left[index + 2] - right[index + 2]);
      }
      return difference / (width * height * 3) <= 2.5;
    } finally {
      candidate.close?.();
      canonical.close?.();
    }
  } catch { return false; }
}

function setAdapterStatus(id, text, stateName = 'waiting') {
  const element = $(`#${id}`);
  if (!element) return;
  element.textContent = text;
  element.dataset.state = stateName;
  element.dataset.ready = stateName === 'ready' ? 'true' : 'false';
}

async function loadScreenshot(blob, name, options = {}) {
  state.bitmap?.close?.();
  const bitmap = await bitmapFromBlob(blob);
  state.blob = blob;
  state.bitmap = bitmap;
  state.fileName = String(name || 'reference.png').slice(0, 240);
  state.sourceWidth = bitmap.width || bitmap.naturalWidth;
  state.sourceHeight = bitmap.height || bitmap.naturalHeight;
  state.intakeReport = inspectScreenshotIntake(blob, bitmap, options);
  state.result = null;
  state.selectedId = null;
  state.hoveredId = null;
  state.semanticMetrics = {};
  state.history = [];
  state.reviewConfirmed = false;
  state.domAvailable = false;
  state.projectReference = options.projectReference === true;
  $('#analysis-review-confirm').checked = false;
  $('#analysis-file-meta').textContent = `${state.fileName} · ${state.sourceWidth} × ${state.sourceHeight} · ${formatBytes(blob.size)}`;
  renderIntakeReport(state.intakeReport);
  $('#analysis-run').disabled = false;
  $('#analysis-save').disabled = true;
  $('#analysis-calibrate-dom').disabled = false;
  $('#analysis-infer-layout').disabled = true;
  $('#analysis-import-ocr').disabled = true;
  setAdapterStatus('analysis-pixel-status', '已载入 · 等待分析', 'ready');
  setAdapterStatus('analysis-dom-status', '分析时自动检查');
  setAdapterStatus('analysis-ocr-status', '精确分析时自动检测');
  setAdapterStatus('analysis-layout-status', '分析后运行');
  $('#analysis-canvas-empty').hidden = true;
  setFlowStep(1);
  status(state.projectReference ? '项目参考图已载入。精确分析会自动融合当前页面的 DOM、文字与布局证据。' : '截图已载入。精确分析会组合像素、布局和可用的源码证据。');
  drawAnalysis();
  renderAll();
}

function analysisDimensions() {
  const maximum = 1400;
  const scale = Math.min(1, maximum / Math.max(state.sourceWidth, state.sourceHeight));
  return { width:Math.max(1, Math.round(state.sourceWidth * scale)), height:Math.max(1, Math.round(state.sourceHeight * scale)) };
}

function evidenceSources(node) {
  const sources = new Set();
  String(node.source || '').split(/[+,]/).map((item) => item.trim()).filter(Boolean).forEach((item) => sources.add(item));
  (node.evidenceSources || []).forEach((item) => sources.add(item));
  if (node.ocr) sources.add('ocr');
  if (node.sourceNodeId || node.semantic?.sourceNodeId) sources.add('production-dom');
  if (node.layoutHint || node.layout?.mode) sources.add('layout');
  if (node.humanConfirmed) sources.add('human');
  return [...sources];
}

function applySemanticEvidence(nodes) {
  nodes.forEach((node) => {
    const sources = new Set(evidenceSources(node).filter((source) => source !== 'layout'));
    if (node.layoutHint || node.componentHint || node.layout?.mode === 'grid' || node.layout?.mode === 'flex') sources.add('layout');
    node.evidenceSources = [...sources];
  });
}

function isReliableCandidate(node) {
  if (node.type === 'page' || node.source === 'production-dom') return true;
  return Number(node.confidence || 0) >= AUTO_ACCEPT_THRESHOLD && evidenceSources(node).length >= 2;
}

function isLikelyNoiseCandidate(node) {
  if (!node || node.type === 'page' || node.humanConfirmed) return false;
  const sources = evidenceSources(node);
  const hasStrongEvidence = sources.includes('production-dom') || sources.includes('ocr') || sources.includes('human');
  return !hasStrongEvidence && ['noise', 'absorbed-edge'].includes(node.quality?.level) && node.quality?.recommendation === 'exclude';
}

function reviewState(node) {
  if (node.reviewState) return node.reviewState;
  return node.accepted ? 'accepted' : 'review';
}

function setReviewState(node, value, humanConfirmed = true) {
  node.reviewState = value;
  node.accepted = value === 'accepted';
  if (humanConfirmed) node.humanConfirmed = true;
}

function normalizeReviewStates(nodes, preserveHuman = true) {
  nodes.forEach((node) => {
    if (preserveHuman && node.humanConfirmed && node.reviewState) {
      node.accepted = node.reviewState === 'accepted';
      return;
    }
    if (isReliableCandidate(node)) setReviewState(node, 'accepted', false);
    else if (isLikelyNoiseCandidate(node)) setReviewState(node, 'excluded', false);
    else if (node.type !== 'page' && Number(node.confidence || 0) < AUTO_EXCLUDE_THRESHOLD) setReviewState(node, 'excluded', false);
    else setReviewState(node, 'review', false);
  });
}

function mergeTextEvidence(blocks, options = {}) {
  if (!state.result || !blocks.length) return null;
  if (options.checkpointLabel) checkpoint(options.checkpointLabel);
  const screened = screenOcrContamination(blocks, { width:state.sourceWidth, height:state.sourceHeight });
  if (screened.rejected.length) {
    const warning = `检测到 ${screened.rejected.length} 条浏览器或系统覆盖文字，已从 UI 图层排除`;
    state.intakeReport = state.intakeReport || { warnings:[], metrics:{ width:state.sourceWidth, height:state.sourceHeight, sharpness:0, viewportMatches:false } };
    state.intakeReport.warnings = [...new Set([...(state.intakeReport.warnings || []), warning])];
    state.intakeReport.metrics = {
      ...(state.intakeReport.metrics || {}),
      contaminatedTextBlocks:screened.rejected.length,
      contaminationReasons:[...new Set(screened.rejected.map((item) => item.contaminationReason))],
    };
    state.semanticMetrics = { ...state.semanticMetrics, contaminatedTextBlocks:screened.rejected.length };
    renderIntakeReport(state.intakeReport);
  }
  const merged = mergeOcrBlocks(state.result.nodes, screened.clean, { idPrefix:options.idPrefix || 'analysis.draft.ocr' });
  const inferred = inferSemanticStructure(merged.nodes);
  state.result.nodes = inferred.nodes;
  state.result.analyzerVersion = '0.7.0';
  state.result.metrics = { ...state.result.metrics, ...merged.metrics, ...inferred.metrics };
  state.semanticMetrics = { ...state.semanticMetrics, ...merged.metrics, ...inferred.metrics, ocrAdapter:options.adapter || 'import' };
  applySemanticEvidence(state.result.nodes);
  state.result.nodes.forEach((node) => {
    if (node.ocr || node.source?.includes('ocr')) node.evidenceSources = [...new Set([...evidenceSources(node), 'ocr'])];
  });
  normalizeReviewStates(state.result.nodes, options.preserveHuman !== false);
  return { merged, inferred };
}

async function runBrowserTextRecognition() {
  if (typeof globalThis.TextDetector !== 'function') return { result:null, reason:'browser-text-detector-unavailable' };
  try {
    const detector = new globalThis.TextDetector();
    const detected = await detector.detect(state.bitmap);
    const blocks = normalizeOcrPayload((detected || []).map((item) => ({
      text:item.rawValue || item.text || '',
      confidence:Number.isFinite(item.confidence) ? item.confidence : 0.9,
      bounds:{
        x:item.boundingBox?.x ?? item.bounds?.x ?? 0,
        y:item.boundingBox?.y ?? item.bounds?.y ?? 0,
        width:item.boundingBox?.width ?? item.bounds?.width ?? 0,
        height:item.boundingBox?.height ?? item.bounds?.height ?? 0,
      },
    })));
    if (!blocks.length) return { result:null, reason:'browser-text-detector-empty' };
    return { result:mergeTextEvidence(blocks, { adapter:'native-text-detector', preserveHuman:false }), adapter:'native-text-detector' };
  } catch (error) {
    return { result:null, reason:`browser-text-detector-failed:${String(error?.message || error)}` };
  }
}

async function runBridgeTextRecognition() {
  try {
    const png = await canvasPngBlob();
    const response = await fetch('/__ui_sync/ocr', { method:'POST', cache:'no-store', headers:{ 'Content-Type':'image/png' }, body:png });
    let payload = {};
    try { payload = await response.json(); } catch {}
    if (!response.ok) return { result:null, reason:payload.message || `local-ocr-${response.status}`, failures:payload.failures || [] };
    const blocks = normalizeOcrPayload(payload.blocks || []);
    if (!blocks.length) return { result:null, reason:'local-ocr-empty', adapter:payload.adapter, language:payload.language };
    return {
      result:mergeTextEvidence(blocks, { adapter:payload.adapter || 'local-ocr', preserveHuman:false }),
      adapter:payload.adapter || 'local-ocr',
      language:payload.language || null,
    };
  } catch (error) {
    return { result:null, reason:`local-ocr-failed:${String(error?.message || error)}` };
  }
}

function ocrAdapterLabel(adapter) {
  if (adapter === 'windows-media-ocr') return 'Windows 离线 OCR';
  if (adapter === 'tesseract-cli') return 'Tesseract OCR';
  if (adapter === 'native-text-detector') return '浏览器 OCR';
  return '自动 OCR';
}

async function runAutomaticTextRecognition() {
  if (!state.bitmap || !state.result) return null;
  setAdapterStatus('analysis-ocr-status', '正在自动识别', 'running');
  const browserResult = await runBrowserTextRecognition();
  const outcome = browserResult.result ? browserResult : await runBridgeTextRecognition();
  if (!outcome.result) {
    state.semanticMetrics.ocrAdapter = outcome.adapter || 'unavailable';
    state.semanticMetrics.ocrReason = outcome.reason || browserResult.reason || 'no-ocr-adapter';
    state.semanticMetrics.ocrFailures = outcome.failures || [];
    setAdapterStatus('analysis-ocr-status', '本地 OCR 不可用 · 可在高级选项导入', 'unavailable');
    return null;
  }
  state.semanticMetrics.ocrAdapter = outcome.adapter;
  state.semanticMetrics.ocrLanguage = outcome.language || null;
  const count = outcome.result.merged.metrics.ocrBlocks;
  const rawCount = outcome.result.merged.metrics.ocrRawBlocks || count;
  const label = ocrAdapterLabel(outcome.adapter);
  const mergeLabel = rawCount > count ? `${rawCount} 块→${count} 行` : `${count} 条`;
  setAdapterStatus('analysis-ocr-status', `${mergeLabel} · ${label}`, 'ready');
  return outcome.result;
}

function checkpoint(label) {
  if (!state.result) return;
  state.history.push({ label, nodes:clone(state.result.nodes), selectedId:state.selectedId });
  if (state.history.length > MAX_HISTORY) state.history.shift();
  $('#analysis-undo-action').disabled = false;
}

function undoAnalysisAction() {
  const entry = state.history.pop();
  if (!entry || !state.result) return;
  state.result.nodes = entry.nodes;
  state.selectedId = entry.selectedId;
  $('#analysis-undo-action').disabled = !state.history.length;
  status(`已撤销：${entry.label}`, 'success');
  renderAll();
}

function collectProductionDomSnapshot() {
  const frame = $('#preview-frame');
  const frameWindow = frame.contentWindow;
  const frameDocument = frame.contentDocument;
  if (!frameWindow || !frameDocument) throw new Error('生产预览尚未就绪');
  const elements = [...frameDocument.querySelectorAll('[data-ui-id]')].filter((element) => {
    const rect = element.getBoundingClientRect();
    const style = frameWindow.getComputedStyle(element);
    return rect.width >= 1 && rect.height >= 1 && style.display !== 'none' && style.visibility !== 'hidden' && !element.closest('defs, symbol');
  }).map((element) => {
    const rect = element.getBoundingClientRect();
    const style = frameWindow.getComputedStyle(element);
    const directText = [...element.childNodes].filter((node) => node.nodeType === Node.TEXT_NODE).map((node) => node.textContent).join(' ').trim();
    const parent = element.parentElement?.closest('[data-ui-id]');
    return {
      id:element.dataset.uiId,
      parentId:parent?.dataset.uiId || null,
      name:element.dataset.uiName || element.getAttribute('aria-label') || directText || element.dataset.uiId,
      tag:element.tagName.toLowerCase(),
      role:element.getAttribute('role') || '',
      directText,
      text:element.innerText || element.textContent || '',
      bounds:{ x:rect.x, y:rect.y, width:rect.width, height:rect.height },
      display:style.display,
      flexDirection:style.flexDirection,
      gap:style.gap,
    };
  });
  return { elements, viewportWidth:frameWindow.innerWidth, viewportHeight:frameWindow.innerHeight };
}

async function waitForProductionDomSnapshot({ timeout = 6500, minimumNodes = 1 } = {}) {
  const deadline = performance.now() + timeout;
  let lastSnapshot = null;
  let lastError = null;
  let lastCount = -1;
  let stablePasses = 0;
  do {
    try {
      lastSnapshot = collectProductionDomSnapshot();
      const currentCount = lastSnapshot.elements.length;
      stablePasses = currentCount === lastCount ? stablePasses + 1 : 0;
      lastCount = currentCount;
      if (currentCount >= minimumNodes && stablePasses >= 2) return lastSnapshot;
    } catch (error) { lastError = error; }
    await new Promise((resolve) => setTimeout(resolve, 120));
  } while (performance.now() < deadline);
  if (lastSnapshot?.elements?.length >= minimumNodes) return lastSnapshot;
  throw lastError || new Error('当前页面尚未准备好可校准的图层');
}

function dimensionsCompatible(snapshot) {
  const widthDelta = Math.abs(snapshot.viewportWidth - state.sourceWidth) / Math.max(1, state.sourceWidth);
  const heightDelta = Math.abs(snapshot.viewportHeight - state.sourceHeight) / Math.max(1, state.sourceHeight);
  return widthDelta <= 0.04 && heightDelta <= 0.04;
}

function domCalibrationResult({ requireMatch = true, snapshot = null } = {}) {
  const currentSnapshot = snapshot || collectProductionDomSnapshot();
  if (requireMatch && !dimensionsCompatible(currentSnapshot)) {
    return { unavailable:`截图 ${state.sourceWidth}×${state.sourceHeight} 与当前页面 ${currentSnapshot.viewportWidth}×${currentSnapshot.viewportHeight} 不一致` };
  }
  const dom = normalizeDomSnapshot(currentSnapshot.elements, {
    viewportWidth:currentSnapshot.viewportWidth,
    viewportHeight:currentSnapshot.viewportHeight,
    sourceWidth:state.sourceWidth,
    sourceHeight:state.sourceHeight,
  });
  if (!dom.nodes.length) throw new Error('当前页面没有可见的 data-ui-id 节点');
  dom.nodes.forEach((node) => {
    node.evidenceSources = ['production-dom'];
    if (node.layoutHint || node.componentHint || node.layout?.mode === 'grid' || node.layout?.mode === 'flex') node.evidenceSources.push('layout');
    node.reviewState = 'accepted';
    node.accepted = true;
  });
  return { dom };
}

function analyzePixels() {
  const dimensions = analysisDimensions();
  const canvas = $('#analysis-canvas');
  canvas.width = dimensions.width;
  canvas.height = dimensions.height;
  const context = canvas.getContext('2d', { willReadFrequently:true });
  context.drawImage(state.bitmap, 0, 0, dimensions.width, dimensions.height);
  const imageData = context.getImageData(0, 0, dimensions.width, dimensions.height);
  state.analysisWidth = dimensions.width;
  state.analysisHeight = dimensions.height;
  const result = analyzeImageData(imageData, {
    idPrefix:'analysis.draft',
    sourceScaleX:state.sourceWidth / dimensions.width,
    sourceScaleY:state.sourceHeight / dimensions.height,
  });
  const semantic = inferSemanticStructure(result.nodes);
  result.analyzerVersion = '0.7.0';
  result.nodes = semantic.nodes;
  result.metrics = { ...result.metrics, ...semantic.metrics };
  applySemanticEvidence(result.nodes);
  normalizeReviewStates(result.nodes, false);
  return { result, semantic };
}

async function runAnalysis() {
  if (!state.bitmap || state.busy) return;
  state.busy = true;
  const button = $('#analysis-run');
  button.disabled = true;
  button.textContent = state.analysisMode === 'precise' ? '正在精确分析…' : '正在快速分析…';
  setFlowStep(2);
  status('正在提取视觉结构，并检查可融合的文字、布局和源码证据。');
  setAdapterStatus('analysis-pixel-status', '正在分析', 'running');
  await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  try {
    let automaticFusion = null;
    const { result, semantic } = analyzePixels();
    state.result = result;
    state.semanticMetrics = { ...semantic.metrics, intake:clone(state.intakeReport || {}) };
    setAdapterStatus('analysis-pixel-status', `${result.nodes.length} 个候选`, 'ready');
    setAdapterStatus('analysis-layout-status', `${semantic.metrics.inferredLayouts} 组 · 重复 ${semantic.metrics.repeatedGroups}`, 'ready');

    if (state.analysisMode === 'precise') {
      setFlowStep(3);
      await runAutomaticTextRecognition();
      setAdapterStatus('analysis-dom-status', '正在检查', 'running');
      document.body.classList.add('dom-calibrating');
      try {
        const snapshot = state.projectReference ? await waitForProductionDomSnapshot() : collectProductionDomSnapshot();
        if (!dimensionsCompatible(snapshot)) {
          setAdapterStatus('analysis-dom-status', '不可用 · 截图非当前页面尺寸', 'unavailable');
          state.semanticMetrics.domReason = `截图 ${state.sourceWidth}×${state.sourceHeight} 与当前页面 ${snapshot.viewportWidth}×${snapshot.viewportHeight} 不一致`;
        } else {
          state.domAvailable = true;
          if (state.projectReference) {
            const calibration = domCalibrationResult({ requireMatch:true, snapshot });
            automaticFusion = applyDomCalibration(calibration, { preserveHuman:false });
            setAdapterStatus('analysis-dom-status', `${calibration.dom.metrics.domNodes} 个节点 · 已自动融合`, 'ready');
          } else {
            setAdapterStatus('analysis-dom-status', '可用 · 请在高级选项确认校准', 'ready');
          }
        }
      } catch (error) {
        const reason = String(error?.message || '当前页面尚未准备好').slice(0, 48);
        setAdapterStatus('analysis-dom-status', `不可用 · ${reason}`, 'unavailable');
        state.semanticMetrics.domReason = error.message;
      } finally { document.body.classList.remove('dom-calibrating'); }
    } else {
      setAdapterStatus('analysis-dom-status', '快速模式未运行', 'unavailable');
    }

    normalizeReviewStates(state.result.nodes, false);
    state.selectedId = state.result.nodes.find((node) => reviewState(node) === 'review')?.id || state.result.nodes.find((node) => node.type !== 'page')?.id || state.result.nodes[0]?.id || null;
    state.history = [];
    $('#analysis-infer-layout').disabled = false;
    $('#analysis-import-ocr').disabled = !$('#analysis-ocr-json').value.trim();
    $('#layer-count').textContent = String(state.result.nodes.length);
    setFlowStep(4);
    if (automaticFusion) {
      state.reviewFilter = 'review';
      $$('[data-analysis-filter]').forEach((item) => item.classList.toggle('active', item.dataset.analysisFilter === 'review'));
      status(`精确分析完成：自动融合项目 DOM，匹配 ${automaticFusion.metrics.evidenceMatched} 项、新增 ${automaticFusion.metrics.evidenceAdded} 项；当前只显示仍需人工确认的候选。`, 'success');
    } else {
      status(`分析完成：${state.result.nodes.length} 个候选。橙色项需要确认，未确认项不会写入可编辑图层。`, 'success');
    }
    renderAll();
  } catch (error) {
    console.error(error);
    status(`分析失败：${error.message}`, 'error');
    setAdapterStatus('analysis-pixel-status', '分析失败', 'error');
  } finally {
    state.busy = false;
    button.disabled = false;
    button.textContent = state.analysisMode === 'precise' ? '重新精确分析' : '重新快速分析';
    updateReviewGate();
  }
}

function acceptedNodes() {
  return state.result?.nodes.filter((node) => reviewState(node) === 'accepted') || [];
}

function acceptedNodesForAudit() {
  const selected = acceptedNodes().map((node) => clone(node));
  const selectedIds = new Set(selected.map((node) => node.id));
  const allById = new Map((state.result?.nodes || []).map((node) => [node.id, node]));
  const pageId = selected.find((node) => node.type === 'page')?.id || null;
  selected.forEach((node) => {
    const visited = new Set([node.id]);
    let parentId = node.parentId;
    while (parentId && !selectedIds.has(parentId) && !visited.has(parentId)) {
      visited.add(parentId);
      parentId = allById.get(parentId)?.parentId || null;
    }
    node.parentId = parentId && !visited.has(parentId) ? parentId : node.type === 'page' ? null : pageId;
  });
  return selected;
}

function renderSummary() {
  const nodes = state.result?.nodes || [];
  $('#analysis-count').textContent = String(nodes.length);
  $('#analysis-accepted-count').textContent = String(nodes.filter((node) => reviewState(node) === 'accepted').length);
  $('#analysis-manual-count').textContent = String(nodes.filter((node) => reviewState(node) === 'review').length);
  $('#analysis-excluded-count').textContent = String(nodes.filter((node) => reviewState(node) === 'excluded').length);
  updateReviewGate();
}

function updateReviewGate() {
  const unresolved = state.result?.nodes.filter((node) => reviewState(node) === 'review').length || 0;
  const graphAudit = auditCandidateGraph(acceptedNodesForAudit());
  const conflictBlockers = graphAudit.overlapConflicts.filter((conflict) => conflict.severity === 'blocker').length;
  const graphBlocked = graphAudit.missingParents.length > 0 || graphAudit.cycles.length > 0 || conflictBlockers > 0;
  const confirmation = $('#analysis-review-confirm');
  const confirmationLabel = $('#analysis-review-confirm-label');
  const warningCount = graphAudit.missingText.length + graphAudit.overlapConflicts.filter((conflict) => conflict.severity === 'warning').length;
  confirmation.disabled = !state.result || unresolved > 0 || graphBlocked || state.busy;
  if (confirmation.disabled) {
    confirmation.checked = false;
    state.reviewConfirmed = false;
  }
  if (confirmationLabel) {
    confirmationLabel.textContent = graphBlocked || unresolved
      ? '请先处理所有阻塞项'
      : warningCount
        ? `我已检查 ${warningCount} 项生成警告`
        : '候选队列已审核完成';
  }
  $('#analysis-save').disabled = !state.result || unresolved > 0 || graphBlocked || !state.reviewConfirmed || state.busy;
  renderGenerationPreflight();
}

function renderGenerationPreflight() {
  const element = $('#analysis-generation-preflight');
  if (!element) return;
  if (!state.result) {
    element.innerHTML = '<strong>生成前检查</strong><small>分析并审核候选后显示结构完整性。</small>';
    element.dataset.state = 'waiting';
    return;
  }
  const accepted = acceptedNodesForAudit();
  const audit = auditCandidateGraph(accepted);
  const unresolved = state.result.nodes.filter((node) => reviewState(node) === 'review').length;
  const typeCounts = accepted.reduce((counts, node) => ({ ...counts, [node.type]:(counts[node.type] || 0) + 1 }), {});
  const conflictBlockers = audit.overlapConflicts.filter((conflict) => conflict.severity === 'blocker').length;
  const conflictWarnings = audit.overlapConflicts.length - conflictBlockers;
  const blockers = unresolved + audit.missingParents.length + audit.cycles.length + conflictBlockers;
  const warnings = audit.missingText.length + conflictWarnings;
  const typeSummary = [
    ['区域', (typeCounts.section || 0) + (typeCounts.frame || 0)],
    ['文字', typeCounts.text || 0],
    ['图标', typeCounts.icon || 0],
    ['控件', typeCounts.control || 0],
  ].filter(([, count]) => count).map(([label, count]) => `${label} ${count}`).join(' · ') || '尚无可生成图层';
  element.dataset.state = blockers ? 'blocked' : warnings ? 'warning' : 'ready';
  element.innerHTML = `<strong>${blockers ? `还有 ${blockers} 项阻塞` : warnings ? `可生成 · ${warnings} 项需要检查` : '结构可以生成'}</strong><small>${typeSummary}</small><ul><li>待确认 ${unresolved}</li><li>缺少父级 ${audit.missingParents.length}</li><li>文字待补 ${audit.missingText.length}</li><li>冲突：阻塞 ${conflictBlockers} / 提醒 ${conflictWarnings}</li></ul>`;
}

function filteredCandidates() {
  const nodes = state.result?.nodes || [];
  if (state.reviewFilter === 'all') return nodes;
  return nodes.filter((node) => reviewState(node) === state.reviewFilter);
}

function renderCandidateList() {
  const container = $('#analysis-candidate-list');
  const nodes = filteredCandidates();
  if (!state.result?.nodes.length) { container.innerHTML = '<p>上传截图后显示候选图层。</p>'; return; }
  if (!nodes.length) { container.innerHTML = `<p>没有“${REVIEW_LABELS[state.reviewFilter] || state.reviewFilter}”候选。</p>`; return; }
  const fragment = document.createDocumentFragment();
  nodes.forEach((node) => {
    const nodeState = reviewState(node);
    const row = document.createElement('article');
    row.className = `analysis-candidate${node.id === state.selectedId ? ' selected' : ''}`;
    row.dataset.analysisId = node.id;
    row.dataset.reviewState = nodeState;
    const selectButton = document.createElement('button');
    selectButton.type = 'button';
    selectButton.innerHTML = `<i></i><span><b>${escapeHTML(node.name)}</b><small>${TYPE_LABELS[node.type] || TYPE_LABELS.unknown} · ${Math.round(Number(node.confidence || 0) * 100)}% · ${Math.round(node.bounds.width)}×${Math.round(node.bounds.height)}</small></span><em>${REVIEW_LABELS[nodeState]}</em>`;
    selectButton.addEventListener('click', () => selectCandidate(node.id));
    selectButton.addEventListener('mouseenter', () => { state.hoveredId = node.id; drawAnalysis(); });
    selectButton.addEventListener('mouseleave', () => { state.hoveredId = null; drawAnalysis(); });
    row.append(selectButton);
    fragment.append(row);
  });
  container.replaceChildren(fragment);
}

function selectedCandidate() {
  return state.result?.nodes.find((node) => node.id === state.selectedId) || null;
}

function isDescendant(candidateId, parentId) {
  const byId = new Map((state.result?.nodes || []).map((node) => [node.id, node]));
  const visited = new Set([candidateId]);
  let cursor = byId.get(candidateId)?.parentId;
  while (cursor) {
    if (cursor === parentId) return true;
    if (visited.has(cursor)) return false;
    visited.add(cursor);
    cursor = byId.get(cursor)?.parentId;
  }
  return false;
}

function evidenceLabel(source, node) {
  if (source === 'production-dom') return ['DOM 精确', 'strong'];
  if (source === 'ocr' || source === 'ocr-import') return [`OCR ${Math.round(Number(node.ocr?.confidence || node.confidence || 0) * 100)}%`, 'strong'];
  if (source === 'layout') return [`Layout ${Math.round(Number(node.layoutHint?.confidence || 0.76) * 100)}%`, 'medium'];
  if (source === 'human') return ['人工确认', 'strong'];
  if (source === 'pixel-structure' || source === 'edge-projection' || source === 'image-boundary') return [`Pixel ${Math.round(Number(node.confidence || 0) * 100)}%`, 'medium'];
  return [source, 'neutral'];
}

function qualityDescription(node) {
  if (node.quality?.reason === 'production-dom') return '源码精确验证 · 建议采用';
  if (node.quality?.reason === 'ocr-text') return `文字证据 ${Math.round(Number(node.quality.confidence || 0) * 100)}% · ${node.quality.recommendation === 'accept' ? '建议采用' : '建议确认'}`;
  if (node.quality?.reason === 'covered-by-dom-edge') return `已由精确容器边缘覆盖 · ${node.quality.orientation === 'horizontal' ? '横向' : '纵向'}重合 ${Math.round(Number(node.quality.overlap || 0) * 100)}% · 建议排除`;
  if (node.quality?.level === 'noise') return '微小边缘碎片 · 建议排除';
  if (isReliableCandidate(node)) return '多源高置信 · 建议采用';
  return '证据不足 · 建议确认';
}

function findConflictPairs() {
  const nodes = state.result?.nodes.filter((node) => node.type !== 'page' && reviewState(node) !== 'excluded') || [];
  const byId = new Map(nodes.map((node) => [node.id, node]));
  return diagnoseCandidateConflicts(nodes).map((conflict) => ({ ...conflict, left:byId.get(conflict.leftId), right:byId.get(conflict.rightId) })).filter((conflict) => conflict.left && conflict.right);
}

function selectedConflict() {
  return findConflictPairs().find((conflict) => conflict.leftId === state.selectedId || conflict.rightId === state.selectedId) || null;
}

function conflictReason(conflict) {
  if (!conflict) return '';
  if (conflict.reasonCode === 'human-protected') return '其中至少一项经过人工确认，系统不会自动合并或排除。';
  if (conflict.reasonCode === 'weak-single-source-overlap') return '一个候选只有较弱的单一像素证据，且被更可靠的候选大面积覆盖。';
  if (conflict.reasonCode === 'probable-duplicate') return '两个同类候选形状高度重合，可能是不同分析器识别出的同一个对象。';
  if (conflict.reasonCode === 'different-semantic-types') return '两项语义类型不同，重叠可能属于正常的容器与内容关系，请检查父级。';
  if (conflict.reasonCode === 'text-overlap') return '两段文字占据相近区域，可能需要合并文字或调整识别边界。';
  return '两个同级候选存在较大重叠，请确认它们是两个对象还是重复识别。';
}

function conflictRecommendation(conflict) {
  const labels = {
    merge:'建议合并为一个候选',
    'keep-both':'建议保留两个并确认父级',
    'exclude-left':'建议排除较弱的左侧候选',
    'exclude-right':'建议排除较弱的右侧候选',
    review:'建议人工检查',
  };
  return labels[conflict?.recommendedAction] || labels.review;
}

function renderConflictCard(node) {
  const card = $('#analysis-conflict-card');
  if (!card) return;
  const conflict = node ? selectedConflict() : null;
  card.hidden = !conflict;
  if (!conflict) return;
  const other = conflict.leftId === node.id ? conflict.right : conflict.left;
  card.dataset.state = conflict.severity;
  card.dataset.conflictId = conflict.id;
  $('#analysis-conflict-overlap').textContent = `重叠 ${Math.round(conflict.iou * 100)}%`;
  $('#analysis-conflict-title').textContent = `与“${other.name}”存在${conflict.severity === 'blocker' ? '待处理' : '需检查'}冲突`;
  $('#analysis-conflict-reason').textContent = conflictReason(conflict);
  $('#analysis-conflict-recommendation').textContent = conflictRecommendation(conflict);
  $('#analysis-conflict-merge').disabled = conflict.protectedByHuman || conflict.recommendedAction === 'keep-both';
  $('#analysis-conflict-exclude').disabled = !conflict.weakerId || conflict.protectedByHuman;
}

function renderInspector() {
  const node = selectedCandidate();
  $('#analysis-inspector-empty').hidden = Boolean(node);
  $('#analysis-inspector-fields').hidden = !node;
  renderConflictCard(node);
  if (!node) return;
  $('#analysis-prop-name').value = node.name;
  $('#analysis-prop-type').value = node.type;
  const textField = $('#analysis-text-field');
  textField.hidden = node.type !== 'text' && !node.content?.text;
  $('#analysis-prop-text').value = node.content?.text || '';
  $('#analysis-prop-confidence').textContent = `${Math.round(Number(node.confidence || 0) * 100)}%`;
  $('#analysis-prop-confidence').dataset.level = isReliableCandidate(node) ? 'strong' : Number(node.confidence || 0) >= 0.72 ? 'medium' : 'manual';
  $('#analysis-prop-x').textContent = String(Math.round(node.bounds.x));
  $('#analysis-prop-y').textContent = String(Math.round(node.bounds.y));
  $('#analysis-prop-width').textContent = String(Math.round(node.bounds.width));
  $('#analysis-prop-height').textContent = String(Math.round(node.bounds.height));
  $('#analysis-prop-layout').textContent = layoutDescription(node);
  $('#analysis-prop-quality').textContent = qualityDescription(node);
  $('#analysis-prop-source-node').textContent = node.sourceNodeId || node.semantic?.sourceNodeId || '—';

  const parentSelect = $('#analysis-prop-parent');
  const eligibleParents = state.result.nodes.filter((candidate) => candidate.id !== node.id && ['page','section','frame'].includes(candidate.type) && !isDescendant(candidate.id, node.id));
  parentSelect.innerHTML = `<option value="">无父级</option>${eligibleParents.map((candidate) => `<option value="${escapeHTML(candidate.id)}">${escapeHTML(candidate.name)}</option>`).join('')}`;
  parentSelect.value = eligibleParents.some((candidate) => candidate.id === node.parentId) ? node.parentId : '';

  const chips = $('#analysis-evidence-chips');
  chips.innerHTML = evidenceSources(node).map((source) => {
    const [label, level] = evidenceLabel(source, node);
    return `<span data-level="${level}">${escapeHTML(label)}</span>`;
  }).join('') || '<span data-level="neutral">单一未知证据</span>';

  const nodeState = reviewState(node);
  $('#analysis-candidate-accept').classList.toggle('active', nodeState === 'accepted');
  $('#analysis-candidate-review').classList.toggle('active', nodeState === 'review');
  $('#analysis-candidate-exclude').classList.toggle('active', nodeState === 'excluded');
}

function layoutDescription(node) {
  const hint = node.layoutHint || node.layout;
  if (!hint) return '缺少布局证据';
  if (hint.mode === 'grid') return `Grid ${hint.columns || '?'}×${hint.rows || '?'} · ${Math.round(Number(hint.confidence || 0) * 100)}%`;
  if (hint.mode === 'flex') return `Flex ${hint.direction || 'row'} · gap ${hint.gap || 0}px`;
  return String(hint.mode || 'flow');
}

function shouldDrawNode(node) {
  const selected = node.id === state.selectedId;
  const hovered = node.id === state.hoveredId;
  if (selected || hovered || node.type === 'page') return true;
  if (state.overlayMode === 'all') return reviewState(node) !== 'excluded';
  return reviewState(node) === 'review';
}

function drawAnalysis() {
  const canvas = $('#analysis-canvas');
  const context = canvas.getContext('2d');
  if (!state.bitmap) { context.clearRect(0, 0, canvas.width, canvas.height); return; }
  if (!state.analysisWidth || !state.analysisHeight) {
    const dimensions = analysisDimensions();
    state.analysisWidth = dimensions.width;
    state.analysisHeight = dimensions.height;
    canvas.width = dimensions.width;
    canvas.height = dimensions.height;
  }
  context.clearRect(0, 0, canvas.width, canvas.height);
  context.drawImage(state.bitmap, 0, 0, canvas.width, canvas.height);
  if (!state.result) return;
  const scaleX = canvas.width / state.sourceWidth;
  const scaleY = canvas.height / state.sourceHeight;
  for (const node of state.result.nodes) {
    if (!shouldDrawNode(node)) continue;
    const x = node.bounds.x * scaleX;
    const y = node.bounds.y * scaleY;
    const width = node.bounds.width * scaleX;
    const height = node.bounds.height * scaleY;
    const selected = node.id === state.selectedId;
    const color = REVIEW_COLORS[reviewState(node)];
    context.save();
    context.strokeStyle = color;
    context.lineWidth = selected ? 3 : node.type === 'page' ? 1 : 1.5;
    context.setLineDash(reviewState(node) === 'review' ? [6, 4] : []);
    context.fillStyle = `${color}${selected ? '22' : '0d'}`;
    context.fillRect(x, y, width, height);
    context.strokeRect(x + 0.5, y + 0.5, Math.max(1, width - 1), Math.max(1, height - 1));
    if (selected || node.id === state.hoveredId || state.showLabels) {
      const label = `${TYPE_LABELS[node.type] || TYPE_LABELS.unknown} · ${REVIEW_LABELS[reviewState(node)]} · ${Math.round(Number(node.confidence || 0) * 100)}%`;
      context.font = '12px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
      const labelWidth = context.measureText(label).width + 12;
      const labelY = Math.max(0, y - 20);
      context.fillStyle = color;
      context.fillRect(x, labelY, labelWidth, 20);
      context.fillStyle = '#fff';
      context.fillText(label, x + 6, labelY + 14);
    }
    context.restore();
  }
}

function renderAll() {
  renderSummary();
  renderCandidateList();
  renderInspector();
  drawAnalysis();
}

function selectCandidate(id) {
  state.selectedId = id;
  renderAll();
}

function candidateAtPoint(x, y) {
  const nodes = state.result?.nodes.filter((node) => x >= node.bounds.x && y >= node.bounds.y && x <= node.bounds.x + node.bounds.width && y <= node.bounds.y + node.bounds.height) || [];
  return nodes.sort((left, right) => left.bounds.width * left.bounds.height - right.bounds.width * right.bounds.height)[0] || null;
}

function intersectionOverUnion(left, right) {
  const x1 = Math.max(left.x, right.x);
  const y1 = Math.max(left.y, right.y);
  const x2 = Math.min(left.x + left.width, right.x + right.width);
  const y2 = Math.min(left.y + left.height, right.y + right.height);
  const intersection = Math.max(0, x2 - x1) * Math.max(0, y2 - y1);
  const union = left.width * left.height + right.width * right.height - intersection;
  return intersection / Math.max(1, union);
}

function updateSelectedState(value) {
  const node = selectedCandidate();
  if (!node) return;
  checkpoint(`将“${node.name}”改为${REVIEW_LABELS[value]}`);
  setReviewState(node, value, true);
  if (value === 'accepted') node.evidenceSources = [...new Set([...evidenceSources(node), 'human'])];
  renderAll();
}

function mergeSelectedCandidate() {
  const selected = selectedCandidate();
  if (!selected || !state.result) return;
  const partner = state.result.nodes
    .filter((node) => node.id !== selected.id && node.type !== 'page' && reviewState(node) !== 'excluded')
    .map((node) => ({ node, overlap:intersectionOverUnion(selected.bounds, node.bounds) }))
    .sort((left, right) => right.overlap - left.overlap)[0];
  if (!partner || partner.overlap < 0.35) { status('当前候选没有可合并的重叠项。', 'error'); return; }
  checkpoint(`合并“${selected.name}”与“${partner.node.name}”`);
  const merged = mergeCandidatePair(state.result.nodes, selected.id, partner.node.id);
  if (!merged.merged) { status('当前候选无法安全合并。', 'error'); return; }
  state.result.nodes = inferSemanticStructure(merged.nodes).nodes;
  state.selectedId = merged.primaryId;
  status(`候选已合并，${merged.parentRepairs ? `同时修复 ${merged.parentRepairs} 个父级关系，` : ''}请确认类型和状态。`, 'success');
  renderAll();
}

function resolveSelectedConflict(action) {
  const conflict = selectedConflict();
  if (!conflict || !state.result) { status('当前候选没有待处理冲突。'); return; }
  if (action === 'locate') {
    state.selectedId = conflict.leftId === state.selectedId ? conflict.rightId : conflict.leftId;
    status('已定位到冲突的另一项。');
    renderAll();
    return;
  }
  if (action === 'merge') {
    if (conflict.protectedByHuman) { status('冲突包含人工确认结果，系统已阻止直接合并。请先检查后再调整状态。', 'error'); return; }
    checkpoint(`处理冲突：合并“${conflict.left.name}”与“${conflict.right.name}”`);
    const merged = mergeCandidatePair(state.result.nodes, conflict.leftId, conflict.rightId);
    if (!merged.merged) { status('这组候选无法安全合并。', 'error'); return; }
    state.result.nodes = inferSemanticStructure(merged.nodes).nodes;
    state.selectedId = merged.primaryId;
    status('冲突已合并为一个候选，并重新校准内部父级。', 'success');
    renderAll();
    return;
  }
  if (action === 'keep') {
    checkpoint(`处理冲突：保留“${conflict.left.name}”与“${conflict.right.name}”`);
    const resolution = { action:'keep-both', humanConfirmed:true, resolvedAt:new Date().toISOString() };
    [conflict.left, conflict.right].forEach((node) => {
      node.conflictResolutions = { ...(node.conflictResolutions || {}), [conflict.id]:resolution };
      node.evidenceSources = [...new Set([...evidenceSources(node), 'human'])];
      setReviewState(node, 'accepted', true);
    });
    status('已保留两个候选并记录人工决策；后续重新分析不会重复提示这组冲突。', 'success');
    renderAll();
    return;
  }
  if (action === 'exclude') {
    const weaker = state.result.nodes.find((node) => node.id === conflict.weakerId);
    if (!weaker || conflict.protectedByHuman) { status('没有可安全排除的弱候选，系统不会覆盖人工结果。', 'error'); return; }
    checkpoint(`处理冲突：排除较弱项“${weaker.name}”`);
    weaker.conflictResolutions = { ...(weaker.conflictResolutions || {}), [conflict.id]:{ action:'excluded-weaker', humanConfirmed:true, resolvedAt:new Date().toISOString() } };
    setReviewState(weaker, 'excluded', true);
    state.selectedId = weaker.id === conflict.leftId ? conflict.rightId : conflict.leftId;
    status(`已排除较弱候选“${weaker.name}”，保留更可靠证据。`, 'success');
    renderAll();
  }
}

function splitSelectedCandidate() {
  const selected = selectedCandidate();
  if (!selected || !state.result || selected.type === 'page') return;
  if (Math.max(selected.bounds.width, selected.bounds.height) < 24) { status('候选尺寸过小，无法安全拆分。', 'error'); return; }
  checkpoint(`拆分“${selected.name}”`);
  const split = splitCandidate(state.result.nodes, selected.id);
  if (!split.split) { status('当前候选无法安全拆分。', 'error'); return; }
  state.result.nodes = inferSemanticStructure(split.nodes).nodes;
  state.selectedId = split.createdIds[0];
  status(`已沿${split.axis === 'x' ? '垂直' : '水平'}内容间隙拆成两个候选，并重新分配内部子层。`, 'success');
  renderAll();
}

function markRepeatedCandidate() {
  const node = selectedCandidate();
  if (!node) return;
  const inferred = inferSemanticStructure(state.result.nodes);
  const refreshed = inferred.nodes.find((candidate) => candidate.id === node.id);
  const inferredKey = refreshed?.componentHint?.key;
  const siblings = inferred.nodes.filter((candidate) => candidate.componentHint?.key === inferredKey && reviewState(candidate) !== 'excluded');
  if (!inferredKey || siblings.length < 2) { status('没有找到尺寸和对齐方式相近的同级组件。', 'error'); return; }
  checkpoint(`标记“${node.name}”为重复组件`);
  state.result.nodes = inferred.nodes;
  const key = `repeat.human.${Date.now().toString(36)}`;
  siblings.forEach((candidate, index) => { candidate.componentHint = { key, instance:index + 1, count:siblings.length, confidence:1, humanConfirmed:true }; });
  status(`已把 ${siblings.length} 个尺寸与对齐方式相近的${TYPE_LABELS[node.type]}标记为重复组件。`, 'success');
  renderAll();
}

function applyDomCalibration(calibration, options = {}) {
  if (options.checkpointLabel) checkpoint(options.checkpointLabel);
  const fused = fuseEvidenceCandidates(state.result?.nodes || [], calibration.dom.nodes, { minimumScore:0.3 });
  const coveredEdges = markCoveredPixelEdges(fused.nodes, { evidenceNodes:calibration.dom.nodes, tolerance:12, maximumThickness:12, minimumLength:56, minimumOverlap:0.72 });
  state.result = {
    analyzerVersion:'0.7.0',
    analysisSize:{ width:state.analysisWidth || state.sourceWidth, height:state.analysisHeight || state.sourceHeight },
    sourceSize:{ width:state.sourceWidth, height:state.sourceHeight },
    nodes:coveredEdges.nodes,
    palette:state.result?.palette || [],
    metrics:{ ...(state.result?.metrics || {}), ...calibration.dom.metrics, ...fused.metrics, ...coveredEdges.metrics, calibration:'production-dom-fusion' },
  };
  applySemanticEvidence(state.result.nodes);
  normalizeReviewStates(state.result.nodes, options.preserveHuman !== false);
  state.semanticMetrics = { ...state.semanticMetrics, ...calibration.dom.metrics, ...fused.metrics, ...coveredEdges.metrics, calibration:'production-dom-fusion' };
  setAdapterStatus('analysis-dom-status', `${calibration.dom.metrics.domNodes} 个精确节点 · 文字 ${calibration.dom.metrics.domTextNodes || 0}`, 'ready');
  setAdapterStatus('analysis-layout-status', `${calibration.dom.metrics.inferredLayouts} 组 · 重复 ${calibration.dom.metrics.repeatedGroups}`, 'ready');
  return { ...fused, nodes:coveredEdges.nodes, metrics:{ ...fused.metrics, ...coveredEdges.metrics } };
}

async function calibrateFromProductionDom() {
  if (!state.bitmap || state.busy) return;
  document.body.classList.add('dom-calibrating');
  try {
    const calibration = domCalibrationResult({ requireMatch:true });
    if (calibration.unavailable) throw new Error(calibration.unavailable);
    const fused = applyDomCalibration(calibration, { checkpointLabel:'重新运行源码校准', preserveHuman:true });
    state.selectedId = state.result.nodes.find((node) => node.type === 'text')?.id || state.result.nodes[0]?.id || null;
    status(`证据融合完成：匹配 ${fused.metrics.evidenceMatched} 项，新增 ${fused.metrics.evidenceAdded} 项，吸收重复边缘 ${fused.metrics.absorbedEdgeArtifacts || 0} 项；精确节点保留原始 data-ui-id。`, 'success');
    renderAll();
  } catch (error) {
    setAdapterStatus('analysis-dom-status', '不可用 · 截图或页面不匹配', 'unavailable');
    status(`源码校准未应用：${error.message}`, 'error');
  } finally { document.body.classList.remove('dom-calibrating'); }
}

function inferCurrentLayout() {
  if (!state.result) return;
  checkpoint('重新推断布局');
  const inferred = inferSemanticStructure(state.result.nodes);
  state.result.nodes = inferred.nodes;
  state.result.analyzerVersion = '0.7.0';
  state.result.metrics = { ...state.result.metrics, ...inferred.metrics };
  state.semanticMetrics = { ...state.semanticMetrics, ...inferred.metrics };
  applySemanticEvidence(state.result.nodes);
  normalizeReviewStates(state.result.nodes, true);
  setAdapterStatus('analysis-layout-status', `${inferred.metrics.inferredLayouts} 组 · 重复 ${inferred.metrics.repeatedGroups}`, 'ready');
  status(`已推断 ${inferred.metrics.inferredLayouts} 个布局容器和 ${inferred.metrics.repeatedGroups} 组重复组件。`, 'success');
  renderAll();
}

function importOcrJson() {
  if (!state.result) return;
  try {
    const blocks = normalizeOcrPayload($('#analysis-ocr-json').value);
    if (!blocks.length) throw new Error('没有找到带文字和边界的 OCR 条目');
    const { merged, inferred } = mergeTextEvidence(blocks, { checkpointLabel:'导入 OCR 文字证据', adapter:'json-import', preserveHuman:true });
    state.selectedId = state.result.nodes.find((node) => node.content?.status === 'ocr-observed')?.id || state.selectedId;
    const mergeLabel = merged.metrics.ocrRawBlocks > merged.metrics.ocrBlocks ? `${merged.metrics.ocrRawBlocks} 块→${merged.metrics.ocrBlocks} 行` : `${merged.metrics.ocrBlocks} 条`;
    setAdapterStatus('analysis-ocr-status', `${mergeLabel} · 新增 ${merged.metrics.ocrCreated}`, 'ready');
    setAdapterStatus('analysis-layout-status', `${inferred.metrics.inferredLayouts} 组 · 重复 ${inferred.metrics.repeatedGroups}`, 'ready');
    status(`文字证据已融合：匹配 ${merged.metrics.ocrMatched} 条，新建 ${merged.metrics.ocrCreated} 个文字层。`, 'success');
    renderAll();
  } catch (error) {
    status(`OCR JSON 无法导入：${error.message}`, 'error');
  }
}

async function canvasPngBlob() {
  const canvas = document.createElement('canvas');
  canvas.width = state.sourceWidth;
  canvas.height = state.sourceHeight;
  canvas.getContext('2d').drawImage(state.bitmap, 0, 0, canvas.width, canvas.height);
  return new Promise((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('无法转换 PNG')), 'image/png'));
}

async function jsonRequest(pathname, options = {}) {
  const response = await fetch(pathname, { cache:'no-store', headers:{ 'Content-Type':'application/json', ...(options.headers || {}) }, ...options });
  let payload = {};
  try { payload = await response.json(); } catch {}
  if (!response.ok) throw new Error(payload.message || `${response.status} ${response.statusText}`);
  return payload;
}

function buildRecognizedNodes(referenceId, sourceKey = screenshotIdentityKey()) {
  const selected = acceptedNodes();
  const selectedIds = new Set(selected.map((node) => node.id));
  const allById = new Map((state.result?.nodes || []).map((node) => [node.id, node]));
  const selectedPageId = selected.find((node) => node.type === 'page')?.id || null;
  const counters = {};
  const idMap = new Map();
  selected.forEach((node) => {
    counters[node.type] = (counters[node.type] || 0) + 1;
    const semanticIdentity = node.sourceNodeId || node.semantic?.sourceNodeId || node.id;
    idMap.set(node.id, `analysis.${stableIdentityToken(`${sourceKey}:${semanticIdentity}`)}.${node.type}`);
  });
  const acceptedParent = (node) => {
    let parentId = node.parentId;
    while (parentId && !selectedIds.has(parentId)) parentId = allById.get(parentId)?.parentId || null;
    if (parentId) return idMap.get(parentId) || null;
    return node.type === 'page' ? null : idMap.get(selectedPageId) || null;
  };
  return selected.map((node) => ({
    id:idMap.get(node.id),
    name:node.name,
    type:node.type,
    parentId:acceptedParent(node),
    bounds:{ ...node.bounds },
    layout:{ ...(node.layout || {}), mode:node.layoutHint?.mode || node.layout?.mode || 'free', sizing:{ width:'fixed', height:'fixed' }, constraints:{ horizontal:'left', vertical:'top' }, hint:node.layoutHint ? { ...node.layoutHint } : undefined },
    style:{},
    content:node.type === 'text' ? { text:node.content?.text || '', status:node.content?.status || 'ocr-pending' } : { ...(node.content || {}) },
    sourceNodeId:node.sourceNodeId || node.semantic?.sourceNodeId || undefined,
    semantic:node.semantic ? { ...node.semantic } : undefined,
    componentHint:node.componentHint ? { ...node.componentHint } : undefined,
    analysisIdentity:{ sourceKey, candidateId:node.id, referenceId },
    origin:node.source === 'production-dom' ? 'dom-calibration' : 'analysis',
  }));
}

function mergeRecognizedNodes(existingNodes, recognizedNodes) {
  const generatedIds = new Set(recognizedNodes.map((node) => node.id));
  return [...existingNodes.filter((node) => !generatedIds.has(node.id)), ...recognizedNodes];
}

async function saveAnalysis() {
  if (!state.result || !state.bitmap || state.busy) return;
  const nodes = acceptedNodes();
  if (!nodes.length) { status('至少确认一个“可采用”候选后才能生成图层。', 'error'); return; }
  const unresolvedBeforeSave = state.result.nodes.filter((node) => reviewState(node) === 'review').length;
  if (unresolvedBeforeSave) { status(`仍有 ${unresolvedBeforeSave} 个候选待确认；接受或排除后才能生成。`, 'error'); return; }
  const graphAudit = auditCandidateGraph(acceptedNodesForAudit());
  if (!graphAudit.valid) { status(`结构仍不完整：缺少父级 ${graphAudit.missingParents.length} 项，循环父级 ${graphAudit.cycles.length} 项。`, 'error'); return; }
  const unresolvedConflictBlockers = graphAudit.overlapConflicts.filter((conflict) => conflict.severity === 'blocker');
  if (unresolvedConflictBlockers.length) { status(`仍有 ${unresolvedConflictBlockers.length} 组重复或弱证据冲突；请在右侧选择合并、保留或排除后再生成。`, 'error'); return; }
  if (!state.reviewConfirmed) { status('请先勾选“候选队列已审核完成”。', 'error'); return; }
  state.busy = true;
  setFlowStep(5);
  const button = $('#analysis-save');
  button.disabled = true;
  button.textContent = '正在生成可编辑图层…';
  try {
    const current = await jsonRequest('/__ui_sync/document');
    const documentValue = current.document;
    if (documentValue.source.references.length >= 30 || documentValue.evidence.runs.length >= 30) throw new Error('参考图已达到 30 个上限，请先归档旧记录');
    const suffix = Date.now().toString(36);
    const referenceId = `ref-${suffix}`;
    const runId = `run-${suffix}`;
    const sourceKey = screenshotIdentityKey();
    const png = await canvasPngBlob();
    const uploadResponse = await fetch(`/__ui_sync/reference/${referenceId}`, {
      method:'PUT',
      headers:{ 'Content-Type':'image/png', 'X-UI-Expected-Revision':String(documentValue.revision) },
      body:png,
    });
    const uploaded = await uploadResponse.json();
    if (!uploadResponse.ok) throw new Error(uploaded.message || `参考图上传失败 (${uploadResponse.status})`);

    const recognizedNodes = buildRecognizedNodes(referenceId, sourceKey);
    const originalAccepted = acceptedNodes();
    const evidenceItems = {};
    recognizedNodes.forEach((node, index) => {
      const source = originalAccepted[index];
      evidenceItems[node.id] = {
        referenceId,
        runId,
        sourceKey,
        confidence:source.confidence,
        source:source.source,
        sources:evidenceSources(source),
        humanConfirmed:Boolean(source.humanConfirmed),
        observedBounds:{ ...source.bounds },
        classification:source.type,
        sourceNodeId:source.sourceNodeId || source.semantic?.sourceNodeId || null,
        ocrConfidence:source.ocr?.confidence ?? null,
        layoutHint:source.layoutHint || null,
      };
    });
    const unresolvedCount = state.result.nodes.filter((node) => reviewState(node) === 'review').length;
    const manualIds = recognizedNodes.filter((node, index) => !isReliableCandidate(originalAccepted[index]) && !originalAccepted[index].humanConfirmed).map((node) => node.id);
    const colorTokens = { ...(documentValue.tokens?.color || {}) };
    (state.result.palette || []).forEach((color, index) => { colorTokens[`observed.${referenceId}.${index + 1}`] = color.value; });
    const nextDocument = {
      ...documentValue,
      version:4,
      source:{ ...documentValue.source, references:[...documentValue.source.references, { id:referenceId, sourceKey, name:state.fileName, path:uploaded.path, width:state.sourceWidth, height:state.sourceHeight, origin:state.projectReference ? 'project-reference' : 'upload', createdAt:new Date().toISOString() }] },
      tokens:{ ...documentValue.tokens, color:colorTokens },
      nodes:mergeRecognizedNodes(documentValue.nodes, recognizedNodes),
      evidence:{
        activeRunId:runId,
        runs:[...documentValue.evidence.runs, { id:runId, referenceId, sourceKey, analyzerVersion:state.result.analyzerVersion, candidateCount:state.result.nodes.length, acceptedCount:recognizedNodes.length, reviewCount:unresolvedCount, excludedCount:state.result.nodes.filter((node) => reviewState(node) === 'excluded').length, manualCount:manualIds.length, metrics:{ ...state.result.metrics, adapters:{ ...state.semanticMetrics } }, createdAt:new Date().toISOString() }],
        items:{ ...documentValue.evidence.items, ...evidenceItems },
      },
      manualQueue:[...new Set([...(documentValue.manualQueue || []), ...manualIds])],
      updatedAt:new Date().toISOString(),
      updatedBy:'studio',
    };
    await jsonRequest('/__ui_sync/document', {
      method:'PUT',
      body:JSON.stringify({
        expectedRevision:documentValue.revision,
        document:nextDocument,
        operations:[{ type:'analysis.generate-editable-layers', targetIds:recognizedNodes.map((node) => node.id), detail:{ referenceId, runId, sourceKey, candidates:state.result.nodes.length, accepted:recognizedNodes.length, unresolved:unresolvedCount, adapters:{ ...state.semanticMetrics } } }],
      }),
    });
    sessionStorage.setItem('ui-analysis-open-structure', JSON.stringify({ runId, accepted:recognizedNodes.length, unresolved:unresolvedCount }));
    status(`已生成 UI Document V4 草稿：${recognizedNodes.length} 个可编辑图层；${unresolvedCount} 个未确认候选未写入。`, 'success');
    setTimeout(() => window.location.reload(), 900);
  } catch (error) {
    console.error(error);
    status(`生成失败：${error.message}`, 'error');
    setFlowStep(4);
    button.disabled = false;
    button.textContent = '生成可编辑图层';
  } finally {
    state.busy = false;
    updateReviewGate();
  }
}

async function restoreLatestAnalysis() {
  try {
    const current = await jsonRequest('/__ui_sync/document');
    const run = current.document.evidence?.runs?.find((item) => item.id === current.document.evidence.activeRunId);
    const reference = current.document.source?.references?.find((item) => item.id === run?.referenceId);
    if (!run || !reference) return;
    const response = await fetch(reference.path, { cache:'no-store' });
    if (!response.ok) return;
    const blob = await response.blob();
    const projectReference = reference.origin === 'project-reference' || await matchesCanonicalProjectReference(blob);
    await loadScreenshot(blob, reference.name, { projectReference });
    const runNodes = current.document.nodes.filter((node) => current.document.evidence.items?.[node.id]?.runId === run.id);
    state.result = {
      analyzerVersion:run.analyzerVersion || '0.3.0',
      analysisSize:{ width:reference.width, height:reference.height },
      sourceSize:{ width:reference.width, height:reference.height },
      nodes:runNodes.map((node) => {
        const evidence = current.document.evidence.items[node.id];
        return { ...node, confidence:evidence.confidence, source:evidence.source, evidenceSources:evidence.sources || [], humanConfirmed:evidence.humanConfirmed };
      }),
      palette:[],
      metrics:run.metrics || {},
    };
    state.analysisWidth = reference.width;
    state.analysisHeight = reference.height;
    normalizeReviewStates(state.result.nodes, false);
    state.selectedId = state.result.nodes.find((node) => node.type !== 'page')?.id || state.result.nodes[0]?.id || null;
    state.semanticMetrics = { ...(run.metrics?.adapters || {}) };
    $('#analysis-infer-layout').disabled = false;
    $('#analysis-import-ocr').disabled = !$('#analysis-ocr-json').value.trim();
    if (state.semanticMetrics.domNodes) setAdapterStatus('analysis-dom-status', `${state.semanticMetrics.domNodes} 个精确节点`, 'ready');
    if (state.semanticMetrics.ocrBlocks) setAdapterStatus('analysis-ocr-status', `${state.semanticMetrics.ocrBlocks} 条 · ${ocrAdapterLabel(state.semanticMetrics.ocrAdapter)}`, 'ready');
    if (state.semanticMetrics.inferredLayouts) setAdapterStatus('analysis-layout-status', `${state.semanticMetrics.inferredLayouts} 组 · 重复 ${state.semanticMetrics.repeatedGroups || 0}`, 'ready');
    setAdapterStatus('analysis-pixel-status', `${state.result.nodes.length} 个已保存图层 · 原运行 ${run.candidateCount || state.result.nodes.length} 候选`, 'ready');
    $('#analysis-run').textContent = '重新精确分析';
    setFlowStep(4);
    status(`已载入最近一次 UI 草稿：${run.acceptedCount} 层。可继续审核或进入页面结构。`, 'success');
    renderAll();
  } catch (error) { console.warn('Could not restore analysis.', error); }
}

$('#analysis-file').addEventListener('change', async (event) => {
  const file = event.target.files?.[0];
  if (!file) return;
  if (file.size > 12 * 1024 * 1024) { status('文件超过 12MB，请先压缩后再上传。', 'error'); return; }
  if (!['image/png','image/jpeg','image/webp'].includes(file.type)) { status('只支持 PNG、JPG 或 WebP 截图。', 'error'); return; }
  try { await loadScreenshot(file, file.name); }
  catch (error) { status(`图片无法读取：${error.message}`, 'error'); }
});

$('#analysis-load-reference').addEventListener('click', async (event) => {
  const button = event.currentTarget;
  button.disabled = true;
  button.textContent = '正在载入…';
  try {
    const response = await fetch('reference.png', { cache:'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    await loadScreenshot(await response.blob(), 'reference.png', { projectReference:true });
  } catch (error) { status(`项目参考图无法读取：${error.message}`, 'error'); }
  finally { button.disabled = false; button.textContent = '使用项目参考图'; }
});

$$('[data-analysis-mode]').forEach((button) => button.addEventListener('click', () => {
  state.analysisMode = button.dataset.analysisMode;
  $$('[data-analysis-mode]').forEach((item) => item.classList.toggle('active', item === button));
  $('#analysis-run').textContent = state.analysisMode === 'precise' ? '开始精确分析' : '开始快速分析';
}));

$$('[data-analysis-filter]').forEach((button) => button.addEventListener('click', () => {
  state.reviewFilter = button.dataset.analysisFilter;
  $$('[data-analysis-filter]').forEach((item) => item.classList.toggle('active', item === button));
  renderCandidateList();
}));

$$('[data-analysis-overlay]').forEach((button) => button.addEventListener('click', () => {
  if (button.dataset.analysisOverlay === 'labels') {
    state.showLabels = !state.showLabels;
    button.classList.toggle('active', state.showLabels);
  } else {
    state.overlayMode = button.dataset.analysisOverlay;
    $$('[data-analysis-overlay]:not([data-analysis-overlay="labels"])').forEach((item) => item.classList.toggle('active', item === button));
  }
  drawAnalysis();
}));

$('#analysis-run').addEventListener('click', runAnalysis);
$('#analysis-calibrate-dom').addEventListener('click', calibrateFromProductionDom);
$('#analysis-infer-layout').addEventListener('click', inferCurrentLayout);
$('#analysis-import-ocr').addEventListener('click', importOcrJson);
$('#analysis-ocr-json').addEventListener('input', (event) => { $('#analysis-import-ocr').disabled = !state.result || !event.target.value.trim(); });

$('#analysis-smart-triage').addEventListener('click', () => {
  if (!state.result) return;
  checkpoint('智能整理待确认候选');
  const changed = { accepted:0, excluded:0, review:0 };
  const conflicts = findConflictPairs();
  const conflictByNode = new Map();
  conflicts.forEach((conflict) => {
    conflictByNode.set(conflict.leftId, conflict);
    conflictByNode.set(conflict.rightId, conflict);
  });
  state.result.nodes.forEach((node) => {
    if (node.humanConfirmed) return;
    const conflict = conflictByNode.get(node.id);
    const next = conflict
      ? conflict.weakerId === node.id ? 'excluded' : 'review'
      : isReliableCandidate(node)
      ? 'accepted'
      : isLikelyNoiseCandidate(node) || (node.type !== 'page' && Number(node.confidence || 0) < AUTO_EXCLUDE_THRESHOLD)
        ? 'excluded'
        : 'review';
    if (reviewState(node) !== next) changed[next] += 1;
    setReviewState(node, next, false);
  });
  state.reviewFilter = 'review';
  $$('[data-analysis-filter]').forEach((item) => item.classList.toggle('active', item.dataset.analysisFilter === 'review'));
  const changeCount = changed.accepted + changed.excluded + changed.review;
  if (!changeCount && state.domAvailable && !state.projectReference) {
    status('当前没有可自动整理项。若截图来自本项目，请使用“项目参考图”重新载入，或在高级选项执行源码校准。');
  } else if (!changeCount) {
    status('当前候选已按可靠性完成整理；剩余项目需要人工确认，系统不会冒险自动采用。');
  } else {
    status(`智能整理完成：新增采用 ${changed.accepted} 项，排除噪声 ${changed.excluded} 项；仅显示仍需确认的候选。`, 'success');
  }
  renderAll();
});

$('#analysis-accept-strong').addEventListener('click', () => {
  if (!state.result) return;
  checkpoint('采用可靠候选');
  let changed = 0;
  const conflictedIds = new Set(findConflictPairs().flatMap((conflict) => [conflict.leftId, conflict.rightId]));
  state.result.nodes.forEach((node) => { if (!node.humanConfirmed && !conflictedIds.has(node.id) && isReliableCandidate(node)) { setReviewState(node, 'accepted', false); changed += 1; } });
  status(`已采用 ${changed} 个达到 92% 且具备多源证据的候选。`, 'success');
  renderAll();
});

$('#analysis-exclude-weak').addEventListener('click', () => {
  if (!state.result) return;
  checkpoint('排除低可信候选');
  let changed = 0;
  state.result.nodes.forEach((node) => { if (!node.humanConfirmed && node.type !== 'page' && Number(node.confidence || 0) < AUTO_EXCLUDE_THRESHOLD) { setReviewState(node, 'excluded', false); changed += 1; } });
  status(`已排除 ${changed} 个低于 ${Math.round(AUTO_EXCLUDE_THRESHOLD * 100)}% 的候选。`, 'success');
  renderAll();
});

$('#analysis-check-conflicts').addEventListener('click', () => {
  const conflicts = findConflictPairs();
  if (!conflicts.length) { status('未发现高重叠冲突。', 'success'); return; }
  conflicts.forEach(({ left, right }) => {
    if (!left.humanConfirmed) setReviewState(left, 'review', false);
    if (!right.humanConfirmed) setReviewState(right, 'review', false);
  });
  state.selectedId = conflicts[0].left.id;
  state.reviewFilter = 'review';
  $$('[data-analysis-filter]').forEach((item) => item.classList.toggle('active', item.dataset.analysisFilter === 'review'));
  status(`发现 ${conflicts.length} 组高重叠冲突，已加入待确认队列。`, 'error');
  renderAll();
});

$('#analysis-canvas').addEventListener('click', (event) => {
  if (!state.result) return;
  const rect = event.currentTarget.getBoundingClientRect();
  const x = (event.clientX - rect.left) / rect.width * state.sourceWidth;
  const y = (event.clientY - rect.top) / rect.height * state.sourceHeight;
  const node = candidateAtPoint(x, y);
  if (node) selectCandidate(node.id);
});

$('#analysis-canvas').addEventListener('mousemove', (event) => {
  if (!state.result) return;
  const rect = event.currentTarget.getBoundingClientRect();
  const x = (event.clientX - rect.left) / rect.width * state.sourceWidth;
  const y = (event.clientY - rect.top) / rect.height * state.sourceHeight;
  const node = candidateAtPoint(x, y);
  const nextId = node?.id || null;
  if (nextId !== state.hoveredId) { state.hoveredId = nextId; drawAnalysis(); }
});

$('#analysis-canvas').addEventListener('mouseleave', () => { state.hoveredId = null; drawAnalysis(); });
$('#analysis-prop-name').addEventListener('input', (event) => { const node = selectedCandidate(); if (node) { node.name = event.target.value || TYPE_LABELS[node.type]; renderCandidateList(); drawAnalysis(); } });
$('#analysis-prop-type').addEventListener('change', (event) => { const node = selectedCandidate(); if (node) { checkpoint(`修改“${node.name}”类型`); node.type = event.target.value; setReviewState(node, 'review', false); renderAll(); } });
$('#analysis-prop-text').addEventListener('input', (event) => { const node = selectedCandidate(); if (node) { node.content = { ...(node.content || {}), text:event.target.value, status:'human-confirmed' }; node.evidenceSources = [...new Set([...evidenceSources(node), 'human'])]; renderCandidateList(); drawAnalysis(); } });
$('#analysis-prop-parent').addEventListener('change', (event) => { const node = selectedCandidate(); if (node) { checkpoint(`修改“${node.name}”父级`); node.parentId = event.target.value || null; node.evidenceSources = [...new Set([...evidenceSources(node), 'human'])]; setReviewState(node, 'review', false); renderAll(); } });
$('#analysis-candidate-accept').addEventListener('click', () => updateSelectedState('accepted'));
$('#analysis-candidate-review').addEventListener('click', () => updateSelectedState('review'));
$('#analysis-candidate-exclude').addEventListener('click', () => updateSelectedState('excluded'));
$('#analysis-merge-candidate').addEventListener('click', mergeSelectedCandidate);
$('#analysis-split-candidate').addEventListener('click', splitSelectedCandidate);
$('#analysis-repeat-candidate').addEventListener('click', markRepeatedCandidate);
$('#analysis-conflict-locate').addEventListener('click', () => resolveSelectedConflict('locate'));
$('#analysis-conflict-merge').addEventListener('click', () => resolveSelectedConflict('merge'));
$('#analysis-conflict-keep').addEventListener('click', () => resolveSelectedConflict('keep'));
$('#analysis-conflict-exclude').addEventListener('click', () => resolveSelectedConflict('exclude'));
$('#analysis-undo-action').addEventListener('click', undoAnalysisAction);
$('#analysis-save').addEventListener('click', saveAnalysis);
$('#analysis-review-confirm').addEventListener('change', (event) => {
  state.reviewConfirmed = event.target.checked;
  updateReviewGate();
});

await restoreLatestAnalysis();
const generated = sessionStorage.getItem('ui-analysis-open-structure');
if (generated) {
  sessionStorage.removeItem('ui-analysis-open-structure');
  const detail = JSON.parse(generated);
  $('[data-feature="layers"]')?.click();
  setTimeout(() => window.dispatchEvent(new CustomEvent('ui-analysis-generated', { detail })), 200);
}
