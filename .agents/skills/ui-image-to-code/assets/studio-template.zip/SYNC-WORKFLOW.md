# Studio 与 Codex 双向衔接

生产源代码负责最终交付，`.ui-studio/ui-document.json` 负责 Studio 与 Codex 之间的版本化交接。浏览器 `localStorage` 只用于异常退出时恢复草稿，不作为最终文件。

UI Document 当前为 V4，保存截图参考、结构识别节点、证据与置信度、设计 Token、人工确认队列、图标替换和最近 200 条语义操作。`.ui-studio/operations.jsonl` 是追加式交接记录；`.ui-studio/references/` 只接收经过本地桥验证的 PNG。

## 启动

通过 Skill 新脚手架启动：

```powershell
npm run studio:start
```

本示例工程也保留兼容命令：

```powershell
npm run start
```

打开 `http://127.0.0.1:4173/studio.html`。必须通过本地桥启动；直接双击 HTML 或使用普通静态服务器时，只能保留本机草稿，不能写入项目。

## Studio 修改后交给 Codex

1. 在 Studio 中编辑文字、样式、位置、尺寸、图标或识别候选。
2. 点击“保存到项目”，生成新的 `.ui-studio` 修订。
3. 点击同步状态中的“交给 Codex”，复制交接说明。
4. 回到 Codex，粘贴说明或直接说“同步 Studio 最新修改”。
5. Codex 先执行 `npm run sync:status` 与 `npm run sync:changes`，确认后执行 `npm run sync:apply`。
6. Studio 自动从“待 Codex”回到“已同步”。

截图识别遵循同一流程：识别和人工确认后先保存 V4 修订，Codex 审查证据与操作日志。`sync:apply` 不会把未经生成器处理的候选节点直接写进生产 DOM。

识别增强数据同样进入 V4：OCR 文字保存到节点 `content`，DOM 精确校准保存 `sourceNodeId`，Flex/Grid 与重复组件建议保存为布局证据，分析运行记录保存各适配器计数。Codex 只能通过稳定源码映射应用这些数据，不能根据浏览器传入的任意路径写文件。

项目没有 `reference.png` 时，原图叠加与“载入项目当前参考图”会保持不可用并给出明确提示，不影响 Studio 其余功能。识别工作区仍可直接上传 PNG、JPG 或 WebP；保存到项目时，本地桥会把经过校验的参考证据转换并存放到 `.ui-studio/references/`。

## Codex 修改后回到 Studio

Codex 完成源代码修改后运行：

```powershell
npm run sync:source-updated
```

Studio 会显示“Codex 有更新”。点击“拉取 Codex 最新版”，中间画布重新载入源代码。即使漏跑该命令，同步桥也会通过源码哈希发现变化。

## 状态含义

- `已同步`：项目文档与生产源码一致。
- `未保存`：修改只存在于当前浏览器，需要保存到项目。
- `待 Codex`：修订已写入，等待 Codex 应用到源码。
- `Codex 有更新`：源码领先，Studio 需要拉取。
- `有冲突`：两边从同一基线都修改过；系统停止自动覆盖并保留两边数据。

## 命令

所有项目通用：

```powershell
npm run sync:init
npm run sync:status
npm run sync:changes
npm run sync:apply
npm run sync:source-updated
```

Skill 新脚手架的验证命令：

```powershell
npm run studio:check
npm run studio:check-canvas
npm run studio:check-document
npm run studio:check-analysis
npm run studio:check-fidelity
npm run studio:check-sync
```

本示例工程的等价命令为 `npm run check`、`check:canvas`、`check:document`、`check:analysis`、`check:fidelity`、`check:sync`。

同步桥只监听 `127.0.0.1`，只写允许的 `.ui-studio` 文件；每次保存要求匹配修订号，旧修订返回 409；SVG 会经过安全检查；参考图只允许 12MB 内的有效 PNG；历史默认保留最近 20 份。
