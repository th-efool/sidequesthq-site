export const UI_DOCUMENT_VERSION = 4;
export const UI_DOCUMENT_MAX_BYTES = 2 * 1024 * 1024;

const ID_PATTERN = /^[A-Za-z0-9_.:-]{1,160}$/;
const NODE_TYPES = new Set(['page','frame','section','container','text','icon','image','button','input','control','divider','unknown']);

function plainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function finite(value) {
  return Number.isFinite(Number(value));
}

export function emptyEvidence() {
  return { activeRunId:null, runs:[], items:{} };
}

export function createUIDocumentV4(hash, protocolVersion = 1) {
  return {
    protocolVersion,
    version:UI_DOCUMENT_VERSION,
    documentId:'tudoodoo-ai-studio',
    revision:0,
    baseSourceHash:hash,
    canvas:{ width:1920, height:919 },
    source:{ references:[] },
    tokens:{ color:{}, space:{}, radius:{}, type:{} },
    components:{},
    assets:{ icons:{} },
    breakpoints:{ desktop:{ minWidth:1200 }, tablet:{ minWidth:768, maxWidth:1199 }, mobile:{ maxWidth:767 } },
    nodes:[],
    evidence:emptyEvidence(),
    manualQueue:[],
    operations:[],
    overrides:{},
    iconReplacements:{},
    structuralEdits:{ insertions:[] },
    layerMetadata:{},
    updatedAt:new Date().toISOString(),
    updatedBy:'codex',
  };
}

export function migrateUIDocument(document, hash, protocolVersion = 1) {
  if (!plainObject(document)) return createUIDocumentV4(hash, protocolVersion);
  if (document.version === UI_DOCUMENT_VERSION) return {
    ...structuredClone(document),
    structuralEdits:structuredClone(document.structuralEdits || { insertions:[] }),
    layerMetadata:structuredClone(document.layerMetadata || {}),
  };
  if (document.version !== 3) throw new Error(`不支持迁移的 UI 文档版本：${document.version}`);
  const base = createUIDocumentV4(hash, protocolVersion);
  return {
    ...base,
    protocolVersion:document.protocolVersion,
    documentId:document.documentId || base.documentId,
    revision:Number(document.revision || 0),
    baseSourceHash:document.baseSourceHash || hash,
    canvas:structuredClone(document.canvas || base.canvas),
    overrides:structuredClone(document.overrides || {}),
    iconReplacements:structuredClone(document.iconReplacements || {}),
    structuralEdits:structuredClone(document.structuralEdits || { insertions:[] }),
    layerMetadata:structuredClone(document.layerMetadata || {}),
    updatedAt:document.updatedAt || new Date().toISOString(),
    updatedBy:document.updatedBy || 'codex',
    migratedFrom:3,
  };
}

function validateReferences(references) {
  if (!Array.isArray(references) || references.length > 30) throw new Error('source.references 必须是最多 30 项的数组');
  const ids = new Set();
  for (const reference of references) {
    if (!plainObject(reference) || !ID_PATTERN.test(String(reference.id || ''))) throw new Error('参考图 ID 无效');
    if (ids.has(reference.id)) throw new Error(`参考图 ID 重复：${reference.id}`);
    ids.add(reference.id);
    if (!finite(reference.width) || !finite(reference.height) || Number(reference.width) < 1 || Number(reference.height) < 1 || Number(reference.width) > 20000 || Number(reference.height) > 20000) throw new Error(`参考图 ${reference.id} 尺寸无效`);
    if (!/^\/\.ui-studio\/references\/[A-Za-z0-9_.-]{1,120}\.png$/.test(String(reference.path || ''))) throw new Error(`参考图 ${reference.id} 路径不在允许目录`);
    if (String(reference.name || '').length > 240) throw new Error(`参考图 ${reference.id} 名称过长`);
  }
}

function validateNodes(nodes) {
  if (!Array.isArray(nodes) || nodes.length > 2000) throw new Error('nodes 必须是最多 2000 项的数组');
  const ids = new Set();
  for (const node of nodes) {
    if (!plainObject(node) || !ID_PATTERN.test(String(node.id || ''))) throw new Error('识别节点 ID 无效');
    if (ids.has(node.id)) throw new Error(`识别节点 ID 重复：${node.id}`);
    ids.add(node.id);
    if (!NODE_TYPES.has(String(node.type || ''))) throw new Error(`识别节点 ${node.id} 类型无效`);
    if (node.parentId !== null && node.parentId !== undefined && !ID_PATTERN.test(String(node.parentId))) throw new Error(`识别节点 ${node.id} 父级 ID 无效`);
    if (!plainObject(node.bounds) || !['x','y','width','height'].every((key) => finite(node.bounds[key]))) throw new Error(`识别节点 ${node.id} 边界无效`);
    if (Number(node.bounds.width) < 1 || Number(node.bounds.height) < 1 || Number(node.bounds.width) > 20000 || Number(node.bounds.height) > 20000) throw new Error(`识别节点 ${node.id} 尺寸超限`);
    if (String(node.name || '').length > 240) throw new Error(`识别节点 ${node.id} 名称过长`);
  }
  for (const node of nodes) {
    if (node.parentId && !ids.has(node.parentId)) throw new Error(`识别节点 ${node.id} 的父级不存在：${node.parentId}`);
  }
}

function validateEvidence(evidence, nodes, references) {
  if (!plainObject(evidence) || !Array.isArray(evidence.runs) || !plainObject(evidence.items)) throw new Error('evidence 结构无效');
  if (evidence.runs.length > 30 || Object.keys(evidence.items).length > 2000) throw new Error('evidence 数量超限');
  const referenceIds = new Set(references.map((item) => item.id));
  const nodeIds = new Set(nodes.map((item) => item.id));
  for (const run of evidence.runs) {
    if (!plainObject(run) || !ID_PATTERN.test(String(run.id || '')) || !referenceIds.has(run.referenceId)) throw new Error('识别运行记录无效');
    if (!finite(run.candidateCount) || Number(run.candidateCount) < 0) throw new Error(`识别运行 ${run.id} 候选数无效`);
  }
  for (const [id, item] of Object.entries(evidence.items)) {
    if (!nodeIds.has(id) || !plainObject(item)) throw new Error(`识别证据 ${id} 没有对应节点`);
    if (!finite(item.confidence) || Number(item.confidence) < 0 || Number(item.confidence) > 1) throw new Error(`识别证据 ${id} 置信度无效`);
    if (!referenceIds.has(item.referenceId)) throw new Error(`识别证据 ${id} 的参考图不存在`);
  }
}

function validateStructuralEdits(structuralEdits) {
  if (!plainObject(structuralEdits) || !Array.isArray(structuralEdits.insertions) || structuralEdits.insertions.length > 300) {
    throw new Error('structuralEdits.insertions must be an array with at most 300 entries');
  }
  const insertionIds = new Set();
  const generatedIds = new Set();
  for (const insertion of structuralEdits.insertions) {
    if (!plainObject(insertion)) throw new Error('Structural insertion must be an object');
    const allowedKeys = new Set(['id','sourceId','parentId','afterId','idMap','name']);
    const unknownKey = Object.keys(insertion).find((key) => !allowedKeys.has(key));
    if (unknownKey) throw new Error(`Unknown structural insertion field: ${unknownKey}`);
    if (!ID_PATTERN.test(String(insertion.id || '')) || !ID_PATTERN.test(String(insertion.sourceId || ''))) throw new Error('Structural insertion IDs are invalid');
    if (insertionIds.has(insertion.id)) throw new Error(`Duplicate structural insertion ID: ${insertion.id}`);
    insertionIds.add(insertion.id);
    if (insertion.parentId !== null && insertion.parentId !== undefined && !ID_PATTERN.test(String(insertion.parentId))) throw new Error(`Invalid structural parent ID: ${insertion.parentId}`);
    if (insertion.afterId !== null && insertion.afterId !== undefined && !ID_PATTERN.test(String(insertion.afterId))) throw new Error(`Invalid structural sibling ID: ${insertion.afterId}`);
    if (!plainObject(insertion.idMap) || !Object.keys(insertion.idMap).length || Object.keys(insertion.idMap).length > 500) throw new Error(`Structural insertion ${insertion.id} has an invalid ID map`);
    if (insertion.idMap[insertion.sourceId] !== insertion.id) throw new Error(`Structural insertion ${insertion.id} must map its source root to its insertion ID`);
    for (const [sourceId, generatedId] of Object.entries(insertion.idMap)) {
      if (!ID_PATTERN.test(sourceId) || !ID_PATTERN.test(String(generatedId))) throw new Error(`Structural insertion ${insertion.id} contains an invalid mapped ID`);
      if (generatedIds.has(generatedId)) throw new Error(`Generated structural ID is duplicated: ${generatedId}`);
      generatedIds.add(generatedId);
    }
    if (String(insertion.name || '').length > 240) throw new Error(`Structural insertion ${insertion.id} name is too long`);
  }
}

export function validateUIDocumentV4(document, { protocolVersion = 1, maxBytes = UI_DOCUMENT_MAX_BYTES } = {}) {
  if (!plainObject(document)) throw new Error('document 必须是对象');
  if (document.protocolVersion !== protocolVersion) throw new Error(`不支持的协议版本：${document.protocolVersion}`);
  if (document.version !== UI_DOCUMENT_VERSION) throw new Error(`不支持的文档版本：${document.version}`);
  const allowedDocumentKeys = new Set([
    'protocolVersion','version','documentId','revision','baseSourceHash','canvas','source','tokens','components','assets','breakpoints','nodes','evidence','manualQueue','operations','overrides','iconReplacements','structuralEdits','layerMetadata','updatedAt','updatedBy','migratedFrom',
  ]);
  const unknownDocumentKey = Object.keys(document).find((key) => !allowedDocumentKeys.has(key));
  if (unknownDocumentKey) throw new Error(`未知文档字段：${unknownDocumentKey}`);
  if (!plainObject(document.canvas) || !finite(document.canvas.width) || !finite(document.canvas.height)) throw new Error('canvas 尺寸无效');
  if (!plainObject(document.source)) throw new Error('source 必须是对象');
  validateReferences(document.source.references);
  if (!plainObject(document.tokens) || !plainObject(document.components) || !plainObject(document.assets) || !plainObject(document.breakpoints)) throw new Error('设计系统字段无效');
  validateNodes(document.nodes);
  validateEvidence(document.evidence, document.nodes, document.source.references);
  if (!Array.isArray(document.manualQueue) || document.manualQueue.length > 1000 || document.manualQueue.some((id) => !document.nodes.some((node) => node.id === id))) throw new Error('manualQueue 无效');
  if (!Array.isArray(document.operations) || document.operations.length > 200) throw new Error('operations 必须是最多 200 项的数组');
  if (!plainObject(document.overrides)) throw new Error('overrides 必须是对象');
  if (!plainObject(document.iconReplacements)) throw new Error('iconReplacements 必须是对象');
  validateStructuralEdits(document.structuralEdits || { insertions:[] });
  const layerMetadata = document.layerMetadata || {};
  if (!plainObject(layerMetadata)) throw new Error('layerMetadata 必须是对象');
  for (const [id, metadata] of Object.entries(layerMetadata)) {
    if (!ID_PATTERN.test(id) || !plainObject(metadata)) throw new Error(`图层元数据无效：${id}`);
    const unknownKey = Object.keys(metadata).find((key) => key !== 'name');
    if (unknownKey || typeof metadata.name !== 'string' || !metadata.name.trim() || metadata.name.length > 240) throw new Error(`图层元数据名称无效：${id}`);
  }
  const serialized = JSON.stringify(document);
  if (new TextEncoder().encode(serialized).byteLength > maxBytes) throw new Error('文档超过 2MB 限制');

  const allowedOverrideKeys = new Set([
    'x','y','width','height','scale','rotation','backgroundColor','color','fontSize','fontFamily','fontWeight','lineHeight','letterSpacing','textAlign',
    'borderRadius','borderWidth','borderColor','borderStyle','opacity','padding','display','shadowX','shadowY','shadowBlur','shadowSpread','shadowColor','textContent','zIndex','position',
  ]);
  const numericKeys = new Set(['x','y','width','height','scale','rotation','fontSize','fontWeight','lineHeight','letterSpacing','borderRadius','borderWidth','opacity','padding','shadowX','shadowY','shadowBlur','shadowSpread','zIndex']);
  for (const [id, values] of Object.entries(document.overrides)) {
    if (!ID_PATTERN.test(id)) throw new Error(`图层 ID 无效：${id}`);
    if (!plainObject(values)) throw new Error(`图层 ${id} 的调整值无效`);
    for (const [key, value] of Object.entries(values)) {
      if (!allowedOverrideKeys.has(key)) throw new Error(`图层 ${id} 含未知属性：${key}`);
      if (numericKeys.has(key) && !finite(value)) throw new Error(`图层 ${id} 的 ${key} 必须是数字`);
      if (['x','y'].includes(key) && Math.abs(Number(value)) > 1_000_000) throw new Error(`图层 ${id} 的 ${key} 超出安全范围`);
      if (['width','height'].includes(key) && (Number(value) < 1 || Number(value) > 1_000_000)) throw new Error(`图层 ${id} 的 ${key} 尺寸无效`);
      if (key === 'scale' && (Number(value) < .05 || Number(value) > 10)) throw new Error(`图层 ${id} 的缩放比例无效`);
      if (key === 'rotation' && Math.abs(Number(value)) > 360) throw new Error(`图层 ${id} 的旋转角度无效`);
      if (typeof value === 'string' && value.length > 4000) throw new Error(`图层 ${id} 的 ${key} 过长`);
      if (['fontFamily','backgroundColor','color','borderColor','shadowColor'].includes(key) && /[{};@]|url\s*\(|expression\s*\(/i.test(String(value))) throw new Error(`图层 ${id} 的 ${key} 含不安全 CSS`);
      if (key === 'borderStyle' && !['solid','dashed','dotted','double','none'].includes(String(value))) throw new Error(`图层 ${id} 的边框线型无效`);
      if (key === 'textAlign' && !['left','center','right','justify','start','end'].includes(String(value))) throw new Error(`图层 ${id} 的文字对齐无效`);
      if (key === 'display' && !['none','block','inline','inline-block','flex','grid'].includes(String(value))) throw new Error(`图层 ${id} 的 display 无效`);
      if (key === 'position' && !['static','relative','absolute','fixed','sticky'].includes(String(value))) throw new Error(`图层 ${id} 的 position 无效`);
    }
  }

  const allowedSvgTags = new Set(['g','path','circle','ellipse','rect','line','polyline','polygon','defs','clippath','mask','lineargradient','radialgradient','stop','symbol','title','desc','use']);
  for (const [id, replacement] of Object.entries(document.iconReplacements)) {
    if (!ID_PATTERN.test(id) || !plainObject(replacement) || typeof replacement.body !== 'string') throw new Error(`图标 ${id || '<unknown>'} 数据无效`);
    if (/<\s*script|<\s*foreignObject|\son\w+\s*=|\sstyle\s*=|javascript:|https?:\/\/|url\s*\(\s*['"]?(?!#)/i.test(replacement.body)) throw new Error(`图标 ${id} 含不安全内容`);
    for (const match of replacement.body.matchAll(/<\/?\s*([A-Za-z][\w:-]*)/g)) {
      if (!allowedSvgTags.has(match[1].toLowerCase())) throw new Error(`图标 ${id} 含不允许的 SVG 标签：${match[1]}`);
    }
    if (replacement.viewBox && !/^\s*-?(?:\d+\.?\d*|\.\d+)\s+-?(?:\d+\.?\d*|\.\d+)\s+(?:\d+\.?\d*|\.\d+)\s+(?:\d+\.?\d*|\.\d+)\s*$/.test(replacement.viewBox)) throw new Error(`图标 ${id} 的 viewBox 无效`);
  }
  return true;
}

export function normalizeSemanticOperations(operations, revision, writer = 'studio') {
  if (!Array.isArray(operations) || operations.length > 50) throw new Error('本次 operations 必须是最多 50 项的数组');
  const now = new Date().toISOString();
  return operations.map((operation, index) => {
    if (!plainObject(operation) || !/^[a-z][a-z0-9.-]{1,80}$/.test(String(operation.type || ''))) throw new Error(`第 ${index + 1} 个 operation 类型无效`);
    const targetIds = Array.isArray(operation.targetIds) ? operation.targetIds.map(String) : [];
    if (targetIds.length > 500 || targetIds.some((id) => !ID_PATTERN.test(id))) throw new Error(`operation ${operation.type} 的 targetIds 无效`);
    return {
      id:`op-${revision}-${index + 1}`,
      type:operation.type,
      targetIds,
      detail:plainObject(operation.detail) ? structuredClone(operation.detail) : {},
      revision,
      writer,
      createdAt:now,
    };
  });
}
